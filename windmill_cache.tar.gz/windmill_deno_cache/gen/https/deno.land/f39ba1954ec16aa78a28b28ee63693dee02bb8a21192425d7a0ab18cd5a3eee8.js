/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ export var Script;
(function(Script) {
  let language;
  (function(language) {
    language["PYTHON3"] = "python3";
    language["DENO"] = "deno";
    language["GO"] = "go";
    language["BASH"] = "bash";
  })(language = Script.language || (Script.language = {}));
  let kind;
  (function(kind) {
    kind["SCRIPT"] = "script";
    kind["FAILURE"] = "failure";
    kind["TRIGGER"] = "trigger";
    kind["COMMAND"] = "command";
    kind["APPROVAL"] = "approval";
  })(kind = Script.kind || (Script.kind = {}));
})(Script || (Script = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvbW9kZWxzL1NjcmlwdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5cbmV4cG9ydCB0eXBlIFNjcmlwdCA9IHtcbiAgICB3b3Jrc3BhY2VfaWQ/OiBzdHJpbmc7XG4gICAgaGFzaDogc3RyaW5nO1xuICAgIHBhdGg6IHN0cmluZztcbiAgICAvKipcbiAgICAgKiBUaGUgZmlyc3QgZWxlbWVudCBpcyB0aGUgZGlyZWN0IHBhcmVudCBvZiB0aGUgc2NyaXB0LCB0aGUgc2Vjb25kIGlzIHRoZSBwYXJlbnQgb2YgdGhlIGZpcnN0LCBldGNcbiAgICAgKlxuICAgICAqL1xuICAgIHBhcmVudF9oYXNoZXM/OiBBcnJheTxzdHJpbmc+O1xuICAgIHN1bW1hcnk6IHN0cmluZztcbiAgICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICAgIGNvbnRlbnQ6IHN0cmluZztcbiAgICBjcmVhdGVkX2J5OiBzdHJpbmc7XG4gICAgY3JlYXRlZF9hdDogc3RyaW5nO1xuICAgIGFyY2hpdmVkOiBib29sZWFuO1xuICAgIHNjaGVtYT86IGFueTtcbiAgICBkZWxldGVkOiBib29sZWFuO1xuICAgIGlzX3RlbXBsYXRlOiBib29sZWFuO1xuICAgIGV4dHJhX3Blcm1zOiBSZWNvcmQ8c3RyaW5nLCBib29sZWFuPjtcbiAgICBsb2NrPzogc3RyaW5nO1xuICAgIGxvY2tfZXJyb3JfbG9ncz86IHN0cmluZztcbiAgICBsYW5ndWFnZTogU2NyaXB0Lmxhbmd1YWdlO1xuICAgIGtpbmQ6IFNjcmlwdC5raW5kO1xuICAgIHN0YXJyZWQ6IGJvb2xlYW47XG4gICAgdGFnPzogc3RyaW5nO1xuICAgIGhhc19kcmFmdD86IGJvb2xlYW47XG4gICAgZHJhZnRfb25seT86IGJvb2xlYW47XG59O1xuXG5leHBvcnQgbmFtZXNwYWNlIFNjcmlwdCB7XG5cbiAgICBleHBvcnQgZW51bSBsYW5ndWFnZSB7XG4gICAgICAgIFBZVEhPTjMgPSAncHl0aG9uMycsXG4gICAgICAgIERFTk8gPSAnZGVubycsXG4gICAgICAgIEdPID0gJ2dvJyxcbiAgICAgICAgQkFTSCA9ICdiYXNoJyxcbiAgICB9XG5cbiAgICBleHBvcnQgZW51bSBraW5kIHtcbiAgICAgICAgU0NSSVBUID0gJ3NjcmlwdCcsXG4gICAgICAgIEZBSUxVUkUgPSAnZmFpbHVyZScsXG4gICAgICAgIFRSSUdHRVIgPSAndHJpZ2dlcicsXG4gICAgICAgIENPTU1BTkQgPSAnY29tbWFuZCcsXG4gICAgICAgIEFQUFJPVkFMID0gJ2FwcHJvdmFsJyxcbiAgICB9XG5cblxufVxuXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsd0JBQXdCLEdBQ3hCLGtCQUFrQixHQUNsQixrQkFBa0I7VUErQkQ7O1lBRUQ7Ozs7O0tBQUEsa0JBQUEsb0JBQUE7O1lBT0E7Ozs7OztLQUFBLGNBQUEsZ0JBQUE7QUFTaEIsR0FsQmlCLFdBQUEifQ==
/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class JobService {
  /**
     * run script by path
     * @returns string job created
     * @throws ApiError
     */ static runScriptByPath({ workspace, path, requestBody, scheduledFor, scheduledInSecs, parentJob, invisibleToOwner }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs/run/p/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      query: {
        'scheduled_for': scheduledFor,
        'scheduled_in_secs': scheduledInSecs,
        'parent_job': parentJob,
        'invisible_to_owner': invisibleToOwner
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * run script by path
     * @returns any job result
     * @throws ApiError
     */ static runWaitResultScriptByPath({ workspace, path, requestBody, parentJob, includeHeader, queueLimit }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs/run_wait_result/p/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      query: {
        'parent_job': parentJob,
        'include_header': includeHeader,
        'queue_limit': queueLimit
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * run script by path with get
     * @returns any job result
     * @throws ApiError
     */ static runWaitResultScriptByPathGet({ workspace, path, parentJob, includeHeader, queueLimit, payload }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs/run_wait_result/p/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      query: {
        'parent_job': parentJob,
        'include_header': includeHeader,
        'queue_limit': queueLimit,
        'payload': payload
      }
    });
  }
  /**
     * run flow by path and wait until completion
     * @returns any job result
     * @throws ApiError
     */ static runWaitResultFlowByPath({ workspace, path, requestBody, includeHeader, queueLimit }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs/run_wait_result/f/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      query: {
        'include_header': includeHeader,
        'queue_limit': queueLimit
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * get job result by id
     * @returns any job result
     * @throws ApiError
     */ static resultById({ workspace, flowJobId, nodeId }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs/result_by_id/{flow_job_id}/{node_id}',
      path: {
        'workspace': workspace,
        'flow_job_id': flowJobId,
        'node_id': nodeId
      }
    });
  }
  /**
     * run flow by path
     * @returns string job created
     * @throws ApiError
     */ static runFlowByPath({ workspace, path, requestBody, scheduledFor, scheduledInSecs, parentJob, includeHeader, invisibleToOwner }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs/run/f/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      query: {
        'scheduled_for': scheduledFor,
        'scheduled_in_secs': scheduledInSecs,
        'parent_job': parentJob,
        'include_header': includeHeader,
        'invisible_to_owner': invisibleToOwner
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * run script by hash
     * @returns string job created
     * @throws ApiError
     */ static runScriptByHash({ workspace, hash, requestBody, scheduledFor, scheduledInSecs, parentJob, includeHeader, invisibleToOwner }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs/run/h/{hash}',
      path: {
        'workspace': workspace,
        'hash': hash
      },
      query: {
        'scheduled_for': scheduledFor,
        'scheduled_in_secs': scheduledInSecs,
        'parent_job': parentJob,
        'include_header': includeHeader,
        'invisible_to_owner': invisibleToOwner
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * run script preview
     * @returns string job created
     * @throws ApiError
     */ static runScriptPreview({ workspace, requestBody, includeHeader, invisibleToOwner }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs/run/preview',
      path: {
        'workspace': workspace
      },
      query: {
        'include_header': includeHeader,
        'invisible_to_owner': invisibleToOwner
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * run flow preview
     * @returns string job created
     * @throws ApiError
     */ static runFlowPreview({ workspace, requestBody, includeHeader, invisibleToOwner }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs/run/preview_flow',
      path: {
        'workspace': workspace
      },
      query: {
        'include_header': includeHeader,
        'invisible_to_owner': invisibleToOwner
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * list all available queued jobs
     * @returns QueuedJob All available queued jobs
     * @throws ApiError
     */ static listQueue({ workspace, orderDesc, createdBy, parentJob, scriptPathExact, scriptPathStart, scriptHash, startedBefore, startedAfter, success, jobKinds, suspended, running, args, result, tag }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs/queue/list',
      path: {
        'workspace': workspace
      },
      query: {
        'order_desc': orderDesc,
        'created_by': createdBy,
        'parent_job': parentJob,
        'script_path_exact': scriptPathExact,
        'script_path_start': scriptPathStart,
        'script_hash': scriptHash,
        'started_before': startedBefore,
        'started_after': startedAfter,
        'success': success,
        'job_kinds': jobKinds,
        'suspended': suspended,
        'running': running,
        'args': args,
        'result': result,
        'tag': tag
      }
    });
  }
  /**
     * list all available completed jobs
     * @returns CompletedJob All available completed jobs
     * @throws ApiError
     */ static listCompletedJobs({ workspace, orderDesc, createdBy, parentJob, scriptPathExact, scriptPathStart, scriptHash, startedBefore, startedAfter, success, jobKinds, args, result, tag, isSkipped, isFlowStep }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs/completed/list',
      path: {
        'workspace': workspace
      },
      query: {
        'order_desc': orderDesc,
        'created_by': createdBy,
        'parent_job': parentJob,
        'script_path_exact': scriptPathExact,
        'script_path_start': scriptPathStart,
        'script_hash': scriptHash,
        'started_before': startedBefore,
        'started_after': startedAfter,
        'success': success,
        'job_kinds': jobKinds,
        'args': args,
        'result': result,
        'tag': tag,
        'is_skipped': isSkipped,
        'is_flow_step': isFlowStep
      }
    });
  }
  /**
     * list all available jobs
     * @returns Job All jobs
     * @throws ApiError
     */ static listJobs({ workspace, createdBy, parentJob, scriptPathExact, scriptPathStart, scriptHash, startedBefore, startedAfter, jobKinds, args, tag, result, isSkipped, isFlowStep, success }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs/list',
      path: {
        'workspace': workspace
      },
      query: {
        'created_by': createdBy,
        'parent_job': parentJob,
        'script_path_exact': scriptPathExact,
        'script_path_start': scriptPathStart,
        'script_hash': scriptHash,
        'started_before': startedBefore,
        'started_after': startedAfter,
        'job_kinds': jobKinds,
        'args': args,
        'tag': tag,
        'result': result,
        'is_skipped': isSkipped,
        'is_flow_step': isFlowStep,
        'success': success
      }
    });
  }
  /**
     * get job
     * @returns Job job details
     * @throws ApiError
     */ static getJob({ workspace, id }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs_u/get/{id}',
      path: {
        'workspace': workspace,
        'id': id
      }
    });
  }
  /**
     * get job updates
     * @returns any job details
     * @throws ApiError
     */ static getJobUpdates({ workspace, id, running, logOffset }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs_u/getupdate/{id}',
      path: {
        'workspace': workspace,
        'id': id
      },
      query: {
        'running': running,
        'log_offset': logOffset
      }
    });
  }
  /**
     * get completed job
     * @returns CompletedJob job details
     * @throws ApiError
     */ static getCompletedJob({ workspace, id }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs/completed/get/{id}',
      path: {
        'workspace': workspace,
        'id': id
      }
    });
  }
  /**
     * get completed job result
     * @returns any result
     * @throws ApiError
     */ static getCompletedJobResult({ workspace, id }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs/completed/get_result/{id}',
      path: {
        'workspace': workspace,
        'id': id
      }
    });
  }
  /**
     * delete completed job (erase content but keep run id)
     * @returns CompletedJob job details
     * @throws ApiError
     */ static deleteCompletedJob({ workspace, id }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs/completed/delete/{id}',
      path: {
        'workspace': workspace,
        'id': id
      }
    });
  }
  /**
     * cancel queued job
     * @returns string job canceled
     * @throws ApiError
     */ static cancelQueuedJob({ workspace, id, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs_u/queue/cancel/{id}',
      path: {
        'workspace': workspace,
        'id': id
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * force cancel queued job
     * @returns string job canceled
     * @throws ApiError
     */ static forceCancelQueuedJob({ workspace, id, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs_u/queue/force_cancel/{id}',
      path: {
        'workspace': workspace,
        'id': id
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * create an HMac signature given a job id and a resume id
     * @returns string job signature
     * @throws ApiError
     */ static createJobSignature({ workspace, id, resumeId, approver }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs/job_signature/{id}/{resume_id}',
      path: {
        'workspace': workspace,
        'id': id,
        'resume_id': resumeId
      },
      query: {
        'approver': approver
      }
    });
  }
  /**
     * get resume urls given a job_id, resume_id and a nonce to resume a flow
     * @returns any url endpoints
     * @throws ApiError
     */ static getResumeUrls({ workspace, id, resumeId, approver }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs/resume_urls/{id}/{resume_id}',
      path: {
        'workspace': workspace,
        'id': id,
        'resume_id': resumeId
      },
      query: {
        'approver': approver
      }
    });
  }
  /**
     * resume a job for a suspended flow
     * @returns string job resumed
     * @throws ApiError
     */ static resumeSuspendedJobGet({ workspace, id, resumeId, signature, payload, approver }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs_u/resume/{id}/{resume_id}/{signature}',
      path: {
        'workspace': workspace,
        'id': id,
        'resume_id': resumeId,
        'signature': signature
      },
      query: {
        'payload': payload,
        'approver': approver
      }
    });
  }
  /**
     * resume a job for a suspended flow
     * @returns string job resumed
     * @throws ApiError
     */ static resumeSuspendedJobPost({ workspace, id, resumeId, signature, requestBody, approver }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs_u/resume/{id}/{resume_id}/{signature}',
      path: {
        'workspace': workspace,
        'id': id,
        'resume_id': resumeId,
        'signature': signature
      },
      query: {
        'approver': approver
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * resume a job for a suspended flow as an owner
     * @returns string job resumed
     * @throws ApiError
     */ static resumeSuspendedFlowAsOwner({ workspace, id, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs/flow/resume/{id}',
      path: {
        'workspace': workspace,
        'id': id
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * cancel a job for a suspended flow
     * @returns string job resumed
     * @throws ApiError
     */ static cancelSuspendedJobGet({ workspace, id, resumeId, signature, approver }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs_u/cancel/{id}/{resume_id}/{signature}',
      path: {
        'workspace': workspace,
        'id': id,
        'resume_id': resumeId,
        'signature': signature
      },
      query: {
        'approver': approver
      }
    });
  }
  /**
     * cancel a job for a suspended flow
     * @returns string job resumed
     * @throws ApiError
     */ static cancelSuspendedJobPost({ workspace, id, resumeId, signature, requestBody, approver }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/jobs_u/cancel/{id}/{resume_id}/{signature}',
      path: {
        'workspace': workspace,
        'id': id,
        'resume_id': resumeId,
        'signature': signature
      },
      query: {
        'approver': approver
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * get parent flow job of suspended job
     * @returns any parent flow details
     * @throws ApiError
     */ static getSuspendedJobFlow({ workspace, id, resumeId, signature, approver }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/jobs_u/get_flow/{id}/{resume_id}/{signature}',
      path: {
        'workspace': workspace,
        'id': id,
        'resume_id': resumeId,
        'signature': signature
      },
      query: {
        'approver': approver
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvSm9iU2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5pbXBvcnQgdHlwZSB7IENvbXBsZXRlZEpvYiB9IGZyb20gJy4uL21vZGVscy9Db21wbGV0ZWRKb2IudHMnO1xuaW1wb3J0IHR5cGUgeyBGbG93UHJldmlldyB9IGZyb20gJy4uL21vZGVscy9GbG93UHJldmlldy50cyc7XG5pbXBvcnQgdHlwZSB7IEpvYiB9IGZyb20gJy4uL21vZGVscy9Kb2IudHMnO1xuaW1wb3J0IHR5cGUgeyBQcmV2aWV3IH0gZnJvbSAnLi4vbW9kZWxzL1ByZXZpZXcudHMnO1xuaW1wb3J0IHR5cGUgeyBRdWV1ZWRKb2IgfSBmcm9tICcuLi9tb2RlbHMvUXVldWVkSm9iLnRzJztcbmltcG9ydCB0eXBlIHsgU2NyaXB0QXJncyB9IGZyb20gJy4uL21vZGVscy9TY3JpcHRBcmdzLnRzJztcblxuaW1wb3J0IHR5cGUgeyBDYW5jZWxhYmxlUHJvbWlzZSB9IGZyb20gJy4uL2NvcmUvQ2FuY2VsYWJsZVByb21pc2UudHMnO1xuaW1wb3J0IHsgT3BlbkFQSSB9IGZyb20gJy4uL2NvcmUvT3BlbkFQSS50cyc7XG5pbXBvcnQgeyByZXF1ZXN0IGFzIF9fcmVxdWVzdCB9IGZyb20gJy4uL2NvcmUvcmVxdWVzdC50cyc7XG5cbmV4cG9ydCBjbGFzcyBKb2JTZXJ2aWNlIHtcblxuICAgIC8qKlxuICAgICAqIHJ1biBzY3JpcHQgYnkgcGF0aFxuICAgICAqIEByZXR1cm5zIHN0cmluZyBqb2IgY3JlYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJ1blNjcmlwdEJ5UGF0aCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgICAgIHNjaGVkdWxlZEZvcixcbiAgICAgICAgc2NoZWR1bGVkSW5TZWNzLFxuICAgICAgICBwYXJlbnRKb2IsXG4gICAgICAgIGludmlzaWJsZVRvT3duZXIsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogc2NyaXB0IGFyZ3NcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiBTY3JpcHRBcmdzLFxuICAgICAgICAvKipcbiAgICAgICAgICogd2hlbiB0byBzY2hlZHVsZSB0aGlzIGpvYiAobGVhdmUgZW1wdHkgZm9yIGltbWVkaWF0ZSBydW4pXG4gICAgICAgICAqL1xuICAgICAgICBzY2hlZHVsZWRGb3I/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBzY2hlZHVsZSB0aGUgc2NyaXB0IHRvIGV4ZWN1dGUgaW4gdGhlIG51bWJlciBvZiBzZWNvbmRzIHN0YXJ0aW5nIG5vd1xuICAgICAgICAgKi9cbiAgICAgICAgc2NoZWR1bGVkSW5TZWNzPzogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIHBhcmVudCBqb2IgdGhhdCBpcyBhdCB0aGUgb3JpZ2luIGFuZCByZXNwb25zaWJsZSBmb3IgdGhlIGV4ZWN1dGlvbiBvZiB0aGlzIHNjcmlwdCBpZiBhbnlcbiAgICAgICAgICovXG4gICAgICAgIHBhcmVudEpvYj86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1ha2UgdGhlIHJ1biBpbnZpc2libGUgdG8gdGhlIHRoZSBzY3JpcHQgb3duZXIgKGRlZmF1bHQgZmFsc2UpXG4gICAgICAgICAqL1xuICAgICAgICBpbnZpc2libGVUb093bmVyPzogYm9vbGVhbixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzL3J1bi9wL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAnc2NoZWR1bGVkX2Zvcic6IHNjaGVkdWxlZEZvcixcbiAgICAgICAgICAgICAgICAnc2NoZWR1bGVkX2luX3NlY3MnOiBzY2hlZHVsZWRJblNlY3MsXG4gICAgICAgICAgICAgICAgJ3BhcmVudF9qb2InOiBwYXJlbnRKb2IsXG4gICAgICAgICAgICAgICAgJ2ludmlzaWJsZV90b19vd25lcic6IGludmlzaWJsZVRvT3duZXIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcnVuIHNjcmlwdCBieSBwYXRoXG4gICAgICogQHJldHVybnMgYW55IGpvYiByZXN1bHRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBydW5XYWl0UmVzdWx0U2NyaXB0QnlQYXRoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICAgICAgcGFyZW50Sm9iLFxuICAgICAgICBpbmNsdWRlSGVhZGVyLFxuICAgICAgICBxdWV1ZUxpbWl0LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHNjcmlwdCBhcmdzXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogU2NyaXB0QXJncyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZSBwYXJlbnQgam9iIHRoYXQgaXMgYXQgdGhlIG9yaWdpbiBhbmQgcmVzcG9uc2libGUgZm9yIHRoZSBleGVjdXRpb24gb2YgdGhpcyBzY3JpcHQgaWYgYW55XG4gICAgICAgICAqL1xuICAgICAgICBwYXJlbnRKb2I/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBMaXN0IG9mIGhlYWRlcnMncyBrZXlzIChzZXBhcmF0ZWQgd2l0aCAnLCcpIHdob3ZlIHZhbHVlIGFyZSBhZGRlZCB0byB0aGUgYXJnc1xuICAgICAgICAgKiBIZWFkZXIncyBrZXkgbG93ZXJjYXNlZCBhbmQgJy0nJyByZXBsYWNlZCB0byAnXycgc3VjaCB0aGF0ICdDb250ZW50LVR5cGUnIGJlY29tZXMgdGhlICdjb250ZW50X3R5cGUnIGFyZyBrZXlcbiAgICAgICAgICpcbiAgICAgICAgICovXG4gICAgICAgIGluY2x1ZGVIZWFkZXI/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBUaGUgbWF4aW11bSBzaXplIG9mIHRoZSBxdWV1ZSBmb3Igd2hpY2ggdGhlIHJlcXVlc3Qgd291bGQgZ2V0IHJlamVjdGVkIGlmIHRoYXQgam9iIHdvdWxkIHB1c2ggaXQgYWJvdmUgdGhhdCBsaW1pdFxuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgcXVldWVMaW1pdD86IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8YW55PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzL3J1bl93YWl0X3Jlc3VsdC9wL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAncGFyZW50X2pvYic6IHBhcmVudEpvYixcbiAgICAgICAgICAgICAgICAnaW5jbHVkZV9oZWFkZXInOiBpbmNsdWRlSGVhZGVyLFxuICAgICAgICAgICAgICAgICdxdWV1ZV9saW1pdCc6IHF1ZXVlTGltaXQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcnVuIHNjcmlwdCBieSBwYXRoIHdpdGggZ2V0XG4gICAgICogQHJldHVybnMgYW55IGpvYiByZXN1bHRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBydW5XYWl0UmVzdWx0U2NyaXB0QnlQYXRoR2V0KHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICBwYXJlbnRKb2IsXG4gICAgICAgIGluY2x1ZGVIZWFkZXIsXG4gICAgICAgIHF1ZXVlTGltaXQsXG4gICAgICAgIHBheWxvYWQsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIHBhcmVudCBqb2IgdGhhdCBpcyBhdCB0aGUgb3JpZ2luIGFuZCByZXNwb25zaWJsZSBmb3IgdGhlIGV4ZWN1dGlvbiBvZiB0aGlzIHNjcmlwdCBpZiBhbnlcbiAgICAgICAgICovXG4gICAgICAgIHBhcmVudEpvYj86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIExpc3Qgb2YgaGVhZGVycydzIGtleXMgKHNlcGFyYXRlZCB3aXRoICcsJykgd2hvdmUgdmFsdWUgYXJlIGFkZGVkIHRvIHRoZSBhcmdzXG4gICAgICAgICAqIEhlYWRlcidzIGtleSBsb3dlcmNhc2VkIGFuZCAnLScnIHJlcGxhY2VkIHRvICdfJyBzdWNoIHRoYXQgJ0NvbnRlbnQtVHlwZScgYmVjb21lcyB0aGUgJ2NvbnRlbnRfdHlwZScgYXJnIGtleVxuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgaW5jbHVkZUhlYWRlcj86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZSBtYXhpbXVtIHNpemUgb2YgdGhlIHF1ZXVlIGZvciB3aGljaCB0aGUgcmVxdWVzdCB3b3VsZCBnZXQgcmVqZWN0ZWQgaWYgdGhhdCBqb2Igd291bGQgcHVzaCBpdCBhYm92ZSB0aGF0IGxpbWl0XG4gICAgICAgICAqXG4gICAgICAgICAqL1xuICAgICAgICBxdWV1ZUxpbWl0Pzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIGJhc2U2NCBlbmNvZGVkIHBheWxvYWQgdGhhdCBoYXMgYmVlbiBlbmNvZGVkIGFzIGEgSlNPTi4gZS5nIGhvdyB0byBlbmNvZGUgc3VjaCBwYXlsb2FkIGVuY29kZVVSSUNvbXBvbmVudFxuICAgICAgICAgKiBgZW5jb2RlVVJJQ29tcG9uZW50KGJ0b2EoSlNPTi5zdHJpbmdpZnkoe2E6IDJ9KSkpYFxuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgcGF5bG9hZD86IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8YW55PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2pvYnMvcnVuX3dhaXRfcmVzdWx0L3Ave3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdwYXJlbnRfam9iJzogcGFyZW50Sm9iLFxuICAgICAgICAgICAgICAgICdpbmNsdWRlX2hlYWRlcic6IGluY2x1ZGVIZWFkZXIsXG4gICAgICAgICAgICAgICAgJ3F1ZXVlX2xpbWl0JzogcXVldWVMaW1pdCxcbiAgICAgICAgICAgICAgICAncGF5bG9hZCc6IHBheWxvYWQsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBydW4gZmxvdyBieSBwYXRoIGFuZCB3YWl0IHVudGlsIGNvbXBsZXRpb25cbiAgICAgKiBAcmV0dXJucyBhbnkgam9iIHJlc3VsdFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJ1bldhaXRSZXN1bHRGbG93QnlQYXRoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICAgICAgaW5jbHVkZUhlYWRlcixcbiAgICAgICAgcXVldWVMaW1pdCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBzY3JpcHQgYXJnc1xuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IFNjcmlwdEFyZ3MsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBMaXN0IG9mIGhlYWRlcnMncyBrZXlzIChzZXBhcmF0ZWQgd2l0aCAnLCcpIHdob3ZlIHZhbHVlIGFyZSBhZGRlZCB0byB0aGUgYXJnc1xuICAgICAgICAgKiBIZWFkZXIncyBrZXkgbG93ZXJjYXNlZCBhbmQgJy0nJyByZXBsYWNlZCB0byAnXycgc3VjaCB0aGF0ICdDb250ZW50LVR5cGUnIGJlY29tZXMgdGhlICdjb250ZW50X3R5cGUnIGFyZyBrZXlcbiAgICAgICAgICpcbiAgICAgICAgICovXG4gICAgICAgIGluY2x1ZGVIZWFkZXI/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBUaGUgbWF4aW11bSBzaXplIG9mIHRoZSBxdWV1ZSBmb3Igd2hpY2ggdGhlIHJlcXVlc3Qgd291bGQgZ2V0IHJlamVjdGVkIGlmIHRoYXQgam9iIHdvdWxkIHB1c2ggaXQgYWJvdmUgdGhhdCBsaW1pdFxuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgcXVldWVMaW1pdD86IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8YW55PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzL3J1bl93YWl0X3Jlc3VsdC9mL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAnaW5jbHVkZV9oZWFkZXInOiBpbmNsdWRlSGVhZGVyLFxuICAgICAgICAgICAgICAgICdxdWV1ZV9saW1pdCc6IHF1ZXVlTGltaXQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZ2V0IGpvYiByZXN1bHQgYnkgaWRcbiAgICAgKiBAcmV0dXJucyBhbnkgam9iIHJlc3VsdFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJlc3VsdEJ5SWQoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIGZsb3dKb2JJZCxcbiAgICAgICAgbm9kZUlkLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGZsb3dKb2JJZDogc3RyaW5nLFxuICAgICAgICBub2RlSWQ6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8YW55PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2pvYnMvcmVzdWx0X2J5X2lkL3tmbG93X2pvYl9pZH0ve25vZGVfaWR9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdmbG93X2pvYl9pZCc6IGZsb3dKb2JJZCxcbiAgICAgICAgICAgICAgICAnbm9kZV9pZCc6IG5vZGVJZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHJ1biBmbG93IGJ5IHBhdGhcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgam9iIGNyZWF0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBydW5GbG93QnlQYXRoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICAgICAgc2NoZWR1bGVkRm9yLFxuICAgICAgICBzY2hlZHVsZWRJblNlY3MsXG4gICAgICAgIHBhcmVudEpvYixcbiAgICAgICAgaW5jbHVkZUhlYWRlcixcbiAgICAgICAgaW52aXNpYmxlVG9Pd25lcixcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBmbG93IGFyZ3NcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiBTY3JpcHRBcmdzLFxuICAgICAgICAvKipcbiAgICAgICAgICogd2hlbiB0byBzY2hlZHVsZSB0aGlzIGpvYiAobGVhdmUgZW1wdHkgZm9yIGltbWVkaWF0ZSBydW4pXG4gICAgICAgICAqL1xuICAgICAgICBzY2hlZHVsZWRGb3I/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBzY2hlZHVsZSB0aGUgc2NyaXB0IHRvIGV4ZWN1dGUgaW4gdGhlIG51bWJlciBvZiBzZWNvbmRzIHN0YXJ0aW5nIG5vd1xuICAgICAgICAgKi9cbiAgICAgICAgc2NoZWR1bGVkSW5TZWNzPzogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIHBhcmVudCBqb2IgdGhhdCBpcyBhdCB0aGUgb3JpZ2luIGFuZCByZXNwb25zaWJsZSBmb3IgdGhlIGV4ZWN1dGlvbiBvZiB0aGlzIHNjcmlwdCBpZiBhbnlcbiAgICAgICAgICovXG4gICAgICAgIHBhcmVudEpvYj86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIExpc3Qgb2YgaGVhZGVycydzIGtleXMgKHNlcGFyYXRlZCB3aXRoICcsJykgd2hvdmUgdmFsdWUgYXJlIGFkZGVkIHRvIHRoZSBhcmdzXG4gICAgICAgICAqIEhlYWRlcidzIGtleSBsb3dlcmNhc2VkIGFuZCAnLScnIHJlcGxhY2VkIHRvICdfJyBzdWNoIHRoYXQgJ0NvbnRlbnQtVHlwZScgYmVjb21lcyB0aGUgJ2NvbnRlbnRfdHlwZScgYXJnIGtleVxuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgaW5jbHVkZUhlYWRlcj86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1ha2UgdGhlIHJ1biBpbnZpc2libGUgdG8gdGhlIHRoZSBmbG93IG93bmVyIChkZWZhdWx0IGZhbHNlKVxuICAgICAgICAgKi9cbiAgICAgICAgaW52aXNpYmxlVG9Pd25lcj86IGJvb2xlYW4sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vam9icy9ydW4vZi97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ3NjaGVkdWxlZF9mb3InOiBzY2hlZHVsZWRGb3IsXG4gICAgICAgICAgICAgICAgJ3NjaGVkdWxlZF9pbl9zZWNzJzogc2NoZWR1bGVkSW5TZWNzLFxuICAgICAgICAgICAgICAgICdwYXJlbnRfam9iJzogcGFyZW50Sm9iLFxuICAgICAgICAgICAgICAgICdpbmNsdWRlX2hlYWRlcic6IGluY2x1ZGVIZWFkZXIsXG4gICAgICAgICAgICAgICAgJ2ludmlzaWJsZV90b19vd25lcic6IGludmlzaWJsZVRvT3duZXIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcnVuIHNjcmlwdCBieSBoYXNoXG4gICAgICogQHJldHVybnMgc3RyaW5nIGpvYiBjcmVhdGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcnVuU2NyaXB0QnlIYXNoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBoYXNoLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICAgICAgc2NoZWR1bGVkRm9yLFxuICAgICAgICBzY2hlZHVsZWRJblNlY3MsXG4gICAgICAgIHBhcmVudEpvYixcbiAgICAgICAgaW5jbHVkZUhlYWRlcixcbiAgICAgICAgaW52aXNpYmxlVG9Pd25lcixcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBoYXNoOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQYXJ0aWFsbHkgZmlsbGVkIGFyZ3NcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiBhbnksXG4gICAgICAgIC8qKlxuICAgICAgICAgKiB3aGVuIHRvIHNjaGVkdWxlIHRoaXMgam9iIChsZWF2ZSBlbXB0eSBmb3IgaW1tZWRpYXRlIHJ1bilcbiAgICAgICAgICovXG4gICAgICAgIHNjaGVkdWxlZEZvcj86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHNjaGVkdWxlIHRoZSBzY3JpcHQgdG8gZXhlY3V0ZSBpbiB0aGUgbnVtYmVyIG9mIHNlY29uZHMgc3RhcnRpbmcgbm93XG4gICAgICAgICAqL1xuICAgICAgICBzY2hlZHVsZWRJblNlY3M/OiBudW1iZXIsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBUaGUgcGFyZW50IGpvYiB0aGF0IGlzIGF0IHRoZSBvcmlnaW4gYW5kIHJlc3BvbnNpYmxlIGZvciB0aGUgZXhlY3V0aW9uIG9mIHRoaXMgc2NyaXB0IGlmIGFueVxuICAgICAgICAgKi9cbiAgICAgICAgcGFyZW50Sm9iPzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogTGlzdCBvZiBoZWFkZXJzJ3Mga2V5cyAoc2VwYXJhdGVkIHdpdGggJywnKSB3aG92ZSB2YWx1ZSBhcmUgYWRkZWQgdG8gdGhlIGFyZ3NcbiAgICAgICAgICogSGVhZGVyJ3Mga2V5IGxvd2VyY2FzZWQgYW5kICctJycgcmVwbGFjZWQgdG8gJ18nIHN1Y2ggdGhhdCAnQ29udGVudC1UeXBlJyBiZWNvbWVzIHRoZSAnY29udGVudF90eXBlJyBhcmcga2V5XG4gICAgICAgICAqXG4gICAgICAgICAqL1xuICAgICAgICBpbmNsdWRlSGVhZGVyPzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogbWFrZSB0aGUgcnVuIGludmlzaWJsZSB0byB0aGUgdGhlIHNjcmlwdCBvd25lciAoZGVmYXVsdCBmYWxzZSlcbiAgICAgICAgICovXG4gICAgICAgIGludmlzaWJsZVRvT3duZXI/OiBib29sZWFuLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2pvYnMvcnVuL2gve2hhc2h9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdoYXNoJzogaGFzaCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdzY2hlZHVsZWRfZm9yJzogc2NoZWR1bGVkRm9yLFxuICAgICAgICAgICAgICAgICdzY2hlZHVsZWRfaW5fc2Vjcyc6IHNjaGVkdWxlZEluU2VjcyxcbiAgICAgICAgICAgICAgICAncGFyZW50X2pvYic6IHBhcmVudEpvYixcbiAgICAgICAgICAgICAgICAnaW5jbHVkZV9oZWFkZXInOiBpbmNsdWRlSGVhZGVyLFxuICAgICAgICAgICAgICAgICdpbnZpc2libGVfdG9fb3duZXInOiBpbnZpc2libGVUb093bmVyLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHJ1biBzY3JpcHQgcHJldmlld1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBqb2IgY3JlYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJ1blNjcmlwdFByZXZpZXcoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgICAgICBpbmNsdWRlSGVhZGVyLFxuICAgICAgICBpbnZpc2libGVUb093bmVyLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBwcmV2aWV3XG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogUHJldmlldyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIExpc3Qgb2YgaGVhZGVycydzIGtleXMgKHNlcGFyYXRlZCB3aXRoICcsJykgd2hvdmUgdmFsdWUgYXJlIGFkZGVkIHRvIHRoZSBhcmdzXG4gICAgICAgICAqIEhlYWRlcidzIGtleSBsb3dlcmNhc2VkIGFuZCAnLScnIHJlcGxhY2VkIHRvICdfJyBzdWNoIHRoYXQgJ0NvbnRlbnQtVHlwZScgYmVjb21lcyB0aGUgJ2NvbnRlbnRfdHlwZScgYXJnIGtleVxuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgaW5jbHVkZUhlYWRlcj86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1ha2UgdGhlIHJ1biBpbnZpc2libGUgdG8gdGhlIHRoZSBzY3JpcHQgb3duZXIgKGRlZmF1bHQgZmFsc2UpXG4gICAgICAgICAqL1xuICAgICAgICBpbnZpc2libGVUb093bmVyPzogYm9vbGVhbixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzL3J1bi9wcmV2aWV3JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ2luY2x1ZGVfaGVhZGVyJzogaW5jbHVkZUhlYWRlcixcbiAgICAgICAgICAgICAgICAnaW52aXNpYmxlX3RvX293bmVyJzogaW52aXNpYmxlVG9Pd25lcixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBydW4gZmxvdyBwcmV2aWV3XG4gICAgICogQHJldHVybnMgc3RyaW5nIGpvYiBjcmVhdGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcnVuRmxvd1ByZXZpZXcoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgICAgICBpbmNsdWRlSGVhZGVyLFxuICAgICAgICBpbnZpc2libGVUb093bmVyLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBwcmV2aWV3XG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogRmxvd1ByZXZpZXcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBMaXN0IG9mIGhlYWRlcnMncyBrZXlzIChzZXBhcmF0ZWQgd2l0aCAnLCcpIHdob3ZlIHZhbHVlIGFyZSBhZGRlZCB0byB0aGUgYXJnc1xuICAgICAgICAgKiBIZWFkZXIncyBrZXkgbG93ZXJjYXNlZCBhbmQgJy0nJyByZXBsYWNlZCB0byAnXycgc3VjaCB0aGF0ICdDb250ZW50LVR5cGUnIGJlY29tZXMgdGhlICdjb250ZW50X3R5cGUnIGFyZyBrZXlcbiAgICAgICAgICpcbiAgICAgICAgICovXG4gICAgICAgIGluY2x1ZGVIZWFkZXI/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBtYWtlIHRoZSBydW4gaW52aXNpYmxlIHRvIHRoZSB0aGUgc2NyaXB0IG93bmVyIChkZWZhdWx0IGZhbHNlKVxuICAgICAgICAgKi9cbiAgICAgICAgaW52aXNpYmxlVG9Pd25lcj86IGJvb2xlYW4sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vam9icy9ydW4vcHJldmlld19mbG93JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ2luY2x1ZGVfaGVhZGVyJzogaW5jbHVkZUhlYWRlcixcbiAgICAgICAgICAgICAgICAnaW52aXNpYmxlX3RvX293bmVyJzogaW52aXNpYmxlVG9Pd25lcixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGFsbCBhdmFpbGFibGUgcXVldWVkIGpvYnNcbiAgICAgKiBAcmV0dXJucyBRdWV1ZWRKb2IgQWxsIGF2YWlsYWJsZSBxdWV1ZWQgam9ic1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RRdWV1ZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgb3JkZXJEZXNjLFxuICAgICAgICBjcmVhdGVkQnksXG4gICAgICAgIHBhcmVudEpvYixcbiAgICAgICAgc2NyaXB0UGF0aEV4YWN0LFxuICAgICAgICBzY3JpcHRQYXRoU3RhcnQsXG4gICAgICAgIHNjcmlwdEhhc2gsXG4gICAgICAgIHN0YXJ0ZWRCZWZvcmUsXG4gICAgICAgIHN0YXJ0ZWRBZnRlcixcbiAgICAgICAgc3VjY2VzcyxcbiAgICAgICAgam9iS2luZHMsXG4gICAgICAgIHN1c3BlbmRlZCxcbiAgICAgICAgcnVubmluZyxcbiAgICAgICAgYXJncyxcbiAgICAgICAgcmVzdWx0LFxuICAgICAgICB0YWcsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG9yZGVyIGJ5IGRlc2Mgb3JkZXIgKGRlZmF1bHQgdHJ1ZSlcbiAgICAgICAgICovXG4gICAgICAgIG9yZGVyRGVzYz86IGJvb2xlYW4sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBtYXNrIHRvIGZpbHRlciBleGFjdCBtYXRjaGluZyB1c2VyIGNyZWF0b3JcbiAgICAgICAgICovXG4gICAgICAgIGNyZWF0ZWRCeT86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZSBwYXJlbnQgam9iIHRoYXQgaXMgYXQgdGhlIG9yaWdpbiBhbmQgcmVzcG9uc2libGUgZm9yIHRoZSBleGVjdXRpb24gb2YgdGhpcyBzY3JpcHQgaWYgYW55XG4gICAgICAgICAqL1xuICAgICAgICBwYXJlbnRKb2I/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBtYXNrIHRvIGZpbHRlciBleGFjdCBtYXRjaGluZyBwYXRoXG4gICAgICAgICAqL1xuICAgICAgICBzY3JpcHRQYXRoRXhhY3Q/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBtYXNrIHRvIGZpbHRlciBtYXRjaGluZyBzdGFydGluZyBwYXRoXG4gICAgICAgICAqL1xuICAgICAgICBzY3JpcHRQYXRoU3RhcnQ/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBtYXNrIHRvIGZpbHRlciBleGFjdCBtYXRjaGluZyBwYXRoXG4gICAgICAgICAqL1xuICAgICAgICBzY3JpcHRIYXNoPzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogZmlsdGVyIG9uIGNyZWF0ZWQgYmVmb3JlIChpbmNsdXNpdmUpIHRpbWVzdGFtcFxuICAgICAgICAgKi9cbiAgICAgICAgc3RhcnRlZEJlZm9yZT86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGZpbHRlciBvbiBjcmVhdGVkIGFmdGVyIChleGNsdXNpdmUpIHRpbWVzdGFtcFxuICAgICAgICAgKi9cbiAgICAgICAgc3RhcnRlZEFmdGVyPzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogZmlsdGVyIG9uIHN1Y2Nlc3NmdWwgam9ic1xuICAgICAgICAgKi9cbiAgICAgICAgc3VjY2Vzcz86IGJvb2xlYW4sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBmaWx0ZXIgb24gam9iIGtpbmQgKHZhbHVlcyAncHJldmlldycsICdzY3JpcHQnLCAnZGVwZW5kZW5jaWVzJywgJ2Zsb3cnKSBzZXBhcmF0ZWQgYnksXG4gICAgICAgICAqL1xuICAgICAgICBqb2JLaW5kcz86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGZpbHRlciBvbiBzdXNwZW5kZWQgam9ic1xuICAgICAgICAgKi9cbiAgICAgICAgc3VzcGVuZGVkPzogYm9vbGVhbixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGZpbHRlciBvbiBydW5uaW5nIGpvYnNcbiAgICAgICAgICovXG4gICAgICAgIHJ1bm5pbmc/OiBib29sZWFuLFxuICAgICAgICAvKipcbiAgICAgICAgICogZmlsdGVyIG9uIGpvYnMgY29udGFpbmluZyB0aG9zZSBhcmdzIGFzIGEganNvbiBzdWJzZXQgKEA+IGluIHBvc3RncmVzKVxuICAgICAgICAgKi9cbiAgICAgICAgYXJncz86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGZpbHRlciBvbiBqb2JzIGNvbnRhaW5pbmcgdGhvc2UgcmVzdWx0IGFzIGEganNvbiBzdWJzZXQgKEA+IGluIHBvc3RncmVzKVxuICAgICAgICAgKi9cbiAgICAgICAgcmVzdWx0Pzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogZmlsdGVyIG9uIGpvYnMgd2l0aCBhIGdpdmVuIHRhZy93b3JrZXIgZ3JvdXBcbiAgICAgICAgICovXG4gICAgICAgIHRhZz86IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8QXJyYXk8UXVldWVkSm9iPj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzL3F1ZXVlL2xpc3QnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAnb3JkZXJfZGVzYyc6IG9yZGVyRGVzYyxcbiAgICAgICAgICAgICAgICAnY3JlYXRlZF9ieSc6IGNyZWF0ZWRCeSxcbiAgICAgICAgICAgICAgICAncGFyZW50X2pvYic6IHBhcmVudEpvYixcbiAgICAgICAgICAgICAgICAnc2NyaXB0X3BhdGhfZXhhY3QnOiBzY3JpcHRQYXRoRXhhY3QsXG4gICAgICAgICAgICAgICAgJ3NjcmlwdF9wYXRoX3N0YXJ0Jzogc2NyaXB0UGF0aFN0YXJ0LFxuICAgICAgICAgICAgICAgICdzY3JpcHRfaGFzaCc6IHNjcmlwdEhhc2gsXG4gICAgICAgICAgICAgICAgJ3N0YXJ0ZWRfYmVmb3JlJzogc3RhcnRlZEJlZm9yZSxcbiAgICAgICAgICAgICAgICAnc3RhcnRlZF9hZnRlcic6IHN0YXJ0ZWRBZnRlcixcbiAgICAgICAgICAgICAgICAnc3VjY2Vzcyc6IHN1Y2Nlc3MsXG4gICAgICAgICAgICAgICAgJ2pvYl9raW5kcyc6IGpvYktpbmRzLFxuICAgICAgICAgICAgICAgICdzdXNwZW5kZWQnOiBzdXNwZW5kZWQsXG4gICAgICAgICAgICAgICAgJ3J1bm5pbmcnOiBydW5uaW5nLFxuICAgICAgICAgICAgICAgICdhcmdzJzogYXJncyxcbiAgICAgICAgICAgICAgICAncmVzdWx0JzogcmVzdWx0LFxuICAgICAgICAgICAgICAgICd0YWcnOiB0YWcsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGFsbCBhdmFpbGFibGUgY29tcGxldGVkIGpvYnNcbiAgICAgKiBAcmV0dXJucyBDb21wbGV0ZWRKb2IgQWxsIGF2YWlsYWJsZSBjb21wbGV0ZWQgam9ic1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RDb21wbGV0ZWRKb2JzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBvcmRlckRlc2MsXG4gICAgICAgIGNyZWF0ZWRCeSxcbiAgICAgICAgcGFyZW50Sm9iLFxuICAgICAgICBzY3JpcHRQYXRoRXhhY3QsXG4gICAgICAgIHNjcmlwdFBhdGhTdGFydCxcbiAgICAgICAgc2NyaXB0SGFzaCxcbiAgICAgICAgc3RhcnRlZEJlZm9yZSxcbiAgICAgICAgc3RhcnRlZEFmdGVyLFxuICAgICAgICBzdWNjZXNzLFxuICAgICAgICBqb2JLaW5kcyxcbiAgICAgICAgYXJncyxcbiAgICAgICAgcmVzdWx0LFxuICAgICAgICB0YWcsXG4gICAgICAgIGlzU2tpcHBlZCxcbiAgICAgICAgaXNGbG93U3RlcCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogb3JkZXIgYnkgZGVzYyBvcmRlciAoZGVmYXVsdCB0cnVlKVxuICAgICAgICAgKi9cbiAgICAgICAgb3JkZXJEZXNjPzogYm9vbGVhbixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIGV4YWN0IG1hdGNoaW5nIHVzZXIgY3JlYXRvclxuICAgICAgICAgKi9cbiAgICAgICAgY3JlYXRlZEJ5Pzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIHBhcmVudCBqb2IgdGhhdCBpcyBhdCB0aGUgb3JpZ2luIGFuZCByZXNwb25zaWJsZSBmb3IgdGhlIGV4ZWN1dGlvbiBvZiB0aGlzIHNjcmlwdCBpZiBhbnlcbiAgICAgICAgICovXG4gICAgICAgIHBhcmVudEpvYj86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIGV4YWN0IG1hdGNoaW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHNjcmlwdFBhdGhFeGFjdD86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIG1hdGNoaW5nIHN0YXJ0aW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHNjcmlwdFBhdGhTdGFydD86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIGV4YWN0IG1hdGNoaW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHNjcmlwdEhhc2g/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBmaWx0ZXIgb24gY3JlYXRlZCBiZWZvcmUgKGluY2x1c2l2ZSkgdGltZXN0YW1wXG4gICAgICAgICAqL1xuICAgICAgICBzdGFydGVkQmVmb3JlPzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogZmlsdGVyIG9uIGNyZWF0ZWQgYWZ0ZXIgKGV4Y2x1c2l2ZSkgdGltZXN0YW1wXG4gICAgICAgICAqL1xuICAgICAgICBzdGFydGVkQWZ0ZXI/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBmaWx0ZXIgb24gc3VjY2Vzc2Z1bCBqb2JzXG4gICAgICAgICAqL1xuICAgICAgICBzdWNjZXNzPzogYm9vbGVhbixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGZpbHRlciBvbiBqb2Iga2luZCAodmFsdWVzICdwcmV2aWV3JywgJ3NjcmlwdCcsICdkZXBlbmRlbmNpZXMnLCAnZmxvdycpIHNlcGFyYXRlZCBieSxcbiAgICAgICAgICovXG4gICAgICAgIGpvYktpbmRzPzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogZmlsdGVyIG9uIGpvYnMgY29udGFpbmluZyB0aG9zZSBhcmdzIGFzIGEganNvbiBzdWJzZXQgKEA+IGluIHBvc3RncmVzKVxuICAgICAgICAgKi9cbiAgICAgICAgYXJncz86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGZpbHRlciBvbiBqb2JzIGNvbnRhaW5pbmcgdGhvc2UgcmVzdWx0IGFzIGEganNvbiBzdWJzZXQgKEA+IGluIHBvc3RncmVzKVxuICAgICAgICAgKi9cbiAgICAgICAgcmVzdWx0Pzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogZmlsdGVyIG9uIGpvYnMgd2l0aCBhIGdpdmVuIHRhZy93b3JrZXIgZ3JvdXBcbiAgICAgICAgICovXG4gICAgICAgIHRhZz86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGlzIHRoZSBqb2Igc2tpcHBlZFxuICAgICAgICAgKi9cbiAgICAgICAgaXNTa2lwcGVkPzogYm9vbGVhbixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGlzIHRoZSBqb2IgYSBmbG93IHN0ZXBcbiAgICAgICAgICovXG4gICAgICAgIGlzRmxvd1N0ZXA/OiBib29sZWFuLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxDb21wbGV0ZWRKb2I+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2pvYnMvY29tcGxldGVkL2xpc3QnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAnb3JkZXJfZGVzYyc6IG9yZGVyRGVzYyxcbiAgICAgICAgICAgICAgICAnY3JlYXRlZF9ieSc6IGNyZWF0ZWRCeSxcbiAgICAgICAgICAgICAgICAncGFyZW50X2pvYic6IHBhcmVudEpvYixcbiAgICAgICAgICAgICAgICAnc2NyaXB0X3BhdGhfZXhhY3QnOiBzY3JpcHRQYXRoRXhhY3QsXG4gICAgICAgICAgICAgICAgJ3NjcmlwdF9wYXRoX3N0YXJ0Jzogc2NyaXB0UGF0aFN0YXJ0LFxuICAgICAgICAgICAgICAgICdzY3JpcHRfaGFzaCc6IHNjcmlwdEhhc2gsXG4gICAgICAgICAgICAgICAgJ3N0YXJ0ZWRfYmVmb3JlJzogc3RhcnRlZEJlZm9yZSxcbiAgICAgICAgICAgICAgICAnc3RhcnRlZF9hZnRlcic6IHN0YXJ0ZWRBZnRlcixcbiAgICAgICAgICAgICAgICAnc3VjY2Vzcyc6IHN1Y2Nlc3MsXG4gICAgICAgICAgICAgICAgJ2pvYl9raW5kcyc6IGpvYktpbmRzLFxuICAgICAgICAgICAgICAgICdhcmdzJzogYXJncyxcbiAgICAgICAgICAgICAgICAncmVzdWx0JzogcmVzdWx0LFxuICAgICAgICAgICAgICAgICd0YWcnOiB0YWcsXG4gICAgICAgICAgICAgICAgJ2lzX3NraXBwZWQnOiBpc1NraXBwZWQsXG4gICAgICAgICAgICAgICAgJ2lzX2Zsb3dfc3RlcCc6IGlzRmxvd1N0ZXAsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGFsbCBhdmFpbGFibGUgam9ic1xuICAgICAqIEByZXR1cm5zIEpvYiBBbGwgam9ic1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RKb2JzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBjcmVhdGVkQnksXG4gICAgICAgIHBhcmVudEpvYixcbiAgICAgICAgc2NyaXB0UGF0aEV4YWN0LFxuICAgICAgICBzY3JpcHRQYXRoU3RhcnQsXG4gICAgICAgIHNjcmlwdEhhc2gsXG4gICAgICAgIHN0YXJ0ZWRCZWZvcmUsXG4gICAgICAgIHN0YXJ0ZWRBZnRlcixcbiAgICAgICAgam9iS2luZHMsXG4gICAgICAgIGFyZ3MsXG4gICAgICAgIHRhZyxcbiAgICAgICAgcmVzdWx0LFxuICAgICAgICBpc1NraXBwZWQsXG4gICAgICAgIGlzRmxvd1N0ZXAsXG4gICAgICAgIHN1Y2Nlc3MsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIGV4YWN0IG1hdGNoaW5nIHVzZXIgY3JlYXRvclxuICAgICAgICAgKi9cbiAgICAgICAgY3JlYXRlZEJ5Pzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogVGhlIHBhcmVudCBqb2IgdGhhdCBpcyBhdCB0aGUgb3JpZ2luIGFuZCByZXNwb25zaWJsZSBmb3IgdGhlIGV4ZWN1dGlvbiBvZiB0aGlzIHNjcmlwdCBpZiBhbnlcbiAgICAgICAgICovXG4gICAgICAgIHBhcmVudEpvYj86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIGV4YWN0IG1hdGNoaW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHNjcmlwdFBhdGhFeGFjdD86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIG1hdGNoaW5nIHN0YXJ0aW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHNjcmlwdFBhdGhTdGFydD86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIGV4YWN0IG1hdGNoaW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHNjcmlwdEhhc2g/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBmaWx0ZXIgb24gY3JlYXRlZCBiZWZvcmUgKGluY2x1c2l2ZSkgdGltZXN0YW1wXG4gICAgICAgICAqL1xuICAgICAgICBzdGFydGVkQmVmb3JlPzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogZmlsdGVyIG9uIGNyZWF0ZWQgYWZ0ZXIgKGV4Y2x1c2l2ZSkgdGltZXN0YW1wXG4gICAgICAgICAqL1xuICAgICAgICBzdGFydGVkQWZ0ZXI/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBmaWx0ZXIgb24gam9iIGtpbmQgKHZhbHVlcyAncHJldmlldycsICdzY3JpcHQnLCAnZGVwZW5kZW5jaWVzJywgJ2Zsb3cnKSBzZXBhcmF0ZWQgYnksXG4gICAgICAgICAqL1xuICAgICAgICBqb2JLaW5kcz86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGZpbHRlciBvbiBqb2JzIGNvbnRhaW5pbmcgdGhvc2UgYXJncyBhcyBhIGpzb24gc3Vic2V0IChAPiBpbiBwb3N0Z3JlcylcbiAgICAgICAgICovXG4gICAgICAgIGFyZ3M/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBmaWx0ZXIgb24gam9icyB3aXRoIGEgZ2l2ZW4gdGFnL3dvcmtlciBncm91cFxuICAgICAgICAgKi9cbiAgICAgICAgdGFnPzogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogZmlsdGVyIG9uIGpvYnMgY29udGFpbmluZyB0aG9zZSByZXN1bHQgYXMgYSBqc29uIHN1YnNldCAoQD4gaW4gcG9zdGdyZXMpXG4gICAgICAgICAqL1xuICAgICAgICByZXN1bHQ/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBpcyB0aGUgam9iIHNraXBwZWRcbiAgICAgICAgICovXG4gICAgICAgIGlzU2tpcHBlZD86IGJvb2xlYW4sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBpcyB0aGUgam9iIGEgZmxvdyBzdGVwXG4gICAgICAgICAqL1xuICAgICAgICBpc0Zsb3dTdGVwPzogYm9vbGVhbixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGZpbHRlciBvbiBzdWNjZXNzZnVsIGpvYnNcbiAgICAgICAgICovXG4gICAgICAgIHN1Y2Nlc3M/OiBib29sZWFuLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxKb2I+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2pvYnMvbGlzdCcsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdjcmVhdGVkX2J5JzogY3JlYXRlZEJ5LFxuICAgICAgICAgICAgICAgICdwYXJlbnRfam9iJzogcGFyZW50Sm9iLFxuICAgICAgICAgICAgICAgICdzY3JpcHRfcGF0aF9leGFjdCc6IHNjcmlwdFBhdGhFeGFjdCxcbiAgICAgICAgICAgICAgICAnc2NyaXB0X3BhdGhfc3RhcnQnOiBzY3JpcHRQYXRoU3RhcnQsXG4gICAgICAgICAgICAgICAgJ3NjcmlwdF9oYXNoJzogc2NyaXB0SGFzaCxcbiAgICAgICAgICAgICAgICAnc3RhcnRlZF9iZWZvcmUnOiBzdGFydGVkQmVmb3JlLFxuICAgICAgICAgICAgICAgICdzdGFydGVkX2FmdGVyJzogc3RhcnRlZEFmdGVyLFxuICAgICAgICAgICAgICAgICdqb2Jfa2luZHMnOiBqb2JLaW5kcyxcbiAgICAgICAgICAgICAgICAnYXJncyc6IGFyZ3MsXG4gICAgICAgICAgICAgICAgJ3RhZyc6IHRhZyxcbiAgICAgICAgICAgICAgICAncmVzdWx0JzogcmVzdWx0LFxuICAgICAgICAgICAgICAgICdpc19za2lwcGVkJzogaXNTa2lwcGVkLFxuICAgICAgICAgICAgICAgICdpc19mbG93X3N0ZXAnOiBpc0Zsb3dTdGVwLFxuICAgICAgICAgICAgICAgICdzdWNjZXNzJzogc3VjY2VzcyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBqb2JcbiAgICAgKiBAcmV0dXJucyBKb2Igam9iIGRldGFpbHNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRKb2Ioe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIGlkLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGlkOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPEpvYj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzX3UvZ2V0L3tpZH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2lkJzogaWQsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgam9iIHVwZGF0ZXNcbiAgICAgKiBAcmV0dXJucyBhbnkgam9iIGRldGFpbHNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRKb2JVcGRhdGVzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBpZCxcbiAgICAgICAgcnVubmluZyxcbiAgICAgICAgbG9nT2Zmc2V0LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGlkOiBzdHJpbmcsXG4gICAgICAgIHJ1bm5pbmc/OiBib29sZWFuLFxuICAgICAgICBsb2dPZmZzZXQ/OiBudW1iZXIsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHtcbiAgICAgICAgcnVubmluZz86IGJvb2xlYW47XG4gICAgICAgIGNvbXBsZXRlZD86IGJvb2xlYW47XG4gICAgICAgIG5ld19sb2dzPzogc3RyaW5nO1xuICAgICAgICBtZW1fcGVhaz86IG51bWJlcjtcbiAgICB9PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2pvYnNfdS9nZXR1cGRhdGUve2lkfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAnaWQnOiBpZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdydW5uaW5nJzogcnVubmluZyxcbiAgICAgICAgICAgICAgICAnbG9nX29mZnNldCc6IGxvZ09mZnNldCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBjb21wbGV0ZWQgam9iXG4gICAgICogQHJldHVybnMgQ29tcGxldGVkSm9iIGpvYiBkZXRhaWxzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0Q29tcGxldGVkSm9iKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBpZCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBpZDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxDb21wbGV0ZWRKb2I+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vam9icy9jb21wbGV0ZWQvZ2V0L3tpZH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2lkJzogaWQsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgY29tcGxldGVkIGpvYiByZXN1bHRcbiAgICAgKiBAcmV0dXJucyBhbnkgcmVzdWx0XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0Q29tcGxldGVkSm9iUmVzdWx0KHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBpZCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBpZDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxhbnk+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vam9icy9jb21wbGV0ZWQvZ2V0X3Jlc3VsdC97aWR9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdpZCc6IGlkLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlIGNvbXBsZXRlZCBqb2IgKGVyYXNlIGNvbnRlbnQgYnV0IGtlZXAgcnVuIGlkKVxuICAgICAqIEByZXR1cm5zIENvbXBsZXRlZEpvYiBqb2IgZGV0YWlsc1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGRlbGV0ZUNvbXBsZXRlZEpvYih7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgaWQsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgaWQ6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8Q29tcGxldGVkSm9iPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzL2NvbXBsZXRlZC9kZWxldGUve2lkfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAnaWQnOiBpZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNhbmNlbCBxdWV1ZWQgam9iXG4gICAgICogQHJldHVybnMgc3RyaW5nIGpvYiBjYW5jZWxlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGNhbmNlbFF1ZXVlZEpvYih7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgaWQsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGlkOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiByZWFzb25cbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICByZWFzb24/OiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vam9ic191L3F1ZXVlL2NhbmNlbC97aWR9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdpZCc6IGlkLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGZvcmNlIGNhbmNlbCBxdWV1ZWQgam9iXG4gICAgICogQHJldHVybnMgc3RyaW5nIGpvYiBjYW5jZWxlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGZvcmNlQ2FuY2VsUXVldWVkSm9iKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBpZCxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgaWQ6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHJlYXNvblxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIHJlYXNvbj86IHN0cmluZztcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzX3UvcXVldWUvZm9yY2VfY2FuY2VsL3tpZH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2lkJzogaWQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY3JlYXRlIGFuIEhNYWMgc2lnbmF0dXJlIGdpdmVuIGEgam9iIGlkIGFuZCBhIHJlc3VtZSBpZFxuICAgICAqIEByZXR1cm5zIHN0cmluZyBqb2Igc2lnbmF0dXJlXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgY3JlYXRlSm9iU2lnbmF0dXJlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBpZCxcbiAgICAgICAgcmVzdW1lSWQsXG4gICAgICAgIGFwcHJvdmVyLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGlkOiBzdHJpbmcsXG4gICAgICAgIHJlc3VtZUlkOiBudW1iZXIsXG4gICAgICAgIGFwcHJvdmVyPzogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vam9icy9qb2Jfc2lnbmF0dXJlL3tpZH0ve3Jlc3VtZV9pZH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2lkJzogaWQsXG4gICAgICAgICAgICAgICAgJ3Jlc3VtZV9pZCc6IHJlc3VtZUlkLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ2FwcHJvdmVyJzogYXBwcm92ZXIsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgcmVzdW1lIHVybHMgZ2l2ZW4gYSBqb2JfaWQsIHJlc3VtZV9pZCBhbmQgYSBub25jZSB0byByZXN1bWUgYSBmbG93XG4gICAgICogQHJldHVybnMgYW55IHVybCBlbmRwb2ludHNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRSZXN1bWVVcmxzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBpZCxcbiAgICAgICAgcmVzdW1lSWQsXG4gICAgICAgIGFwcHJvdmVyLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGlkOiBzdHJpbmcsXG4gICAgICAgIHJlc3VtZUlkOiBudW1iZXIsXG4gICAgICAgIGFwcHJvdmVyPzogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTx7XG4gICAgICAgIGFwcHJvdmFsUGFnZTogc3RyaW5nO1xuICAgICAgICByZXN1bWU6IHN0cmluZztcbiAgICAgICAgY2FuY2VsOiBzdHJpbmc7XG4gICAgfT4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzL3Jlc3VtZV91cmxzL3tpZH0ve3Jlc3VtZV9pZH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2lkJzogaWQsXG4gICAgICAgICAgICAgICAgJ3Jlc3VtZV9pZCc6IHJlc3VtZUlkLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ2FwcHJvdmVyJzogYXBwcm92ZXIsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiByZXN1bWUgYSBqb2IgZm9yIGEgc3VzcGVuZGVkIGZsb3dcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgam9iIHJlc3VtZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyByZXN1bWVTdXNwZW5kZWRKb2JHZXQoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIGlkLFxuICAgICAgICByZXN1bWVJZCxcbiAgICAgICAgc2lnbmF0dXJlLFxuICAgICAgICBwYXlsb2FkLFxuICAgICAgICBhcHByb3ZlcixcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBpZDogc3RyaW5nLFxuICAgICAgICByZXN1bWVJZDogbnVtYmVyLFxuICAgICAgICBzaWduYXR1cmU6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFRoZSBiYXNlNjQgZW5jb2RlZCBwYXlsb2FkIHRoYXQgaGFzIGJlZW4gZW5jb2RlZCBhcyBhIEpTT04uIGUuZyBob3cgdG8gZW5jb2RlIHN1Y2ggcGF5bG9hZCBlbmNvZGVVUklDb21wb25lbnRcbiAgICAgICAgICogYGVuY29kZVVSSUNvbXBvbmVudChidG9hKEpTT04uc3RyaW5naWZ5KHthOiAyfSkpKWBcbiAgICAgICAgICpcbiAgICAgICAgICovXG4gICAgICAgIHBheWxvYWQ/OiBzdHJpbmcsXG4gICAgICAgIGFwcHJvdmVyPzogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vam9ic191L3Jlc3VtZS97aWR9L3tyZXN1bWVfaWR9L3tzaWduYXR1cmV9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdpZCc6IGlkLFxuICAgICAgICAgICAgICAgICdyZXN1bWVfaWQnOiByZXN1bWVJZCxcbiAgICAgICAgICAgICAgICAnc2lnbmF0dXJlJzogc2lnbmF0dXJlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ3BheWxvYWQnOiBwYXlsb2FkLFxuICAgICAgICAgICAgICAgICdhcHByb3Zlcic6IGFwcHJvdmVyLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcmVzdW1lIGEgam9iIGZvciBhIHN1c3BlbmRlZCBmbG93XG4gICAgICogQHJldHVybnMgc3RyaW5nIGpvYiByZXN1bWVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcmVzdW1lU3VzcGVuZGVkSm9iUG9zdCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgaWQsXG4gICAgICAgIHJlc3VtZUlkLFxuICAgICAgICBzaWduYXR1cmUsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgICAgICBhcHByb3ZlcixcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBpZDogc3RyaW5nLFxuICAgICAgICByZXN1bWVJZDogbnVtYmVyLFxuICAgICAgICBzaWduYXR1cmU6IHN0cmluZyxcbiAgICAgICAgcmVxdWVzdEJvZHk6IGFueSxcbiAgICAgICAgYXBwcm92ZXI/OiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vam9ic191L3Jlc3VtZS97aWR9L3tyZXN1bWVfaWR9L3tzaWduYXR1cmV9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdpZCc6IGlkLFxuICAgICAgICAgICAgICAgICdyZXN1bWVfaWQnOiByZXN1bWVJZCxcbiAgICAgICAgICAgICAgICAnc2lnbmF0dXJlJzogc2lnbmF0dXJlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ2FwcHJvdmVyJzogYXBwcm92ZXIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcmVzdW1lIGEgam9iIGZvciBhIHN1c3BlbmRlZCBmbG93IGFzIGFuIG93bmVyXG4gICAgICogQHJldHVybnMgc3RyaW5nIGpvYiByZXN1bWVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcmVzdW1lU3VzcGVuZGVkRmxvd0FzT3duZXIoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIGlkLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBpZDogc3RyaW5nLFxuICAgICAgICByZXF1ZXN0Qm9keTogYW55LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2pvYnMvZmxvdy9yZXN1bWUve2lkfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAnaWQnOiBpZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjYW5jZWwgYSBqb2IgZm9yIGEgc3VzcGVuZGVkIGZsb3dcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgam9iIHJlc3VtZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBjYW5jZWxTdXNwZW5kZWRKb2JHZXQoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIGlkLFxuICAgICAgICByZXN1bWVJZCxcbiAgICAgICAgc2lnbmF0dXJlLFxuICAgICAgICBhcHByb3ZlcixcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBpZDogc3RyaW5nLFxuICAgICAgICByZXN1bWVJZDogbnVtYmVyLFxuICAgICAgICBzaWduYXR1cmU6IHN0cmluZyxcbiAgICAgICAgYXBwcm92ZXI/OiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9qb2JzX3UvY2FuY2VsL3tpZH0ve3Jlc3VtZV9pZH0ve3NpZ25hdHVyZX0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2lkJzogaWQsXG4gICAgICAgICAgICAgICAgJ3Jlc3VtZV9pZCc6IHJlc3VtZUlkLFxuICAgICAgICAgICAgICAgICdzaWduYXR1cmUnOiBzaWduYXR1cmUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAnYXBwcm92ZXInOiBhcHByb3ZlcixcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNhbmNlbCBhIGpvYiBmb3IgYSBzdXNwZW5kZWQgZmxvd1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBqb2IgcmVzdW1lZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGNhbmNlbFN1c3BlbmRlZEpvYlBvc3Qoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIGlkLFxuICAgICAgICByZXN1bWVJZCxcbiAgICAgICAgc2lnbmF0dXJlLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICAgICAgYXBwcm92ZXIsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgaWQ6IHN0cmluZyxcbiAgICAgICAgcmVzdW1lSWQ6IG51bWJlcixcbiAgICAgICAgc2lnbmF0dXJlOiBzdHJpbmcsXG4gICAgICAgIHJlcXVlc3RCb2R5OiBhbnksXG4gICAgICAgIGFwcHJvdmVyPzogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2pvYnNfdS9jYW5jZWwve2lkfS97cmVzdW1lX2lkfS97c2lnbmF0dXJlfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAnaWQnOiBpZCxcbiAgICAgICAgICAgICAgICAncmVzdW1lX2lkJzogcmVzdW1lSWQsXG4gICAgICAgICAgICAgICAgJ3NpZ25hdHVyZSc6IHNpZ25hdHVyZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdhcHByb3Zlcic6IGFwcHJvdmVyLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBwYXJlbnQgZmxvdyBqb2Igb2Ygc3VzcGVuZGVkIGpvYlxuICAgICAqIEByZXR1cm5zIGFueSBwYXJlbnQgZmxvdyBkZXRhaWxzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0U3VzcGVuZGVkSm9iRmxvdyh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgaWQsXG4gICAgICAgIHJlc3VtZUlkLFxuICAgICAgICBzaWduYXR1cmUsXG4gICAgICAgIGFwcHJvdmVyLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGlkOiBzdHJpbmcsXG4gICAgICAgIHJlc3VtZUlkOiBudW1iZXIsXG4gICAgICAgIHNpZ25hdHVyZTogc3RyaW5nLFxuICAgICAgICBhcHByb3Zlcj86IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8e1xuICAgICAgICBqb2I6IEpvYjtcbiAgICAgICAgYXBwcm92ZXJzOiBBcnJheTx7XG4gICAgICAgICAgICByZXN1bWVfaWQ6IG51bWJlcjtcbiAgICAgICAgICAgIGFwcHJvdmVyOiBzdHJpbmc7XG4gICAgICAgIH0+O1xuICAgIH0+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vam9ic191L2dldF9mbG93L3tpZH0ve3Jlc3VtZV9pZH0ve3NpZ25hdHVyZX0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2lkJzogaWQsXG4gICAgICAgICAgICAgICAgJ3Jlc3VtZV9pZCc6IHJlc3VtZUlkLFxuICAgICAgICAgICAgICAgICdzaWduYXR1cmUnOiBzaWduYXR1cmUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAnYXBwcm92ZXInOiBhcHByb3ZlcixcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCLEdBU2xCLFNBQVMsT0FBTyxRQUFRLHFCQUFxQjtBQUM3QyxTQUFTLFdBQVcsU0FBUyxRQUFRLHFCQUFxQjtBQUUxRCxPQUFPLE1BQU07RUFFVDs7OztLQUlDLEdBQ0QsT0FBYyxnQkFBZ0IsRUFDMUIsU0FBUyxFQUNULElBQUksRUFDSixXQUFXLEVBQ1gsWUFBWSxFQUNaLGVBQWUsRUFDZixTQUFTLEVBQ1QsZ0JBQWdCLEVBd0JuQixFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO01BQ0EsT0FBTztRQUNILGlCQUFpQjtRQUNqQixxQkFBcUI7UUFDckIsY0FBYztRQUNkLHNCQUFzQjtNQUMxQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLDBCQUEwQixFQUNwQyxTQUFTLEVBQ1QsSUFBSSxFQUNKLFdBQVcsRUFDWCxTQUFTLEVBQ1QsYUFBYSxFQUNiLFVBQVUsRUF1QmIsRUFBMEI7SUFDdkIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtNQUNBLE9BQU87UUFDSCxjQUFjO1FBQ2Qsa0JBQWtCO1FBQ2xCLGVBQWU7TUFDbkI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyw2QkFBNkIsRUFDdkMsU0FBUyxFQUNULElBQUksRUFDSixTQUFTLEVBQ1QsYUFBYSxFQUNiLFVBQVUsRUFDVixPQUFPLEVBeUJWLEVBQTBCO0lBQ3ZCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7TUFDQSxPQUFPO1FBQ0gsY0FBYztRQUNkLGtCQUFrQjtRQUNsQixlQUFlO1FBQ2YsV0FBVztNQUNmO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLHdCQUF3QixFQUNsQyxTQUFTLEVBQ1QsSUFBSSxFQUNKLFdBQVcsRUFDWCxhQUFhLEVBQ2IsVUFBVSxFQW1CYixFQUEwQjtJQUN2QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO01BQ0EsT0FBTztRQUNILGtCQUFrQjtRQUNsQixlQUFlO01BQ25CO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsV0FBVyxFQUNyQixTQUFTLEVBQ1QsU0FBUyxFQUNULE1BQU0sRUFLVCxFQUEwQjtJQUN2QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsZUFBZTtRQUNmLFdBQVc7TUFDZjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxjQUFjLEVBQ3hCLFNBQVMsRUFDVCxJQUFJLEVBQ0osV0FBVyxFQUNYLFlBQVksRUFDWixlQUFlLEVBQ2YsU0FBUyxFQUNULGFBQWEsRUFDYixnQkFBZ0IsRUE4Qm5CLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7TUFDQSxPQUFPO1FBQ0gsaUJBQWlCO1FBQ2pCLHFCQUFxQjtRQUNyQixjQUFjO1FBQ2Qsa0JBQWtCO1FBQ2xCLHNCQUFzQjtNQUMxQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGdCQUFnQixFQUMxQixTQUFTLEVBQ1QsSUFBSSxFQUNKLFdBQVcsRUFDWCxZQUFZLEVBQ1osZUFBZSxFQUNmLFNBQVMsRUFDVCxhQUFhLEVBQ2IsZ0JBQWdCLEVBOEJuQixFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO01BQ0EsT0FBTztRQUNILGlCQUFpQjtRQUNqQixxQkFBcUI7UUFDckIsY0FBYztRQUNkLGtCQUFrQjtRQUNsQixzQkFBc0I7TUFDMUI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxpQkFBaUIsRUFDM0IsU0FBUyxFQUNULFdBQVcsRUFDWCxhQUFhLEVBQ2IsZ0JBQWdCLEVBaUJuQixFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsT0FBTztRQUNILGtCQUFrQjtRQUNsQixzQkFBc0I7TUFDMUI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxlQUFlLEVBQ3pCLFNBQVMsRUFDVCxXQUFXLEVBQ1gsYUFBYSxFQUNiLGdCQUFnQixFQWlCbkIsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE9BQU87UUFDSCxrQkFBa0I7UUFDbEIsc0JBQXNCO01BQzFCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsVUFBVSxFQUNwQixTQUFTLEVBQ1QsU0FBUyxFQUNULFNBQVMsRUFDVCxTQUFTLEVBQ1QsZUFBZSxFQUNmLGVBQWUsRUFDZixVQUFVLEVBQ1YsYUFBYSxFQUNiLFlBQVksRUFDWixPQUFPLEVBQ1AsUUFBUSxFQUNSLFNBQVMsRUFDVCxPQUFPLEVBQ1AsSUFBSSxFQUNKLE1BQU0sRUFDTixHQUFHLEVBK0ROLEVBQXVDO0lBQ3BDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxPQUFPO1FBQ0gsY0FBYztRQUNkLGNBQWM7UUFDZCxjQUFjO1FBQ2QscUJBQXFCO1FBQ3JCLHFCQUFxQjtRQUNyQixlQUFlO1FBQ2Ysa0JBQWtCO1FBQ2xCLGlCQUFpQjtRQUNqQixXQUFXO1FBQ1gsYUFBYTtRQUNiLGFBQWE7UUFDYixXQUFXO1FBQ1gsUUFBUTtRQUNSLFVBQVU7UUFDVixPQUFPO01BQ1g7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsa0JBQWtCLEVBQzVCLFNBQVMsRUFDVCxTQUFTLEVBQ1QsU0FBUyxFQUNULFNBQVMsRUFDVCxlQUFlLEVBQ2YsZUFBZSxFQUNmLFVBQVUsRUFDVixhQUFhLEVBQ2IsWUFBWSxFQUNaLE9BQU8sRUFDUCxRQUFRLEVBQ1IsSUFBSSxFQUNKLE1BQU0sRUFDTixHQUFHLEVBQ0gsU0FBUyxFQUNULFVBQVUsRUErRGIsRUFBMEM7SUFDdkMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE9BQU87UUFDSCxjQUFjO1FBQ2QsY0FBYztRQUNkLGNBQWM7UUFDZCxxQkFBcUI7UUFDckIscUJBQXFCO1FBQ3JCLGVBQWU7UUFDZixrQkFBa0I7UUFDbEIsaUJBQWlCO1FBQ2pCLFdBQVc7UUFDWCxhQUFhO1FBQ2IsUUFBUTtRQUNSLFVBQVU7UUFDVixPQUFPO1FBQ1AsY0FBYztRQUNkLGdCQUFnQjtNQUNwQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxTQUFTLEVBQ25CLFNBQVMsRUFDVCxTQUFTLEVBQ1QsU0FBUyxFQUNULGVBQWUsRUFDZixlQUFlLEVBQ2YsVUFBVSxFQUNWLGFBQWEsRUFDYixZQUFZLEVBQ1osUUFBUSxFQUNSLElBQUksRUFDSixHQUFHLEVBQ0gsTUFBTSxFQUNOLFNBQVMsRUFDVCxVQUFVLEVBQ1YsT0FBTyxFQTJEVixFQUFpQztJQUM5QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsT0FBTztRQUNILGNBQWM7UUFDZCxjQUFjO1FBQ2QscUJBQXFCO1FBQ3JCLHFCQUFxQjtRQUNyQixlQUFlO1FBQ2Ysa0JBQWtCO1FBQ2xCLGlCQUFpQjtRQUNqQixhQUFhO1FBQ2IsUUFBUTtRQUNSLE9BQU87UUFDUCxVQUFVO1FBQ1YsY0FBYztRQUNkLGdCQUFnQjtRQUNoQixXQUFXO01BQ2Y7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsT0FBTyxFQUNqQixTQUFTLEVBQ1QsRUFBRSxFQUlMLEVBQTBCO0lBQ3ZCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixNQUFNO01BQ1Y7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsY0FBYyxFQUN4QixTQUFTLEVBQ1QsRUFBRSxFQUNGLE9BQU8sRUFDUCxTQUFTLEVBTVosRUFLRTtJQUNDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixNQUFNO01BQ1Y7TUFDQSxPQUFPO1FBQ0gsV0FBVztRQUNYLGNBQWM7TUFDbEI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZ0JBQWdCLEVBQzFCLFNBQVMsRUFDVCxFQUFFLEVBSUwsRUFBbUM7SUFDaEMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLE1BQU07TUFDVjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxzQkFBc0IsRUFDaEMsU0FBUyxFQUNULEVBQUUsRUFJTCxFQUEwQjtJQUN2QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsTUFBTTtNQUNWO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG1CQUFtQixFQUM3QixTQUFTLEVBQ1QsRUFBRSxFQUlMLEVBQW1DO0lBQ2hDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixNQUFNO01BQ1Y7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZ0JBQWdCLEVBQzFCLFNBQVMsRUFDVCxFQUFFLEVBQ0YsV0FBVyxFQVVkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixNQUFNO01BQ1Y7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxxQkFBcUIsRUFDL0IsU0FBUyxFQUNULEVBQUUsRUFDRixXQUFXLEVBVWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLE1BQU07TUFDVjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG1CQUFtQixFQUM3QixTQUFTLEVBQ1QsRUFBRSxFQUNGLFFBQVEsRUFDUixRQUFRLEVBTVgsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLE1BQU07UUFDTixhQUFhO01BQ2pCO01BQ0EsT0FBTztRQUNILFlBQVk7TUFDaEI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsY0FBYyxFQUN4QixTQUFTLEVBQ1QsRUFBRSxFQUNGLFFBQVEsRUFDUixRQUFRLEVBTVgsRUFJRTtJQUNDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixNQUFNO1FBQ04sYUFBYTtNQUNqQjtNQUNBLE9BQU87UUFDSCxZQUFZO01BQ2hCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLHNCQUFzQixFQUNoQyxTQUFTLEVBQ1QsRUFBRSxFQUNGLFFBQVEsRUFDUixTQUFTLEVBQ1QsT0FBTyxFQUNQLFFBQVEsRUFhWCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsTUFBTTtRQUNOLGFBQWE7UUFDYixhQUFhO01BQ2pCO01BQ0EsT0FBTztRQUNILFdBQVc7UUFDWCxZQUFZO01BQ2hCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLHVCQUF1QixFQUNqQyxTQUFTLEVBQ1QsRUFBRSxFQUNGLFFBQVEsRUFDUixTQUFTLEVBQ1QsV0FBVyxFQUNYLFFBQVEsRUFRWCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsTUFBTTtRQUNOLGFBQWE7UUFDYixhQUFhO01BQ2pCO01BQ0EsT0FBTztRQUNILFlBQVk7TUFDaEI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYywyQkFBMkIsRUFDckMsU0FBUyxFQUNULEVBQUUsRUFDRixXQUFXLEVBS2QsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLE1BQU07TUFDVjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLHNCQUFzQixFQUNoQyxTQUFTLEVBQ1QsRUFBRSxFQUNGLFFBQVEsRUFDUixTQUFTLEVBQ1QsUUFBUSxFQU9YLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixNQUFNO1FBQ04sYUFBYTtRQUNiLGFBQWE7TUFDakI7TUFDQSxPQUFPO1FBQ0gsWUFBWTtNQUNoQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyx1QkFBdUIsRUFDakMsU0FBUyxFQUNULEVBQUUsRUFDRixRQUFRLEVBQ1IsU0FBUyxFQUNULFdBQVcsRUFDWCxRQUFRLEVBUVgsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLE1BQU07UUFDTixhQUFhO1FBQ2IsYUFBYTtNQUNqQjtNQUNBLE9BQU87UUFDSCxZQUFZO01BQ2hCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsb0JBQW9CLEVBQzlCLFNBQVMsRUFDVCxFQUFFLEVBQ0YsUUFBUSxFQUNSLFNBQVMsRUFDVCxRQUFRLEVBT1gsRUFNRTtJQUNDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixNQUFNO1FBQ04sYUFBYTtRQUNiLGFBQWE7TUFDakI7TUFDQSxPQUFPO1FBQ0gsWUFBWTtNQUNoQjtJQUNKO0VBQ0o7QUFFSiJ9
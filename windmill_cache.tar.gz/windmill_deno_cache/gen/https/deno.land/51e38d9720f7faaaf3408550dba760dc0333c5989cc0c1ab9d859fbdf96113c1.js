/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class UserService {
  /**
     * login with password
     * @returns string Successfully authenticated. The session ID is returned in a cookie named `token` and as plaintext response. Preferred method of authorization is through the bearer token. The cookie is only for browser convenience.
     *
     * @throws ApiError
     */ static login({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/auth/login',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * logout
     * @returns string clear cookies and clear token (if applicable)
     * @throws ApiError
     */ static logout() {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/auth/logout'
    });
  }
  /**
     * create user (require admin privilege)
     * @returns string user created
     * @throws ApiError
     */ static createUser({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/users/add',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * update user (require admin privilege)
     * @returns string edited user
     * @throws ApiError
     */ static updateUser({ workspace, username, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/users/update/{username}',
      path: {
        'workspace': workspace,
        'username': username
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * is owner of path
     * @returns boolean is owner
     * @throws ApiError
     */ static isOwnerOfPath({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/users/is_owner/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * set password
     * @returns string password set
     * @throws ApiError
     */ static setPassword({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/users/setpassword',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * create user
     * @returns string user created
     * @throws ApiError
     */ static createUserGlobally({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/users/create',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * global update user (require super admin)
     * @returns string user updated
     * @throws ApiError
     */ static globalUserUpdate({ email, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/users/update/{email}',
      path: {
        'email': email
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * global delete user (require super admin)
     * @returns string user deleted
     * @throws ApiError
     */ static globalUserDelete({ email }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/users/delete/{email}',
      path: {
        'email': email
      }
    });
  }
  /**
     * delete user (require admin privilege)
     * @returns string delete user
     * @throws ApiError
     */ static deleteUser({ workspace, username }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/w/{workspace}/users/delete/{username}',
      path: {
        'workspace': workspace,
        'username': username
      }
    });
  }
  /**
     * get current user email (if logged in)
     * @returns string user email
     * @throws ApiError
     */ static getCurrentEmail() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/users/email'
    });
  }
  /**
     * get current usage outside of premium workspaces
     * @returns number free usage
     * @throws ApiError
     */ static getUsage() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/users/usage'
    });
  }
  /**
     * get current global whoami (if logged in)
     * @returns GlobalUserInfo user email
     * @throws ApiError
     */ static globalWhoami() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/users/whoami'
    });
  }
  /**
     * list all workspace invites
     * @returns WorkspaceInvite list all workspace invites
     * @throws ApiError
     */ static listWorkspaceInvites() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/users/list_invites'
    });
  }
  /**
     * whoami
     * @returns User user
     * @throws ApiError
     */ static whoami({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/users/whoami',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * leave workspace
     * @returns string status
     * @throws ApiError
     */ static leaveWorkspace({ workspace }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/users/leave_workspace',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * accept invite to workspace
     * @returns string status
     * @throws ApiError
     */ static acceptInvite({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/users/accept_invite',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * decline invite to workspace
     * @returns string status
     * @throws ApiError
     */ static declineInvite({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/users/decline_invite',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * whois
     * @returns User user
     * @throws ApiError
     */ static whois({ workspace, username }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/users/whois/{username}',
      path: {
        'workspace': workspace,
        'username': username
      }
    });
  }
  /**
     * list all users as super admin (require to be super amdin)
     * @returns GlobalUserInfo user
     * @throws ApiError
     */ static listUsersAsSuperAdmin({ page, perPage }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/users/list_as_super_admin',
      query: {
        'page': page,
        'per_page': perPage
      }
    });
  }
  /**
     * list users
     * @returns User user
     * @throws ApiError
     */ static listUsers({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/users/list',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * list usernames
     * @returns string user
     * @throws ApiError
     */ static listUsernames({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/users/list_usernames',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * create token
     * @returns string token created
     * @throws ApiError
     */ static createToken({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/users/tokens/create',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * create token to impersonate a user (require superadmin)
     * @returns string token created
     * @throws ApiError
     */ static createTokenImpersonate({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/users/tokens/impersonate',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete token
     * @returns string delete token
     * @throws ApiError
     */ static deleteToken({ tokenPrefix }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/users/tokens/delete/{token_prefix}',
      path: {
        'token_prefix': tokenPrefix
      }
    });
  }
  /**
     * list token
     * @returns TruncatedToken truncated token
     * @throws ApiError
     */ static listTokens() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/users/tokens/list'
    });
  }
  /**
     * login with oauth authorization flow
     * @returns string Successfully authenticated. The session ID is returned in a cookie named `token` and as plaintext response. Preferred method of authorization is through the bearer token. The cookie is only for browser convenience.
     *
     * @throws ApiError
     */ static loginWithOauth({ clientName, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/oauth/login_callback/{client_name}',
      path: {
        'client_name': clientName
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvVXNlclNlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogaXN0YW5idWwgaWdub3JlIGZpbGUgKi9cbi8qIHRzbGludDpkaXNhYmxlICovXG4vKiBlc2xpbnQtZGlzYWJsZSAqL1xuaW1wb3J0IHR5cGUgeyBFZGl0V29ya3NwYWNlVXNlciB9IGZyb20gJy4uL21vZGVscy9FZGl0V29ya3NwYWNlVXNlci50cyc7XG5pbXBvcnQgdHlwZSB7IEdsb2JhbFVzZXJJbmZvIH0gZnJvbSAnLi4vbW9kZWxzL0dsb2JhbFVzZXJJbmZvLnRzJztcbmltcG9ydCB0eXBlIHsgTG9naW4gfSBmcm9tICcuLi9tb2RlbHMvTG9naW4udHMnO1xuaW1wb3J0IHR5cGUgeyBOZXdUb2tlbiB9IGZyb20gJy4uL21vZGVscy9OZXdUb2tlbi50cyc7XG5pbXBvcnQgdHlwZSB7IE5ld1Rva2VuSW1wZXJzb25hdGUgfSBmcm9tICcuLi9tb2RlbHMvTmV3VG9rZW5JbXBlcnNvbmF0ZS50cyc7XG5pbXBvcnQgdHlwZSB7IE5ld1VzZXIgfSBmcm9tICcuLi9tb2RlbHMvTmV3VXNlci50cyc7XG5pbXBvcnQgdHlwZSB7IFRydW5jYXRlZFRva2VuIH0gZnJvbSAnLi4vbW9kZWxzL1RydW5jYXRlZFRva2VuLnRzJztcbmltcG9ydCB0eXBlIHsgVXNlciB9IGZyb20gJy4uL21vZGVscy9Vc2VyLnRzJztcbmltcG9ydCB0eXBlIHsgV29ya3NwYWNlSW52aXRlIH0gZnJvbSAnLi4vbW9kZWxzL1dvcmtzcGFjZUludml0ZS50cyc7XG5cbmltcG9ydCB0eXBlIHsgQ2FuY2VsYWJsZVByb21pc2UgfSBmcm9tICcuLi9jb3JlL0NhbmNlbGFibGVQcm9taXNlLnRzJztcbmltcG9ydCB7IE9wZW5BUEkgfSBmcm9tICcuLi9jb3JlL09wZW5BUEkudHMnO1xuaW1wb3J0IHsgcmVxdWVzdCBhcyBfX3JlcXVlc3QgfSBmcm9tICcuLi9jb3JlL3JlcXVlc3QudHMnO1xuXG5leHBvcnQgY2xhc3MgVXNlclNlcnZpY2Uge1xuXG4gICAgLyoqXG4gICAgICogbG9naW4gd2l0aCBwYXNzd29yZFxuICAgICAqIEByZXR1cm5zIHN0cmluZyBTdWNjZXNzZnVsbHkgYXV0aGVudGljYXRlZC4gVGhlIHNlc3Npb24gSUQgaXMgcmV0dXJuZWQgaW4gYSBjb29raWUgbmFtZWQgYHRva2VuYCBhbmQgYXMgcGxhaW50ZXh0IHJlc3BvbnNlLiBQcmVmZXJyZWQgbWV0aG9kIG9mIGF1dGhvcml6YXRpb24gaXMgdGhyb3VnaCB0aGUgYmVhcmVyIHRva2VuLiBUaGUgY29va2llIGlzIG9ubHkgZm9yIGJyb3dzZXIgY29udmVuaWVuY2UuXG4gICAgICpcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBsb2dpbih7XG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGNyZWRlbnRpYWxzXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogTG9naW4sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL2F1dGgvbG9naW4nLFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbG9nb3V0XG4gICAgICogQHJldHVybnMgc3RyaW5nIGNsZWFyIGNvb2tpZXMgYW5kIGNsZWFyIHRva2VuIChpZiBhcHBsaWNhYmxlKVxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxvZ291dCgpOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy9hdXRoL2xvZ291dCcsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNyZWF0ZSB1c2VyIChyZXF1aXJlIGFkbWluIHByaXZpbGVnZSlcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgdXNlciBjcmVhdGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgY3JlYXRlVXNlcih7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG5ldyB1c2VyXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogTmV3VXNlcixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS91c2Vycy9hZGQnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogdXBkYXRlIHVzZXIgKHJlcXVpcmUgYWRtaW4gcHJpdmlsZWdlKVxuICAgICAqIEByZXR1cm5zIHN0cmluZyBlZGl0ZWQgdXNlclxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVwZGF0ZVVzZXIoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHVzZXJuYW1lLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICB1c2VybmFtZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogbmV3IHVzZXJcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiBFZGl0V29ya3NwYWNlVXNlcixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS91c2Vycy91cGRhdGUve3VzZXJuYW1lfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAndXNlcm5hbWUnOiB1c2VybmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBpcyBvd25lciBvZiBwYXRoXG4gICAgICogQHJldHVybnMgYm9vbGVhbiBpcyBvd25lclxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGlzT3duZXJPZlBhdGgoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxib29sZWFuPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3VzZXJzL2lzX293bmVyL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBzZXQgcGFzc3dvcmRcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgcGFzc3dvcmQgc2V0XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgc2V0UGFzc3dvcmQoe1xuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBzZXQgcGFzc3dvcmRcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBwYXNzd29yZDogc3RyaW5nO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy91c2Vycy9zZXRwYXNzd29yZCcsXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjcmVhdGUgdXNlclxuICAgICAqIEByZXR1cm5zIHN0cmluZyB1c2VyIGNyZWF0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGVVc2VyR2xvYmFsbHkoe1xuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB1c2VyIGluZm9cbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBlbWFpbDogc3RyaW5nO1xuICAgICAgICAgICAgcGFzc3dvcmQ6IHN0cmluZztcbiAgICAgICAgICAgIHN1cGVyX2FkbWluOiBib29sZWFuO1xuICAgICAgICAgICAgbmFtZT86IHN0cmluZztcbiAgICAgICAgICAgIGNvbXBhbnk/OiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3VzZXJzL2NyZWF0ZScsXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnbG9iYWwgdXBkYXRlIHVzZXIgKHJlcXVpcmUgc3VwZXIgYWRtaW4pXG4gICAgICogQHJldHVybnMgc3RyaW5nIHVzZXIgdXBkYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdsb2JhbFVzZXJVcGRhdGUoe1xuICAgICAgICBlbWFpbCxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICBlbWFpbDogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogbmV3IHVzZXIgaW5mb1xuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIGlzX3N1cGVyX2FkbWluPzogYm9vbGVhbjtcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdXNlcnMvdXBkYXRlL3tlbWFpbH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICdlbWFpbCc6IGVtYWlsLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdsb2JhbCBkZWxldGUgdXNlciAocmVxdWlyZSBzdXBlciBhZG1pbilcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgdXNlciBkZWxldGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2xvYmFsVXNlckRlbGV0ZSh7XG4gICAgICAgIGVtYWlsLFxuICAgIH06IHtcbiAgICAgICAgZW1haWw6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgICAgICAgIHVybDogJy91c2Vycy9kZWxldGUve2VtYWlsfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ2VtYWlsJzogZW1haWwsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBkZWxldGUgdXNlciAocmVxdWlyZSBhZG1pbiBwcml2aWxlZ2UpXG4gICAgICogQHJldHVybnMgc3RyaW5nIGRlbGV0ZSB1c2VyXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZGVsZXRlVXNlcih7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgdXNlcm5hbWUsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgdXNlcm5hbWU6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3VzZXJzL2RlbGV0ZS97dXNlcm5hbWV9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICd1c2VybmFtZSc6IHVzZXJuYW1lLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZ2V0IGN1cnJlbnQgdXNlciBlbWFpbCAoaWYgbG9nZ2VkIGluKVxuICAgICAqIEByZXR1cm5zIHN0cmluZyB1c2VyIGVtYWlsXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0Q3VycmVudEVtYWlsKCk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdXNlcnMvZW1haWwnLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgY3VycmVudCB1c2FnZSBvdXRzaWRlIG9mIHByZW1pdW0gd29ya3NwYWNlc1xuICAgICAqIEByZXR1cm5zIG51bWJlciBmcmVlIHVzYWdlXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0VXNhZ2UoKTogQ2FuY2VsYWJsZVByb21pc2U8bnVtYmVyPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy91c2Vycy91c2FnZScsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBjdXJyZW50IGdsb2JhbCB3aG9hbWkgKGlmIGxvZ2dlZCBpbilcbiAgICAgKiBAcmV0dXJucyBHbG9iYWxVc2VySW5mbyB1c2VyIGVtYWlsXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2xvYmFsV2hvYW1pKCk6IENhbmNlbGFibGVQcm9taXNlPEdsb2JhbFVzZXJJbmZvPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy91c2Vycy93aG9hbWknLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGFsbCB3b3Jrc3BhY2UgaW52aXRlc1xuICAgICAqIEByZXR1cm5zIFdvcmtzcGFjZUludml0ZSBsaXN0IGFsbCB3b3Jrc3BhY2UgaW52aXRlc1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RXb3Jrc3BhY2VJbnZpdGVzKCk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PFdvcmtzcGFjZUludml0ZT4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3VzZXJzL2xpc3RfaW52aXRlcycsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHdob2FtaVxuICAgICAqIEByZXR1cm5zIFVzZXIgdXNlclxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHdob2FtaSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxVc2VyPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3VzZXJzL3dob2FtaScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxlYXZlIHdvcmtzcGFjZVxuICAgICAqIEByZXR1cm5zIHN0cmluZyBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBsZWF2ZVdvcmtzcGFjZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3VzZXJzL2xlYXZlX3dvcmtzcGFjZScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGFjY2VwdCBpbnZpdGUgdG8gd29ya3NwYWNlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHN0YXR1c1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGFjY2VwdEludml0ZSh7XG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGFjY2VwdCBpbnZpdGVcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICB3b3Jrc3BhY2VfaWQ6IHN0cmluZztcbiAgICAgICAgICAgIHVzZXJuYW1lOiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3VzZXJzL2FjY2VwdF9pbnZpdGUnLFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVjbGluZSBpbnZpdGUgdG8gd29ya3NwYWNlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHN0YXR1c1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGRlY2xpbmVJbnZpdGUoe1xuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBkZWNsaW5lIGludml0ZVxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIHdvcmtzcGFjZV9pZDogc3RyaW5nO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy91c2Vycy9kZWNsaW5lX2ludml0ZScsXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiB3aG9pc1xuICAgICAqIEByZXR1cm5zIFVzZXIgdXNlclxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHdob2lzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICB1c2VybmFtZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICB1c2VybmFtZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxVc2VyPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3VzZXJzL3dob2lzL3t1c2VybmFtZX0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3VzZXJuYW1lJzogdXNlcm5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGFsbCB1c2VycyBhcyBzdXBlciBhZG1pbiAocmVxdWlyZSB0byBiZSBzdXBlciBhbWRpbilcbiAgICAgKiBAcmV0dXJucyBHbG9iYWxVc2VySW5mbyB1c2VyXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdFVzZXJzQXNTdXBlckFkbWluKHtcbiAgICAgICAgcGFnZSxcbiAgICAgICAgcGVyUGFnZSxcbiAgICB9OiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB3aGljaCBwYWdlIHRvIHJldHVybiAoc3RhcnQgYXQgMSwgZGVmYXVsdCAxKVxuICAgICAgICAgKi9cbiAgICAgICAgcGFnZT86IG51bWJlcixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG51bWJlciBvZiBpdGVtcyB0byByZXR1cm4gZm9yIGEgZ2l2ZW4gcGFnZSAoZGVmYXVsdCAzMCwgbWF4IDEwMClcbiAgICAgICAgICovXG4gICAgICAgIHBlclBhZ2U/OiBudW1iZXIsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PEdsb2JhbFVzZXJJbmZvPj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdXNlcnMvbGlzdF9hc19zdXBlcl9hZG1pbicsXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdwYWdlJzogcGFnZSxcbiAgICAgICAgICAgICAgICAncGVyX3BhZ2UnOiBwZXJQYWdlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbGlzdCB1c2Vyc1xuICAgICAqIEByZXR1cm5zIFVzZXIgdXNlclxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RVc2Vycyh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxVc2VyPj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS91c2Vycy9saXN0JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbGlzdCB1c2VybmFtZXNcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgdXNlclxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RVc2VybmFtZXMoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8QXJyYXk8c3RyaW5nPj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS91c2Vycy9saXN0X3VzZXJuYW1lcycsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNyZWF0ZSB0b2tlblxuICAgICAqIEByZXR1cm5zIHN0cmluZyB0b2tlbiBjcmVhdGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgY3JlYXRlVG9rZW4oe1xuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBuZXcgdG9rZW5cbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiBOZXdUb2tlbixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdXNlcnMvdG9rZW5zL2NyZWF0ZScsXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjcmVhdGUgdG9rZW4gdG8gaW1wZXJzb25hdGUgYSB1c2VyIChyZXF1aXJlIHN1cGVyYWRtaW4pXG4gICAgICogQHJldHVybnMgc3RyaW5nIHRva2VuIGNyZWF0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGVUb2tlbkltcGVyc29uYXRlKHtcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICAvKipcbiAgICAgICAgICogbmV3IHRva2VuXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogTmV3VG9rZW5JbXBlcnNvbmF0ZSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdXNlcnMvdG9rZW5zL2ltcGVyc29uYXRlJyxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGRlbGV0ZSB0b2tlblxuICAgICAqIEByZXR1cm5zIHN0cmluZyBkZWxldGUgdG9rZW5cbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkZWxldGVUb2tlbih7XG4gICAgICAgIHRva2VuUHJlZml4LFxuICAgIH06IHtcbiAgICAgICAgdG9rZW5QcmVmaXg6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgICAgICAgIHVybDogJy91c2Vycy90b2tlbnMvZGVsZXRlL3t0b2tlbl9wcmVmaXh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAndG9rZW5fcHJlZml4JzogdG9rZW5QcmVmaXgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IHRva2VuXG4gICAgICogQHJldHVybnMgVHJ1bmNhdGVkVG9rZW4gdHJ1bmNhdGVkIHRva2VuXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdFRva2VucygpOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxUcnVuY2F0ZWRUb2tlbj4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3VzZXJzL3Rva2Vucy9saXN0JyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbG9naW4gd2l0aCBvYXV0aCBhdXRob3JpemF0aW9uIGZsb3dcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgU3VjY2Vzc2Z1bGx5IGF1dGhlbnRpY2F0ZWQuIFRoZSBzZXNzaW9uIElEIGlzIHJldHVybmVkIGluIGEgY29va2llIG5hbWVkIGB0b2tlbmAgYW5kIGFzIHBsYWludGV4dCByZXNwb25zZS4gUHJlZmVycmVkIG1ldGhvZCBvZiBhdXRob3JpemF0aW9uIGlzIHRocm91Z2ggdGhlIGJlYXJlciB0b2tlbi4gVGhlIGNvb2tpZSBpcyBvbmx5IGZvciBicm93c2VyIGNvbnZlbmllbmNlLlxuICAgICAqXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbG9naW5XaXRoT2F1dGgoe1xuICAgICAgICBjbGllbnROYW1lLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIGNsaWVudE5hbWU6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhcnRpYWxseSBmaWxsZWQgc2NyaXB0XG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keToge1xuICAgICAgICAgICAgY29kZT86IHN0cmluZztcbiAgICAgICAgICAgIHN0YXRlPzogc3RyaW5nO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy9vYXV0aC9sb2dpbl9jYWxsYmFjay97Y2xpZW50X25hbWV9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnY2xpZW50X25hbWUnOiBjbGllbnROYW1lLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCLEdBWWxCLFNBQVMsT0FBTyxRQUFRLHFCQUFxQjtBQUM3QyxTQUFTLFdBQVcsU0FBUyxRQUFRLHFCQUFxQjtBQUUxRCxPQUFPLE1BQU07RUFFVDs7Ozs7S0FLQyxHQUNELE9BQWMsTUFBTSxFQUNoQixXQUFXLEVBTWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxTQUFvQztJQUM5QyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztJQUNUO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxXQUFXLEVBQ3JCLFNBQVMsRUFDVCxXQUFXLEVBT2QsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFdBQVcsRUFDckIsU0FBUyxFQUNULFFBQVEsRUFDUixXQUFXLEVBUWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFlBQVk7TUFDaEI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxjQUFjLEVBQ3hCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBOEI7SUFDM0IsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxZQUFZLEVBQ3RCLFdBQVcsRUFRZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG1CQUFtQixFQUM3QixXQUFXLEVBWWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxpQkFBaUIsRUFDM0IsS0FBSyxFQUNMLFdBQVcsRUFTZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixTQUFTO01BQ2I7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxpQkFBaUIsRUFDM0IsS0FBSyxFQUdSLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLFNBQVM7TUFDYjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxXQUFXLEVBQ3JCLFNBQVMsRUFDVCxRQUFRLEVBSVgsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFlBQVk7TUFDaEI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsa0JBQTZDO0lBQ3ZELE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO0lBQ1Q7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFdBQXNDO0lBQ2hELE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO0lBQ1Q7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWtEO0lBQzVELE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO0lBQ1Q7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLHVCQUFrRTtJQUM1RSxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztJQUNUO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxPQUFPLEVBQ2pCLFNBQVMsRUFHWixFQUEyQjtJQUN4QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsU0FBUyxFQUdaLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsYUFBYSxFQUN2QixXQUFXLEVBU2QsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxjQUFjLEVBQ3hCLFdBQVcsRUFRZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLE1BQU0sRUFDaEIsU0FBUyxFQUNULFFBQVEsRUFJWCxFQUEyQjtJQUN4QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsWUFBWTtNQUNoQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxzQkFBc0IsRUFDaEMsSUFBSSxFQUNKLE9BQU8sRUFVVixFQUE0QztJQUN6QyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE9BQU87UUFDSCxRQUFRO1FBQ1IsWUFBWTtNQUNoQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxVQUFVLEVBQ3BCLFNBQVMsRUFHWixFQUFrQztJQUMvQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGNBQWMsRUFDeEIsU0FBUyxFQUdaLEVBQW9DO0lBQ2pDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsWUFBWSxFQUN0QixXQUFXLEVBTWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyx1QkFBdUIsRUFDakMsV0FBVyxFQU1kLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsWUFBWSxFQUN0QixXQUFXLEVBR2QsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsZ0JBQWdCO01BQ3BCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGFBQXVEO0lBQ2pFLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO0lBQ1Q7RUFDSjtFQUVBOzs7OztLQUtDLEdBQ0QsT0FBYyxlQUFlLEVBQ3pCLFVBQVUsRUFDVixXQUFXLEVBVWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsZUFBZTtNQUNuQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtBQUVKIn0=
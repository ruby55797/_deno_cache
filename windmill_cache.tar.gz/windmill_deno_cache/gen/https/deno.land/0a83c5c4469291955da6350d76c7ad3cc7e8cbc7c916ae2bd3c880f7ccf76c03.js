/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ export var RunnableType;
(function(RunnableType) {
  RunnableType["SCRIPT_HASH"] = "ScriptHash";
  RunnableType["SCRIPT_PATH"] = "ScriptPath";
  RunnableType["FLOW_PATH"] = "FlowPath";
})(RunnableType || (RunnableType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvbW9kZWxzL1J1bm5hYmxlVHlwZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5cbmV4cG9ydCBlbnVtIFJ1bm5hYmxlVHlwZSB7XG4gICAgU0NSSVBUX0hBU0ggPSAnU2NyaXB0SGFzaCcsXG4gICAgU0NSSVBUX1BBVEggPSAnU2NyaXB0UGF0aCcsXG4gICAgRkxPV19QQVRIID0gJ0Zsb3dQYXRoJyxcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQjtVQUVOOzs7O0dBQUEsaUJBQUEifQ==
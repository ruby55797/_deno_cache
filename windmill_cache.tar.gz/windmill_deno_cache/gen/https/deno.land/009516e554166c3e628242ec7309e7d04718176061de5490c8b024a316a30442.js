/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class CaptureService {
  /**
     * update flow preview capture
     * @returns void
     * @throws ApiError
     */ static updateCapture({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/capture_u/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * create flow preview capture
     * @returns any flow preview capture created
     * @throws ApiError
     */ static createCapture({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'PUT',
      url: '/w/{workspace}/capture/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * get flow preview capture
     * @returns any captured flow preview
     * @throws ApiError
     */ static getCapture({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/capture/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      errors: {
        404: `capture does not exist for this flow`
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvQ2FwdHVyZVNlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogaXN0YW5idWwgaWdub3JlIGZpbGUgKi9cbi8qIHRzbGludDpkaXNhYmxlICovXG4vKiBlc2xpbnQtZGlzYWJsZSAqL1xuaW1wb3J0IHR5cGUgeyBDYW5jZWxhYmxlUHJvbWlzZSB9IGZyb20gJy4uL2NvcmUvQ2FuY2VsYWJsZVByb21pc2UudHMnO1xuaW1wb3J0IHsgT3BlbkFQSSB9IGZyb20gJy4uL2NvcmUvT3BlbkFQSS50cyc7XG5pbXBvcnQgeyByZXF1ZXN0IGFzIF9fcmVxdWVzdCB9IGZyb20gJy4uL2NvcmUvcmVxdWVzdC50cyc7XG5cbmV4cG9ydCBjbGFzcyBDYXB0dXJlU2VydmljZSB7XG5cbiAgICAvKipcbiAgICAgKiB1cGRhdGUgZmxvdyBwcmV2aWV3IGNhcHR1cmVcbiAgICAgKiBAcmV0dXJucyB2b2lkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgdXBkYXRlQ2FwdHVyZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHZvaWQ+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2NhcHR1cmVfdS97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY3JlYXRlIGZsb3cgcHJldmlldyBjYXB0dXJlXG4gICAgICogQHJldHVybnMgYW55IGZsb3cgcHJldmlldyBjYXB0dXJlIGNyZWF0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGVDYXB0dXJlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8YW55PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2NhcHR1cmUve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBmbG93IHByZXZpZXcgY2FwdHVyZVxuICAgICAqIEByZXR1cm5zIGFueSBjYXB0dXJlZCBmbG93IHByZXZpZXdcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRDYXB0dXJlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8YW55PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2NhcHR1cmUve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcnM6IHtcbiAgICAgICAgICAgICAgICA0MDQ6IGBjYXB0dXJlIGRvZXMgbm90IGV4aXN0IGZvciB0aGlzIGZsb3dgLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsd0JBQXdCLEdBQ3hCLGtCQUFrQixHQUNsQixrQkFBa0IsR0FFbEIsU0FBUyxPQUFPLFFBQVEscUJBQXFCO0FBQzdDLFNBQVMsV0FBVyxTQUFTLFFBQVEscUJBQXFCO0FBRTFELE9BQU8sTUFBTTtFQUVUOzs7O0tBSUMsR0FDRCxPQUFjLGNBQWMsRUFDeEIsU0FBUyxFQUNULElBQUksRUFJUCxFQUEyQjtJQUN4QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGNBQWMsRUFDeEIsU0FBUyxFQUNULElBQUksRUFJUCxFQUEwQjtJQUN2QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFdBQVcsRUFDckIsU0FBUyxFQUNULElBQUksRUFJUCxFQUEwQjtJQUN2QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO01BQ0EsUUFBUTtRQUNKLEtBQUssQ0FBQyxvQ0FBb0MsQ0FBQztNQUMvQztJQUNKO0VBQ0o7QUFFSiJ9
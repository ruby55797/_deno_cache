/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class WorkerService {
  /**
     * get all instance custom tags (tags are used to dispatch jobs to different worker groups)
     * @returns string list of custom tags
     * @throws ApiError
     */ static getCustomTags() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/workers/custom_tags'
    });
  }
  /**
     * list workers
     * @returns WorkerPing a list of workers
     * @throws ApiError
     */ static listWorkers({ page, perPage }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/workers/list',
      query: {
        'page': page,
        'per_page': perPage
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvV29ya2VyU2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5pbXBvcnQgdHlwZSB7IFdvcmtlclBpbmcgfSBmcm9tICcuLi9tb2RlbHMvV29ya2VyUGluZy50cyc7XG5cbmltcG9ydCB0eXBlIHsgQ2FuY2VsYWJsZVByb21pc2UgfSBmcm9tICcuLi9jb3JlL0NhbmNlbGFibGVQcm9taXNlLnRzJztcbmltcG9ydCB7IE9wZW5BUEkgfSBmcm9tICcuLi9jb3JlL09wZW5BUEkudHMnO1xuaW1wb3J0IHsgcmVxdWVzdCBhcyBfX3JlcXVlc3QgfSBmcm9tICcuLi9jb3JlL3JlcXVlc3QudHMnO1xuXG5leHBvcnQgY2xhc3MgV29ya2VyU2VydmljZSB7XG5cbiAgICAvKipcbiAgICAgKiBnZXQgYWxsIGluc3RhbmNlIGN1c3RvbSB0YWdzICh0YWdzIGFyZSB1c2VkIHRvIGRpc3BhdGNoIGpvYnMgdG8gZGlmZmVyZW50IHdvcmtlciBncm91cHMpXG4gICAgICogQHJldHVybnMgc3RyaW5nIGxpc3Qgb2YgY3VzdG9tIHRhZ3NcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRDdXN0b21UYWdzKCk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PHN0cmluZz4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3dvcmtlcnMvY3VzdG9tX3RhZ3MnLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IHdvcmtlcnNcbiAgICAgKiBAcmV0dXJucyBXb3JrZXJQaW5nIGEgbGlzdCBvZiB3b3JrZXJzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdFdvcmtlcnMoe1xuICAgICAgICBwYWdlLFxuICAgICAgICBwZXJQYWdlLFxuICAgIH06IHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHdoaWNoIHBhZ2UgdG8gcmV0dXJuIChzdGFydCBhdCAxLCBkZWZhdWx0IDEpXG4gICAgICAgICAqL1xuICAgICAgICBwYWdlPzogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogbnVtYmVyIG9mIGl0ZW1zIHRvIHJldHVybiBmb3IgYSBnaXZlbiBwYWdlIChkZWZhdWx0IDMwLCBtYXggMTAwKVxuICAgICAgICAgKi9cbiAgICAgICAgcGVyUGFnZT86IG51bWJlcixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8QXJyYXk8V29ya2VyUGluZz4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3dvcmtlcnMvbGlzdCcsXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdwYWdlJzogcGFnZSxcbiAgICAgICAgICAgICAgICAncGVyX3BhZ2UnOiBwZXJQYWdlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsd0JBQXdCLEdBQ3hCLGtCQUFrQixHQUNsQixrQkFBa0IsR0FJbEIsU0FBUyxPQUFPLFFBQVEscUJBQXFCO0FBQzdDLFNBQVMsV0FBVyxTQUFTLFFBQVEscUJBQXFCO0FBRTFELE9BQU8sTUFBTTtFQUVUOzs7O0tBSUMsR0FDRCxPQUFjLGdCQUFrRDtJQUM1RCxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztJQUNUO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxZQUFZLEVBQ3RCLElBQUksRUFDSixPQUFPLEVBVVYsRUFBd0M7SUFDckMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxPQUFPO1FBQ0gsUUFBUTtRQUNSLFlBQVk7TUFDaEI7SUFDSjtFQUNKO0FBRUoifQ==
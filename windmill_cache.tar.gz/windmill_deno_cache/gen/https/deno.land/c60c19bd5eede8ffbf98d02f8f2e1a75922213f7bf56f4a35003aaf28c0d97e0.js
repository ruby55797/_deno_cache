/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ export var RawScript;
(function(RawScript) {
  let language;
  (function(language) {
    language["DENO"] = "deno";
    language["PYTHON3"] = "python3";
    language["GO"] = "go";
    language["BASH"] = "bash";
  })(language = RawScript.language || (RawScript.language = {}));
})(RawScript || (RawScript = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvbW9kZWxzL1Jhd1NjcmlwdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5cbmltcG9ydCB0eXBlIHsgSW5wdXRUcmFuc2Zvcm0gfSBmcm9tICcuL0lucHV0VHJhbnNmb3JtLnRzJztcblxuZXhwb3J0IHR5cGUgUmF3U2NyaXB0ID0ge1xuICAgIGlucHV0X3RyYW5zZm9ybXM6IFJlY29yZDxzdHJpbmcsIElucHV0VHJhbnNmb3JtPjtcbiAgICBjb250ZW50OiBzdHJpbmc7XG4gICAgbGFuZ3VhZ2U6IFJhd1NjcmlwdC5sYW5ndWFnZTtcbiAgICBwYXRoPzogc3RyaW5nO1xuICAgIGxvY2s/OiBzdHJpbmc7XG4gICAgdHlwZTogJ3Jhd3NjcmlwdCc7XG4gICAgdGFnPzogc3RyaW5nO1xufTtcblxuZXhwb3J0IG5hbWVzcGFjZSBSYXdTY3JpcHQge1xuXG4gICAgZXhwb3J0IGVudW0gbGFuZ3VhZ2Uge1xuICAgICAgICBERU5PID0gJ2Rlbm8nLFxuICAgICAgICBQWVRIT04zID0gJ3B5dGhvbjMnLFxuICAgICAgICBHTyA9ICdnbycsXG4gICAgICAgIEJBU0ggPSAnYmFzaCcsXG4gICAgfVxuXG5cbn1cblxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCO1VBY0Q7O1lBRUQ7Ozs7O0tBQUEscUJBQUEsdUJBQUE7QUFRaEIsR0FWaUIsY0FBQSJ9
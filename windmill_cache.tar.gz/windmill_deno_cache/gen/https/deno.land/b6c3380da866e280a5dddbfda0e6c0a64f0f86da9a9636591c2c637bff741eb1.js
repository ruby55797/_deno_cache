/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ export var NewScript;
(function(NewScript) {
  let language;
  (function(language) {
    language["PYTHON3"] = "python3";
    language["DENO"] = "deno";
    language["GO"] = "go";
    language["BASH"] = "bash";
  })(language = NewScript.language || (NewScript.language = {}));
  let kind;
  (function(kind) {
    kind["SCRIPT"] = "script";
    kind["FAILURE"] = "failure";
    kind["TRIGGER"] = "trigger";
    kind["COMMAND"] = "command";
    kind["APPROVAL"] = "approval";
  })(kind = NewScript.kind || (NewScript.kind = {}));
})(NewScript || (NewScript = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvbW9kZWxzL05ld1NjcmlwdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5cbmV4cG9ydCB0eXBlIE5ld1NjcmlwdCA9IHtcbiAgICBwYXRoOiBzdHJpbmc7XG4gICAgcGFyZW50X2hhc2g/OiBzdHJpbmc7XG4gICAgc3VtbWFyeTogc3RyaW5nO1xuICAgIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gICAgY29udGVudDogc3RyaW5nO1xuICAgIHNjaGVtYT86IGFueTtcbiAgICBpc190ZW1wbGF0ZT86IGJvb2xlYW47XG4gICAgbG9jaz86IEFycmF5PHN0cmluZz47XG4gICAgbGFuZ3VhZ2U6IE5ld1NjcmlwdC5sYW5ndWFnZTtcbiAgICBraW5kPzogTmV3U2NyaXB0LmtpbmQ7XG4gICAgdGFnPzogc3RyaW5nO1xuICAgIGRyYWZ0X29ubHk/OiBib29sZWFuO1xufTtcblxuZXhwb3J0IG5hbWVzcGFjZSBOZXdTY3JpcHQge1xuXG4gICAgZXhwb3J0IGVudW0gbGFuZ3VhZ2Uge1xuICAgICAgICBQWVRIT04zID0gJ3B5dGhvbjMnLFxuICAgICAgICBERU5PID0gJ2Rlbm8nLFxuICAgICAgICBHTyA9ICdnbycsXG4gICAgICAgIEJBU0ggPSAnYmFzaCcsXG4gICAgfVxuXG4gICAgZXhwb3J0IGVudW0ga2luZCB7XG4gICAgICAgIFNDUklQVCA9ICdzY3JpcHQnLFxuICAgICAgICBGQUlMVVJFID0gJ2ZhaWx1cmUnLFxuICAgICAgICBUUklHR0VSID0gJ3RyaWdnZXInLFxuICAgICAgICBDT01NQU5EID0gJ2NvbW1hbmQnLFxuICAgICAgICBBUFBST1ZBTCA9ICdhcHByb3ZhbCcsXG4gICAgfVxuXG5cbn1cblxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCO1VBaUJEOztZQUVEOzs7OztLQUFBLHFCQUFBLHVCQUFBOztZQU9BOzs7Ozs7S0FBQSxpQkFBQSxtQkFBQTtBQVNoQixHQWxCaUIsY0FBQSJ9
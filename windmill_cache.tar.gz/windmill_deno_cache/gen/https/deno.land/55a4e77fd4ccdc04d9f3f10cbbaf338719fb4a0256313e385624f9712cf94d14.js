/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class OauthService {
  /**
     * connect slack callback
     * @returns string slack token
     * @throws ApiError
     */ static connectSlackCallback({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/oauth/connect_slack_callback',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * connect callback
     * @returns TokenResponse oauth token
     * @throws ApiError
     */ static connectCallback({ clientName, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/oauth/connect_callback/{client_name}',
      path: {
        'client_name': clientName
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * create OAuth account
     * @returns string account set
     * @throws ApiError
     */ static createAccount({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/oauth/create_account',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * refresh token
     * @returns string token refreshed
     * @throws ApiError
     */ static refreshToken({ workspace, id, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/oauth/refresh_token/{id}',
      path: {
        'workspace': workspace,
        'id': id
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * disconnect account
     * @returns string disconnected client
     * @throws ApiError
     */ static disconnectAccount({ workspace, id }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/oauth/disconnect/{id}',
      path: {
        'workspace': workspace,
        'id': id
      }
    });
  }
  /**
     * disconnect slack
     * @returns string disconnected slack
     * @throws ApiError
     */ static disconnectSlack({ workspace }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/oauth/disconnect_slack',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * list oauth logins
     * @returns string list of oauth login clients
     * @throws ApiError
     */ static listOAuthLogins() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/oauth/list_logins'
    });
  }
  /**
     * list oauth connects
     * @returns any list of oauth connects clients
     * @throws ApiError
     */ static listOAuthConnects() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/oauth/list_connects'
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvT2F1dGhTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgVG9rZW5SZXNwb25zZSB9IGZyb20gJy4uL21vZGVscy9Ub2tlblJlc3BvbnNlLnRzJztcblxuaW1wb3J0IHR5cGUgeyBDYW5jZWxhYmxlUHJvbWlzZSB9IGZyb20gJy4uL2NvcmUvQ2FuY2VsYWJsZVByb21pc2UudHMnO1xuaW1wb3J0IHsgT3BlbkFQSSB9IGZyb20gJy4uL2NvcmUvT3BlbkFQSS50cyc7XG5pbXBvcnQgeyByZXF1ZXN0IGFzIF9fcmVxdWVzdCB9IGZyb20gJy4uL2NvcmUvcmVxdWVzdC50cyc7XG5cbmV4cG9ydCBjbGFzcyBPYXV0aFNlcnZpY2Uge1xuXG4gICAgLyoqXG4gICAgICogY29ubmVjdCBzbGFjayBjYWxsYmFja1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBzbGFjayB0b2tlblxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGNvbm5lY3RTbGFja0NhbGxiYWNrKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogY29kZSBlbmRwb2ludFxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIGNvZGU6IHN0cmluZztcbiAgICAgICAgICAgIHN0YXRlOiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vb2F1dGgvY29ubmVjdF9zbGFja19jYWxsYmFjaycsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjb25uZWN0IGNhbGxiYWNrXG4gICAgICogQHJldHVybnMgVG9rZW5SZXNwb25zZSBvYXV0aCB0b2tlblxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGNvbm5lY3RDYWxsYmFjayh7XG4gICAgICAgIGNsaWVudE5hbWUsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgY2xpZW50TmFtZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogY29kZSBlbmRwb2ludFxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIGNvZGU6IHN0cmluZztcbiAgICAgICAgICAgIHN0YXRlOiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPFRva2VuUmVzcG9uc2U+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy9vYXV0aC9jb25uZWN0X2NhbGxiYWNrL3tjbGllbnRfbmFtZX0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICdjbGllbnRfbmFtZSc6IGNsaWVudE5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY3JlYXRlIE9BdXRoIGFjY291bnRcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgYWNjb3VudCBzZXRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGVBY2NvdW50KHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogY29kZSBlbmRwb2ludFxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIHJlZnJlc2hfdG9rZW4/OiBzdHJpbmc7XG4gICAgICAgICAgICBleHBpcmVzX2luOiBudW1iZXI7XG4gICAgICAgICAgICBvd25lcjogc3RyaW5nO1xuICAgICAgICAgICAgY2xpZW50OiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vb2F1dGgvY3JlYXRlX2FjY291bnQnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcmVmcmVzaCB0b2tlblxuICAgICAqIEByZXR1cm5zIHN0cmluZyB0b2tlbiByZWZyZXNoZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyByZWZyZXNoVG9rZW4oe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIGlkLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBpZDogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogdmFyaWFibGUgcGF0aFxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIHBhdGg6IHN0cmluZztcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9vYXV0aC9yZWZyZXNoX3Rva2VuL3tpZH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2lkJzogaWQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGlzY29ubmVjdCBhY2NvdW50XG4gICAgICogQHJldHVybnMgc3RyaW5nIGRpc2Nvbm5lY3RlZCBjbGllbnRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkaXNjb25uZWN0QWNjb3VudCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgaWQsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgaWQ6IG51bWJlcixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9vYXV0aC9kaXNjb25uZWN0L3tpZH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2lkJzogaWQsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBkaXNjb25uZWN0IHNsYWNrXG4gICAgICogQHJldHVybnMgc3RyaW5nIGRpc2Nvbm5lY3RlZCBzbGFja1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGRpc2Nvbm5lY3RTbGFjayh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L29hdXRoL2Rpc2Nvbm5lY3Rfc2xhY2snLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IG9hdXRoIGxvZ2luc1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBsaXN0IG9mIG9hdXRoIGxvZ2luIGNsaWVudHNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBsaXN0T0F1dGhMb2dpbnMoKTogQ2FuY2VsYWJsZVByb21pc2U8QXJyYXk8c3RyaW5nPj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvb2F1dGgvbGlzdF9sb2dpbnMnLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IG9hdXRoIGNvbm5lY3RzXG4gICAgICogQHJldHVybnMgYW55IGxpc3Qgb2Ygb2F1dGggY29ubmVjdHMgY2xpZW50c1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RPQXV0aENvbm5lY3RzKCk6IENhbmNlbGFibGVQcm9taXNlPGFueT4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvb2F1dGgvbGlzdF9jb25uZWN0cycsXG4gICAgICAgIH0pO1xuICAgIH1cblxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCLEdBSWxCLFNBQVMsT0FBTyxRQUFRLHFCQUFxQjtBQUM3QyxTQUFTLFdBQVcsU0FBUyxRQUFRLHFCQUFxQjtBQUUxRCxPQUFPLE1BQU07RUFFVDs7OztLQUlDLEdBQ0QsT0FBYyxxQkFBcUIsRUFDL0IsU0FBUyxFQUNULFdBQVcsRUFVZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZ0JBQWdCLEVBQzFCLFVBQVUsRUFDVixXQUFXLEVBVWQsRUFBb0M7SUFDakMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsZUFBZTtNQUNuQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGNBQWMsRUFDeEIsU0FBUyxFQUNULFdBQVcsRUFZZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsYUFBYSxFQUN2QixTQUFTLEVBQ1QsRUFBRSxFQUNGLFdBQVcsRUFVZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsTUFBTTtNQUNWO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsa0JBQWtCLEVBQzVCLFNBQVMsRUFDVCxFQUFFLEVBSUwsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLE1BQU07TUFDVjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxnQkFBZ0IsRUFDMUIsU0FBUyxFQUdaLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsa0JBQW9EO0lBQzlELE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO0lBQ1Q7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG9CQUE0QztJQUN0RCxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztJQUNUO0VBQ0o7QUFFSiJ9
/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class SettingsService {
  /**
     * get backend version
     * @returns string git version of backend
     * @throws ApiError
     */ static backendVersion() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/version'
    });
  }
  /**
     * get openapi yaml spec
     * @returns string openapi yaml file content
     * @throws ApiError
     */ static getOpenApiYaml() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/openapi.yaml'
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvU2V0dGluZ3NTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgQ2FuY2VsYWJsZVByb21pc2UgfSBmcm9tICcuLi9jb3JlL0NhbmNlbGFibGVQcm9taXNlLnRzJztcbmltcG9ydCB7IE9wZW5BUEkgfSBmcm9tICcuLi9jb3JlL09wZW5BUEkudHMnO1xuaW1wb3J0IHsgcmVxdWVzdCBhcyBfX3JlcXVlc3QgfSBmcm9tICcuLi9jb3JlL3JlcXVlc3QudHMnO1xuXG5leHBvcnQgY2xhc3MgU2V0dGluZ3NTZXJ2aWNlIHtcblxuICAgIC8qKlxuICAgICAqIGdldCBiYWNrZW5kIHZlcnNpb25cbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgZ2l0IHZlcnNpb24gb2YgYmFja2VuZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGJhY2tlbmRWZXJzaW9uKCk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdmVyc2lvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBvcGVuYXBpIHlhbWwgc3BlY1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBvcGVuYXBpIHlhbWwgZmlsZSBjb250ZW50XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0T3BlbkFwaVlhbWwoKTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy9vcGVuYXBpLnlhbWwnLFxuICAgICAgICB9KTtcbiAgICB9XG5cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQixHQUVsQixTQUFTLE9BQU8sUUFBUSxxQkFBcUI7QUFDN0MsU0FBUyxXQUFXLFNBQVMsUUFBUSxxQkFBcUI7QUFFMUQsT0FBTyxNQUFNO0VBRVQ7Ozs7S0FJQyxHQUNELE9BQWMsaUJBQTRDO0lBQ3RELE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO0lBQ1Q7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGlCQUE0QztJQUN0RCxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztJQUNUO0VBQ0o7QUFFSiJ9
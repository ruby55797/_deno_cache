/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class GranularAclService {
  /**
     * get granular acls
     * @returns boolean acls
     * @throws ApiError
     */ static getGranularAcls({ workspace, path, kind }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/acls/get/{kind}/{path}',
      path: {
        'workspace': workspace,
        'path': path,
        'kind': kind
      }
    });
  }
  /**
     * add granular acls
     * @returns string granular acl added
     * @throws ApiError
     */ static addGranularAcls({ workspace, path, kind, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/acls/add/{kind}/{path}',
      path: {
        'workspace': workspace,
        'path': path,
        'kind': kind
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * remove granular acls
     * @returns string granular acl removed
     * @throws ApiError
     */ static removeGranularAcls({ workspace, path, kind, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/acls/remove/{kind}/{path}',
      path: {
        'workspace': workspace,
        'path': path,
        'kind': kind
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvR3JhbnVsYXJBY2xTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgQ2FuY2VsYWJsZVByb21pc2UgfSBmcm9tICcuLi9jb3JlL0NhbmNlbGFibGVQcm9taXNlLnRzJztcbmltcG9ydCB7IE9wZW5BUEkgfSBmcm9tICcuLi9jb3JlL09wZW5BUEkudHMnO1xuaW1wb3J0IHsgcmVxdWVzdCBhcyBfX3JlcXVlc3QgfSBmcm9tICcuLi9jb3JlL3JlcXVlc3QudHMnO1xuXG5leHBvcnQgY2xhc3MgR3JhbnVsYXJBY2xTZXJ2aWNlIHtcblxuICAgIC8qKlxuICAgICAqIGdldCBncmFudWxhciBhY2xzXG4gICAgICogQHJldHVybnMgYm9vbGVhbiBhY2xzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0R3JhbnVsYXJBY2xzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICBraW5kLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICAgICAga2luZDogJ3NjcmlwdCcgfCAnZ3JvdXBfJyB8ICdyZXNvdXJjZScgfCAnc2NoZWR1bGUnIHwgJ3ZhcmlhYmxlJyB8ICdmbG93JyB8ICdmb2xkZXInIHwgJ2FwcCcgfCAncmF3X2FwcCcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPFJlY29yZDxzdHJpbmcsIGJvb2xlYW4+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2FjbHMvZ2V0L3traW5kfS97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgICAgICdraW5kJzoga2luZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGFkZCBncmFudWxhciBhY2xzXG4gICAgICogQHJldHVybnMgc3RyaW5nIGdyYW51bGFyIGFjbCBhZGRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGFkZEdyYW51bGFyQWNscyh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICAgICAga2luZCxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgICAgICBraW5kOiAnc2NyaXB0JyB8ICdncm91cF8nIHwgJ3Jlc291cmNlJyB8ICdzY2hlZHVsZScgfCAndmFyaWFibGUnIHwgJ2Zsb3cnIHwgJ2ZvbGRlcicgfCAnYXBwJyB8ICdyYXdfYXBwJyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGFjbCB0byBhZGRcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBvd25lcjogc3RyaW5nO1xuICAgICAgICAgICAgd3JpdGU/OiBib29sZWFuO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2FjbHMvYWRkL3traW5kfS97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgICAgICdraW5kJzoga2luZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiByZW1vdmUgZ3JhbnVsYXIgYWNsc1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBncmFudWxhciBhY2wgcmVtb3ZlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJlbW92ZUdyYW51bGFyQWNscyh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICAgICAga2luZCxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgICAgICBraW5kOiAnc2NyaXB0JyB8ICdncm91cF8nIHwgJ3Jlc291cmNlJyB8ICdzY2hlZHVsZScgfCAndmFyaWFibGUnIHwgJ2Zsb3cnIHwgJ2ZvbGRlcicgfCAnYXBwJyB8ICdyYXdfYXBwJyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGFjbCB0byBhZGRcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBvd25lcjogc3RyaW5nO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2FjbHMvcmVtb3ZlL3traW5kfS97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgICAgICdraW5kJzoga2luZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQixHQUVsQixTQUFTLE9BQU8sUUFBUSxxQkFBcUI7QUFDN0MsU0FBUyxXQUFXLFNBQVMsUUFBUSxxQkFBcUI7QUFFMUQsT0FBTyxNQUFNO0VBRVQ7Ozs7S0FJQyxHQUNELE9BQWMsZ0JBQWdCLEVBQzFCLFNBQVMsRUFDVCxJQUFJLEVBQ0osSUFBSSxFQUtQLEVBQThDO0lBQzNDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO1FBQ1IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGdCQUFnQixFQUMxQixTQUFTLEVBQ1QsSUFBSSxFQUNKLElBQUksRUFDSixXQUFXLEVBWWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7UUFDUixRQUFRO01BQ1o7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxtQkFBbUIsRUFDN0IsU0FBUyxFQUNULElBQUksRUFDSixJQUFJLEVBQ0osV0FBVyxFQVdkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO1FBQ1IsUUFBUTtNQUNaO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0FBRUoifQ==
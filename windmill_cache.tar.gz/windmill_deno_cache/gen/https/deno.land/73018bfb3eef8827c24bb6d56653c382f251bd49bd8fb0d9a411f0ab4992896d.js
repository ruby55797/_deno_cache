/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class AdminService {
  /**
     * create user (require admin privilege)
     * @returns string user created
     * @throws ApiError
     */ static createUser({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/users/add',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * update user (require admin privilege)
     * @returns string edited user
     * @throws ApiError
     */ static updateUser({ workspace, username, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/users/update/{username}',
      path: {
        'workspace': workspace,
        'username': username
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete user (require admin privilege)
     * @returns string delete user
     * @throws ApiError
     */ static deleteUser({ workspace, username }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/w/{workspace}/users/delete/{username}',
      path: {
        'workspace': workspace,
        'username': username
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvQWRtaW5TZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgRWRpdFdvcmtzcGFjZVVzZXIgfSBmcm9tICcuLi9tb2RlbHMvRWRpdFdvcmtzcGFjZVVzZXIudHMnO1xuaW1wb3J0IHR5cGUgeyBOZXdVc2VyIH0gZnJvbSAnLi4vbW9kZWxzL05ld1VzZXIudHMnO1xuXG5pbXBvcnQgdHlwZSB7IENhbmNlbGFibGVQcm9taXNlIH0gZnJvbSAnLi4vY29yZS9DYW5jZWxhYmxlUHJvbWlzZS50cyc7XG5pbXBvcnQgeyBPcGVuQVBJIH0gZnJvbSAnLi4vY29yZS9PcGVuQVBJLnRzJztcbmltcG9ydCB7IHJlcXVlc3QgYXMgX19yZXF1ZXN0IH0gZnJvbSAnLi4vY29yZS9yZXF1ZXN0LnRzJztcblxuZXhwb3J0IGNsYXNzIEFkbWluU2VydmljZSB7XG5cbiAgICAvKipcbiAgICAgKiBjcmVhdGUgdXNlciAocmVxdWlyZSBhZG1pbiBwcml2aWxlZ2UpXG4gICAgICogQHJldHVybnMgc3RyaW5nIHVzZXIgY3JlYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGNyZWF0ZVVzZXIoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBuZXcgdXNlclxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IE5ld1VzZXIsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vdXNlcnMvYWRkJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHVwZGF0ZSB1c2VyIChyZXF1aXJlIGFkbWluIHByaXZpbGVnZSlcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgZWRpdGVkIHVzZXJcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyB1cGRhdGVVc2VyKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICB1c2VybmFtZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgdXNlcm5hbWU6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG5ldyB1c2VyXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogRWRpdFdvcmtzcGFjZVVzZXIsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vdXNlcnMvdXBkYXRlL3t1c2VybmFtZX0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3VzZXJuYW1lJzogdXNlcm5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlIHVzZXIgKHJlcXVpcmUgYWRtaW4gcHJpdmlsZWdlKVxuICAgICAqIEByZXR1cm5zIHN0cmluZyBkZWxldGUgdXNlclxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGRlbGV0ZVVzZXIoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHVzZXJuYW1lLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHVzZXJuYW1lOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS91c2Vycy9kZWxldGUve3VzZXJuYW1lfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAndXNlcm5hbWUnOiB1c2VybmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCLEdBS2xCLFNBQVMsT0FBTyxRQUFRLHFCQUFxQjtBQUM3QyxTQUFTLFdBQVcsU0FBUyxRQUFRLHFCQUFxQjtBQUUxRCxPQUFPLE1BQU07RUFFVDs7OztLQUlDLEdBQ0QsT0FBYyxXQUFXLEVBQ3JCLFNBQVMsRUFDVCxXQUFXLEVBT2QsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFdBQVcsRUFDckIsU0FBUyxFQUNULFFBQVEsRUFDUixXQUFXLEVBUWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFlBQVk7TUFDaEI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxXQUFXLEVBQ3JCLFNBQVMsRUFDVCxRQUFRLEVBSVgsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFlBQVk7TUFDaEI7SUFDSjtFQUNKO0FBRUoifQ==
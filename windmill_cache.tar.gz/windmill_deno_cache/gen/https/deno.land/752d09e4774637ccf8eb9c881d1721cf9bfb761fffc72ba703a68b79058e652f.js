/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class FolderService {
  /**
     * list folders
     * @returns Folder folder list
     * @throws ApiError
     */ static listFolders({ workspace, page, perPage }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/folders/list',
      path: {
        'workspace': workspace
      },
      query: {
        'page': page,
        'per_page': perPage
      }
    });
  }
  /**
     * list folder names
     * @returns string folder list
     * @throws ApiError
     */ static listFolderNames({ workspace, onlyMemberOf }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/folders/listnames',
      path: {
        'workspace': workspace
      },
      query: {
        'only_member_of': onlyMemberOf
      }
    });
  }
  /**
     * create folder
     * @returns string folder created
     * @throws ApiError
     */ static createFolder({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/folders/create',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * update folder
     * @returns string folder updated
     * @throws ApiError
     */ static updateFolder({ workspace, name, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/folders/update/{name}',
      path: {
        'workspace': workspace,
        'name': name
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete folder
     * @returns string folder deleted
     * @throws ApiError
     */ static deleteFolder({ workspace, name }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/w/{workspace}/folders/delete/{name}',
      path: {
        'workspace': workspace,
        'name': name
      }
    });
  }
  /**
     * get folder
     * @returns Folder folder
     * @throws ApiError
     */ static getFolder({ workspace, name }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/folders/get/{name}',
      path: {
        'workspace': workspace,
        'name': name
      }
    });
  }
  /**
     * get folder usage
     * @returns any folder
     * @throws ApiError
     */ static getFolderUsage({ workspace, name }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/folders/getusage/{name}',
      path: {
        'workspace': workspace,
        'name': name
      }
    });
  }
  /**
     * add owner to folder
     * @returns string owner added to folder
     * @throws ApiError
     */ static addOwnerToFolder({ workspace, name, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/folders/addowner/{name}',
      path: {
        'workspace': workspace,
        'name': name
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * remove owner to folder
     * @returns string owner removed from folder
     * @throws ApiError
     */ static removeOwnerToFolder({ workspace, name, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/folders/removeowner/{name}',
      path: {
        'workspace': workspace,
        'name': name
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvRm9sZGVyU2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5pbXBvcnQgdHlwZSB7IEZvbGRlciB9IGZyb20gJy4uL21vZGVscy9Gb2xkZXIudHMnO1xuXG5pbXBvcnQgdHlwZSB7IENhbmNlbGFibGVQcm9taXNlIH0gZnJvbSAnLi4vY29yZS9DYW5jZWxhYmxlUHJvbWlzZS50cyc7XG5pbXBvcnQgeyBPcGVuQVBJIH0gZnJvbSAnLi4vY29yZS9PcGVuQVBJLnRzJztcbmltcG9ydCB7IHJlcXVlc3QgYXMgX19yZXF1ZXN0IH0gZnJvbSAnLi4vY29yZS9yZXF1ZXN0LnRzJztcblxuZXhwb3J0IGNsYXNzIEZvbGRlclNlcnZpY2Uge1xuXG4gICAgLyoqXG4gICAgICogbGlzdCBmb2xkZXJzXG4gICAgICogQHJldHVybnMgRm9sZGVyIGZvbGRlciBsaXN0XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdEZvbGRlcnMoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhZ2UsXG4gICAgICAgIHBlclBhZ2UsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHdoaWNoIHBhZ2UgdG8gcmV0dXJuIChzdGFydCBhdCAxLCBkZWZhdWx0IDEpXG4gICAgICAgICAqL1xuICAgICAgICBwYWdlPzogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogbnVtYmVyIG9mIGl0ZW1zIHRvIHJldHVybiBmb3IgYSBnaXZlbiBwYWdlIChkZWZhdWx0IDMwLCBtYXggMTAwKVxuICAgICAgICAgKi9cbiAgICAgICAgcGVyUGFnZT86IG51bWJlcixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8QXJyYXk8Rm9sZGVyPj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9mb2xkZXJzL2xpc3QnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAncGFnZSc6IHBhZ2UsXG4gICAgICAgICAgICAgICAgJ3Blcl9wYWdlJzogcGVyUGFnZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxpc3QgZm9sZGVyIG5hbWVzXG4gICAgICogQHJldHVybnMgc3RyaW5nIGZvbGRlciBsaXN0XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdEZvbGRlck5hbWVzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBvbmx5TWVtYmVyT2YsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG9ubHkgbGlzdCB0aGUgZm9sZGVycyB0aGUgdXNlciBpcyBtZW1iZXIgb2YgKGRlZmF1bHQgZmFsc2UpXG4gICAgICAgICAqL1xuICAgICAgICBvbmx5TWVtYmVyT2Y/OiBib29sZWFuLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxzdHJpbmc+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2ZvbGRlcnMvbGlzdG5hbWVzJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ29ubHlfbWVtYmVyX29mJzogb25seU1lbWJlck9mLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY3JlYXRlIGZvbGRlclxuICAgICAqIEByZXR1cm5zIHN0cmluZyBmb2xkZXIgY3JlYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGNyZWF0ZUZvbGRlcih7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGNyZWF0ZSBmb2xkZXJcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBuYW1lOiBzdHJpbmc7XG4gICAgICAgICAgICBvd25lcnM/OiBBcnJheTxzdHJpbmc+O1xuICAgICAgICAgICAgZXh0cmFfcGVybXM/OiBhbnk7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZm9sZGVycy9jcmVhdGUnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogdXBkYXRlIGZvbGRlclxuICAgICAqIEByZXR1cm5zIHN0cmluZyBmb2xkZXIgdXBkYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVwZGF0ZUZvbGRlcih7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgbmFtZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogdXBkYXRlIGZvbGRlclxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIG93bmVycz86IEFycmF5PHN0cmluZz47XG4gICAgICAgICAgICBleHRyYV9wZXJtcz86IGFueTtcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9mb2xkZXJzL3VwZGF0ZS97bmFtZX0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ25hbWUnOiBuYW1lLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGRlbGV0ZSBmb2xkZXJcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgZm9sZGVyIGRlbGV0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkZWxldGVGb2xkZXIoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIG5hbWUsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgbmFtZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZm9sZGVycy9kZWxldGUve25hbWV9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICduYW1lJzogbmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBmb2xkZXJcbiAgICAgKiBAcmV0dXJucyBGb2xkZXIgZm9sZGVyXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0Rm9sZGVyKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBuYW1lLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIG5hbWU6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8Rm9sZGVyPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2ZvbGRlcnMvZ2V0L3tuYW1lfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAnbmFtZSc6IG5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgZm9sZGVyIHVzYWdlXG4gICAgICogQHJldHVybnMgYW55IGZvbGRlclxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdldEZvbGRlclVzYWdlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBuYW1lLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIG5hbWU6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8e1xuICAgICAgICBzY3JpcHRzOiBudW1iZXI7XG4gICAgICAgIGZsb3dzOiBudW1iZXI7XG4gICAgICAgIGFwcHM6IG51bWJlcjtcbiAgICAgICAgcmVzb3VyY2VzOiBudW1iZXI7XG4gICAgICAgIHZhcmlhYmxlczogbnVtYmVyO1xuICAgICAgICBzY2hlZHVsZXM6IG51bWJlcjtcbiAgICB9PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2ZvbGRlcnMvZ2V0dXNhZ2Uve25hbWV9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICduYW1lJzogbmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGFkZCBvd25lciB0byBmb2xkZXJcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgb3duZXIgYWRkZWQgdG8gZm9sZGVyXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgYWRkT3duZXJUb0ZvbGRlcih7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgbmFtZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogb3duZXIgdXNlciB0byBmb2xkZXJcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBvd25lcj86IHN0cmluZztcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9mb2xkZXJzL2FkZG93bmVyL3tuYW1lfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAnbmFtZSc6IG5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcmVtb3ZlIG93bmVyIHRvIGZvbGRlclxuICAgICAqIEByZXR1cm5zIHN0cmluZyBvd25lciByZW1vdmVkIGZyb20gZm9sZGVyXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcmVtb3ZlT3duZXJUb0ZvbGRlcih7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgbmFtZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgbmFtZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogYWRkZWQgb3duZXIgdG8gZm9sZGVyXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keToge1xuICAgICAgICAgICAgb3duZXI/OiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZm9sZGVycy9yZW1vdmVvd25lci97bmFtZX0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ25hbWUnOiBuYW1lLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCLEdBSWxCLFNBQVMsT0FBTyxRQUFRLHFCQUFxQjtBQUM3QyxTQUFTLFdBQVcsU0FBUyxRQUFRLHFCQUFxQjtBQUUxRCxPQUFPLE1BQU07RUFFVDs7OztLQUlDLEdBQ0QsT0FBYyxZQUFZLEVBQ3RCLFNBQVMsRUFDVCxJQUFJLEVBQ0osT0FBTyxFQVdWLEVBQW9DO0lBQ2pDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxPQUFPO1FBQ0gsUUFBUTtRQUNSLFlBQVk7TUFDaEI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZ0JBQWdCLEVBQzFCLFNBQVMsRUFDVCxZQUFZLEVBT2YsRUFBb0M7SUFDakMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE9BQU87UUFDSCxrQkFBa0I7TUFDdEI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsYUFBYSxFQUN2QixTQUFTLEVBQ1QsV0FBVyxFQVdkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxhQUFhLEVBQ3ZCLFNBQVMsRUFDVCxJQUFJLEVBQ0osV0FBVyxFQVdkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxhQUFhLEVBQ3ZCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxVQUFVLEVBQ3BCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxlQUFlLEVBQ3pCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFPRTtJQUNDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsaUJBQWlCLEVBQzNCLFNBQVMsRUFDVCxJQUFJLEVBQ0osV0FBVyxFQVVkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxvQkFBb0IsRUFDOUIsU0FBUyxFQUNULElBQUksRUFDSixXQUFXLEVBVWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtBQUVKIn0=
/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ export var Policy;
(function(Policy) {
  let execution_mode;
  (function(execution_mode) {
    execution_mode["VIEWER"] = "viewer";
    execution_mode["PUBLISHER"] = "publisher";
    execution_mode["ANONYMOUS"] = "anonymous";
  })(execution_mode = Policy.execution_mode || (Policy.execution_mode = {}));
})(Policy || (Policy = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvbW9kZWxzL1BvbGljeS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5cbmV4cG9ydCB0eXBlIFBvbGljeSA9IHtcbiAgICB0cmlnZ2VyYWJsZXM/OiBSZWNvcmQ8c3RyaW5nLCBhbnk+O1xuICAgIGV4ZWN1dGlvbl9tb2RlPzogUG9saWN5LmV4ZWN1dGlvbl9tb2RlO1xuICAgIG9uX2JlaGFsZl9vZj86IHN0cmluZztcbiAgICBvbl9iZWhhbGZfb2ZfZW1haWw/OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgbmFtZXNwYWNlIFBvbGljeSB7XG5cbiAgICBleHBvcnQgZW51bSBleGVjdXRpb25fbW9kZSB7XG4gICAgICAgIFZJRVdFUiA9ICd2aWV3ZXInLFxuICAgICAgICBQVUJMSVNIRVIgPSAncHVibGlzaGVyJyxcbiAgICAgICAgQU5PTllNT1VTID0gJ2Fub255bW91cycsXG4gICAgfVxuXG5cbn1cblxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCO1VBU0Q7O1lBRUQ7Ozs7S0FBQSx3QkFBQSwwQkFBQTtBQU9oQixHQVRpQixXQUFBIn0=
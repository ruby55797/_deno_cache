/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class FavoriteService {
  /**
     * star item
     * @returns any star item
     * @throws ApiError
     */ static star({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/favorites/star',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * unstar item
     * @returns any unstar item
     * @throws ApiError
     */ static unstar({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/favorites/unstar',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvRmF2b3JpdGVTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgQ2FuY2VsYWJsZVByb21pc2UgfSBmcm9tICcuLi9jb3JlL0NhbmNlbGFibGVQcm9taXNlLnRzJztcbmltcG9ydCB7IE9wZW5BUEkgfSBmcm9tICcuLi9jb3JlL09wZW5BUEkudHMnO1xuaW1wb3J0IHsgcmVxdWVzdCBhcyBfX3JlcXVlc3QgfSBmcm9tICcuLi9jb3JlL3JlcXVlc3QudHMnO1xuXG5leHBvcnQgY2xhc3MgRmF2b3JpdGVTZXJ2aWNlIHtcblxuICAgIC8qKlxuICAgICAqIHN0YXIgaXRlbVxuICAgICAqIEByZXR1cm5zIGFueSBzdGFyIGl0ZW1cbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBzdGFyKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICByZXF1ZXN0Qm9keT86IHtcbiAgICAgICAgICAgIHBhdGg/OiBzdHJpbmc7XG4gICAgICAgICAgICBmYXZvcml0ZV9raW5kPzogJ2Zsb3cnIHwgJ2FwcCcgfCAnc2NyaXB0JyB8ICdyYXdfYXBwJztcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8YW55PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9mYXZvcml0ZXMvc3RhcicsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiB1bnN0YXIgaXRlbVxuICAgICAqIEByZXR1cm5zIGFueSB1bnN0YXIgaXRlbVxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVuc3Rhcih7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcmVxdWVzdEJvZHk/OiB7XG4gICAgICAgICAgICBwYXRoPzogc3RyaW5nO1xuICAgICAgICAgICAgZmF2b3JpdGVfa2luZD86ICdmbG93JyB8ICdhcHAnIHwgJ3NjcmlwdCcgfCAncmF3X2FwcCc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPGFueT4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZmF2b3JpdGVzL3Vuc3RhcicsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQixHQUVsQixTQUFTLE9BQU8sUUFBUSxxQkFBcUI7QUFDN0MsU0FBUyxXQUFXLFNBQVMsUUFBUSxxQkFBcUI7QUFFMUQsT0FBTyxNQUFNO0VBRVQ7Ozs7S0FJQyxHQUNELE9BQWMsS0FBSyxFQUNmLFNBQVMsRUFDVCxXQUFXLEVBT2QsRUFBMEI7SUFDdkIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLE9BQU8sRUFDakIsU0FBUyxFQUNULFdBQVcsRUFPZCxFQUEwQjtJQUN2QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0FBRUoifQ==
/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ export var Job;
(function(Job) {
  let type;
  (function(type) {
    type["COMPLETED_JOB"] = "CompletedJob";
    type["QUEUED_JOB"] = "QueuedJob";
  })(type = Job.type || (Job.type = {}));
})(Job || (Job = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvbW9kZWxzL0pvYi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5cbmltcG9ydCB0eXBlIHsgQ29tcGxldGVkSm9iIH0gZnJvbSAnLi9Db21wbGV0ZWRKb2IudHMnO1xuaW1wb3J0IHR5cGUgeyBRdWV1ZWRKb2IgfSBmcm9tICcuL1F1ZXVlZEpvYi50cyc7XG5cbmV4cG9ydCB0eXBlIEpvYiA9ICgoQ29tcGxldGVkSm9iIHwgUXVldWVkSm9iKSAmIHtcbiAgICB0eXBlPzogSm9iLnR5cGU7XG59KTtcblxuZXhwb3J0IG5hbWVzcGFjZSBKb2Ige1xuXG4gICAgZXhwb3J0IGVudW0gdHlwZSB7XG4gICAgICAgIENPTVBMRVRFRF9KT0IgPSAnQ29tcGxldGVkSm9iJyxcbiAgICAgICAgUVVFVUVEX0pPQiA9ICdRdWV1ZWRKb2InLFxuICAgIH1cblxuXG59XG5cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQjtVQVNEOztZQUVEOzs7S0FBQSxXQUFBLGFBQUE7QUFNaEIsR0FSaUIsUUFBQSJ9
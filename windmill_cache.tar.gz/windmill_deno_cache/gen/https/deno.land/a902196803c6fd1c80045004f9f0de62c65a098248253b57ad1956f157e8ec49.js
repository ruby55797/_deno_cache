/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class InputService {
  /**
     * List Inputs used in previously completed jobs
     * @returns Input Input history for completed jobs
     * @throws ApiError
     */ static getInputHistory({ workspace, runnableId, runnableType, page, perPage }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/inputs/history',
      path: {
        'workspace': workspace
      },
      query: {
        'runnable_id': runnableId,
        'runnable_type': runnableType,
        'page': page,
        'per_page': perPage
      }
    });
  }
  /**
     * List saved Inputs for a Runnable
     * @returns Input Saved Inputs for a Runnable
     * @throws ApiError
     */ static listInputs({ workspace, runnableId, runnableType, page, perPage }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/inputs/list',
      path: {
        'workspace': workspace
      },
      query: {
        'runnable_id': runnableId,
        'runnable_type': runnableType,
        'page': page,
        'per_page': perPage
      }
    });
  }
  /**
     * Create an Input for future use in a script or flow
     * @returns string Input created
     * @throws ApiError
     */ static createInput({ workspace, requestBody, runnableId, runnableType }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/inputs/create',
      path: {
        'workspace': workspace
      },
      query: {
        'runnable_id': runnableId,
        'runnable_type': runnableType
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * Update an Input
     * @returns string Input updated
     * @throws ApiError
     */ static updateInput({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/inputs/update',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * Delete a Saved Input
     * @returns string Input deleted
     * @throws ApiError
     */ static deleteInput({ workspace, input }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/inputs/delete/{input}',
      path: {
        'workspace': workspace,
        'input': input
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvSW5wdXRTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgQ3JlYXRlSW5wdXQgfSBmcm9tICcuLi9tb2RlbHMvQ3JlYXRlSW5wdXQudHMnO1xuaW1wb3J0IHR5cGUgeyBJbnB1dCB9IGZyb20gJy4uL21vZGVscy9JbnB1dC50cyc7XG5pbXBvcnQgdHlwZSB7IFJ1bm5hYmxlVHlwZSB9IGZyb20gJy4uL21vZGVscy9SdW5uYWJsZVR5cGUudHMnO1xuaW1wb3J0IHR5cGUgeyBVcGRhdGVJbnB1dCB9IGZyb20gJy4uL21vZGVscy9VcGRhdGVJbnB1dC50cyc7XG5cbmltcG9ydCB0eXBlIHsgQ2FuY2VsYWJsZVByb21pc2UgfSBmcm9tICcuLi9jb3JlL0NhbmNlbGFibGVQcm9taXNlLnRzJztcbmltcG9ydCB7IE9wZW5BUEkgfSBmcm9tICcuLi9jb3JlL09wZW5BUEkudHMnO1xuaW1wb3J0IHsgcmVxdWVzdCBhcyBfX3JlcXVlc3QgfSBmcm9tICcuLi9jb3JlL3JlcXVlc3QudHMnO1xuXG5leHBvcnQgY2xhc3MgSW5wdXRTZXJ2aWNlIHtcblxuICAgIC8qKlxuICAgICAqIExpc3QgSW5wdXRzIHVzZWQgaW4gcHJldmlvdXNseSBjb21wbGV0ZWQgam9ic1xuICAgICAqIEByZXR1cm5zIElucHV0IElucHV0IGhpc3RvcnkgZm9yIGNvbXBsZXRlZCBqb2JzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0SW5wdXRIaXN0b3J5KHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBydW5uYWJsZUlkLFxuICAgICAgICBydW5uYWJsZVR5cGUsXG4gICAgICAgIHBhZ2UsXG4gICAgICAgIHBlclBhZ2UsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcnVubmFibGVJZD86IHN0cmluZyxcbiAgICAgICAgcnVubmFibGVUeXBlPzogUnVubmFibGVUeXBlLFxuICAgICAgICAvKipcbiAgICAgICAgICogd2hpY2ggcGFnZSB0byByZXR1cm4gKHN0YXJ0IGF0IDEsIGRlZmF1bHQgMSlcbiAgICAgICAgICovXG4gICAgICAgIHBhZ2U/OiBudW1iZXIsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBudW1iZXIgb2YgaXRlbXMgdG8gcmV0dXJuIGZvciBhIGdpdmVuIHBhZ2UgKGRlZmF1bHQgMzAsIG1heCAxMDApXG4gICAgICAgICAqL1xuICAgICAgICBwZXJQYWdlPzogbnVtYmVyLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxJbnB1dD4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vaW5wdXRzL2hpc3RvcnknLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAncnVubmFibGVfaWQnOiBydW5uYWJsZUlkLFxuICAgICAgICAgICAgICAgICdydW5uYWJsZV90eXBlJzogcnVubmFibGVUeXBlLFxuICAgICAgICAgICAgICAgICdwYWdlJzogcGFnZSxcbiAgICAgICAgICAgICAgICAncGVyX3BhZ2UnOiBwZXJQYWdlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogTGlzdCBzYXZlZCBJbnB1dHMgZm9yIGEgUnVubmFibGVcbiAgICAgKiBAcmV0dXJucyBJbnB1dCBTYXZlZCBJbnB1dHMgZm9yIGEgUnVubmFibGVcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBsaXN0SW5wdXRzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBydW5uYWJsZUlkLFxuICAgICAgICBydW5uYWJsZVR5cGUsXG4gICAgICAgIHBhZ2UsXG4gICAgICAgIHBlclBhZ2UsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcnVubmFibGVJZD86IHN0cmluZyxcbiAgICAgICAgcnVubmFibGVUeXBlPzogUnVubmFibGVUeXBlLFxuICAgICAgICAvKipcbiAgICAgICAgICogd2hpY2ggcGFnZSB0byByZXR1cm4gKHN0YXJ0IGF0IDEsIGRlZmF1bHQgMSlcbiAgICAgICAgICovXG4gICAgICAgIHBhZ2U/OiBudW1iZXIsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBudW1iZXIgb2YgaXRlbXMgdG8gcmV0dXJuIGZvciBhIGdpdmVuIHBhZ2UgKGRlZmF1bHQgMzAsIG1heCAxMDApXG4gICAgICAgICAqL1xuICAgICAgICBwZXJQYWdlPzogbnVtYmVyLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxJbnB1dD4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vaW5wdXRzL2xpc3QnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAncnVubmFibGVfaWQnOiBydW5uYWJsZUlkLFxuICAgICAgICAgICAgICAgICdydW5uYWJsZV90eXBlJzogcnVubmFibGVUeXBlLFxuICAgICAgICAgICAgICAgICdwYWdlJzogcGFnZSxcbiAgICAgICAgICAgICAgICAncGVyX3BhZ2UnOiBwZXJQYWdlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogQ3JlYXRlIGFuIElucHV0IGZvciBmdXR1cmUgdXNlIGluIGEgc2NyaXB0IG9yIGZsb3dcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgSW5wdXQgY3JlYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGNyZWF0ZUlucHV0KHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICAgICAgcnVubmFibGVJZCxcbiAgICAgICAgcnVubmFibGVUeXBlLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBJbnB1dFxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IENyZWF0ZUlucHV0LFxuICAgICAgICBydW5uYWJsZUlkPzogc3RyaW5nLFxuICAgICAgICBydW5uYWJsZVR5cGU/OiBSdW5uYWJsZVR5cGUsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vaW5wdXRzL2NyZWF0ZScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdydW5uYWJsZV9pZCc6IHJ1bm5hYmxlSWQsXG4gICAgICAgICAgICAgICAgJ3J1bm5hYmxlX3R5cGUnOiBydW5uYWJsZVR5cGUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogVXBkYXRlIGFuIElucHV0XG4gICAgICogQHJldHVybnMgc3RyaW5nIElucHV0IHVwZGF0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyB1cGRhdGVJbnB1dCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFVwZGF0ZUlucHV0XG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogVXBkYXRlSW5wdXQsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vaW5wdXRzL3VwZGF0ZScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBEZWxldGUgYSBTYXZlZCBJbnB1dFxuICAgICAqIEByZXR1cm5zIHN0cmluZyBJbnB1dCBkZWxldGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZGVsZXRlSW5wdXQoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIGlucHV0LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGlucHV0OiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vaW5wdXRzL2RlbGV0ZS97aW5wdXR9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdpbnB1dCc6IGlucHV0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsd0JBQXdCLEdBQ3hCLGtCQUFrQixHQUNsQixrQkFBa0IsR0FPbEIsU0FBUyxPQUFPLFFBQVEscUJBQXFCO0FBQzdDLFNBQVMsV0FBVyxTQUFTLFFBQVEscUJBQXFCO0FBRTFELE9BQU8sTUFBTTtFQUVUOzs7O0tBSUMsR0FDRCxPQUFjLGdCQUFnQixFQUMxQixTQUFTLEVBQ1QsVUFBVSxFQUNWLFlBQVksRUFDWixJQUFJLEVBQ0osT0FBTyxFQWFWLEVBQW1DO0lBQ2hDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxPQUFPO1FBQ0gsZUFBZTtRQUNmLGlCQUFpQjtRQUNqQixRQUFRO1FBQ1IsWUFBWTtNQUNoQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxXQUFXLEVBQ3JCLFNBQVMsRUFDVCxVQUFVLEVBQ1YsWUFBWSxFQUNaLElBQUksRUFDSixPQUFPLEVBYVYsRUFBbUM7SUFDaEMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE9BQU87UUFDSCxlQUFlO1FBQ2YsaUJBQWlCO1FBQ2pCLFFBQVE7UUFDUixZQUFZO01BQ2hCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFlBQVksRUFDdEIsU0FBUyxFQUNULFdBQVcsRUFDWCxVQUFVLEVBQ1YsWUFBWSxFQVNmLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxPQUFPO1FBQ0gsZUFBZTtRQUNmLGlCQUFpQjtNQUNyQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFlBQVksRUFDdEIsU0FBUyxFQUNULFdBQVcsRUFPZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsWUFBWSxFQUN0QixTQUFTLEVBQ1QsS0FBSyxFQUlSLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixTQUFTO01BQ2I7SUFDSjtFQUNKO0FBRUoifQ==
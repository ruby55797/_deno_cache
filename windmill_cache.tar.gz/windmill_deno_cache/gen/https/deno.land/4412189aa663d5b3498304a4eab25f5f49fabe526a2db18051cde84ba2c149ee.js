/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class ScriptService {
  /**
     * list all available hub scripts
     * @returns any hub scripts list
     * @throws ApiError
     */ static listHubScripts() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/scripts/hub/list'
    });
  }
  /**
     * get hub script content by path
     * @returns string script details
     * @throws ApiError
     */ static getHubScriptContentByPath({ path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/scripts/hub/get/{path}',
      path: {
        'path': path
      }
    });
  }
  /**
     * get full hub script by path
     * @returns any script details
     * @throws ApiError
     */ static getHubScriptByPath({ path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/scripts/hub/get_full/{path}',
      path: {
        'path': path
      }
    });
  }
  /**
     * list all available scripts
     * @returns Script All available scripts
     * @throws ApiError
     */ static listScripts({ workspace, page, perPage, orderDesc, createdBy, pathStart, pathExact, firstParentHash, lastParentHash, parentHash, showArchived, isTemplate, kind, starredOnly }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/scripts/list',
      path: {
        'workspace': workspace
      },
      query: {
        'page': page,
        'per_page': perPage,
        'order_desc': orderDesc,
        'created_by': createdBy,
        'path_start': pathStart,
        'path_exact': pathExact,
        'first_parent_hash': firstParentHash,
        'last_parent_hash': lastParentHash,
        'parent_hash': parentHash,
        'show_archived': showArchived,
        'is_template': isTemplate,
        'kind': kind,
        'starred_only': starredOnly
      }
    });
  }
  /**
     * list all available scripts paths
     * @returns string list of script paths
     * @throws ApiError
     */ static listScriptPaths({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/scripts/list_paths',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * create script
     * @returns string script created
     * @throws ApiError
     */ static createScript({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/scripts/create',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * inspect python code to infer jsonschema of arguments
     * @returns MainArgSignature parsed args
     * @throws ApiError
     */ static pythonToJsonschema({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/scripts/python/tojsonschema',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * inspect deno code to infer jsonschema of arguments
     * @returns MainArgSignature parsed args
     * @throws ApiError
     */ static denoToJsonschema({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/scripts/deno/tojsonschema',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * inspect bash code to infer jsonschema of arguments
     * @returns MainArgSignature parsed args
     * @throws ApiError
     */ static bashToJsonschema({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/scripts/bash/tojsonschema',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * inspect go code to infer jsonschema of arguments
     * @returns MainArgSignature parsed args
     * @throws ApiError
     */ static goToJsonschema({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/scripts/go/tojsonschema',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * archive script by path
     * @returns string script archived
     * @throws ApiError
     */ static archiveScriptByPath({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/scripts/archive/p/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * archive script by hash
     * @returns Script script details
     * @throws ApiError
     */ static archiveScriptByHash({ workspace, hash }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/scripts/archive/h/{hash}',
      path: {
        'workspace': workspace,
        'hash': hash
      }
    });
  }
  /**
     * delete script by hash (erase content but keep hash, require admin)
     * @returns Script script details
     * @throws ApiError
     */ static deleteScriptByHash({ workspace, hash }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/scripts/delete/h/{hash}',
      path: {
        'workspace': workspace,
        'hash': hash
      }
    });
  }
  /**
     * delete all scripts at a given path (require admin)
     * @returns string script path
     * @throws ApiError
     */ static deleteScriptByPath({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/scripts/delete/p/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * get script by path
     * @returns Script script details
     * @throws ApiError
     */ static getScriptByPath({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/scripts/get/p/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * get script by path with draft
     * @returns NewScriptWithDraft script details
     * @throws ApiError
     */ static getScriptByPathWithDraft({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/scripts/get/draft/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * raw script by path
     * @returns string script content
     * @throws ApiError
     */ static rawScriptByPath({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/scripts/raw/p/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * raw script by path with a token (mostly used by lsp to be used with import maps to resolve scripts)
     * @returns string script content
     * @throws ApiError
     */ static rawScriptByPathTokened({ workspace, token, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/scripts_u/tokened_raw/{workspace}/{token}/{path}',
      path: {
        'workspace': workspace,
        'token': token,
        'path': path
      }
    });
  }
  /**
     * exists script by path
     * @returns boolean does it exists
     * @throws ApiError
     */ static existsScriptByPath({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/scripts/exists/p/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * get script by hash
     * @returns Script script details
     * @throws ApiError
     */ static getScriptByHash({ workspace, hash }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/scripts/get/h/{hash}',
      path: {
        'workspace': workspace,
        'hash': hash
      }
    });
  }
  /**
     * raw script by hash
     * @returns string script content
     * @throws ApiError
     */ static rawScriptByHash({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/scripts/raw/h/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * get script deployment status
     * @returns any script details
     * @throws ApiError
     */ static getScriptDeploymentStatus({ workspace, hash }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/scripts/deployment_status/h/{hash}',
      path: {
        'workspace': workspace,
        'hash': hash
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvU2NyaXB0U2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5pbXBvcnQgdHlwZSB7IE1haW5BcmdTaWduYXR1cmUgfSBmcm9tICcuLi9tb2RlbHMvTWFpbkFyZ1NpZ25hdHVyZS50cyc7XG5pbXBvcnQgdHlwZSB7IE5ld1NjcmlwdCB9IGZyb20gJy4uL21vZGVscy9OZXdTY3JpcHQudHMnO1xuaW1wb3J0IHR5cGUgeyBOZXdTY3JpcHRXaXRoRHJhZnQgfSBmcm9tICcuLi9tb2RlbHMvTmV3U2NyaXB0V2l0aERyYWZ0LnRzJztcbmltcG9ydCB0eXBlIHsgU2NyaXB0IH0gZnJvbSAnLi4vbW9kZWxzL1NjcmlwdC50cyc7XG5cbmltcG9ydCB0eXBlIHsgQ2FuY2VsYWJsZVByb21pc2UgfSBmcm9tICcuLi9jb3JlL0NhbmNlbGFibGVQcm9taXNlLnRzJztcbmltcG9ydCB7IE9wZW5BUEkgfSBmcm9tICcuLi9jb3JlL09wZW5BUEkudHMnO1xuaW1wb3J0IHsgcmVxdWVzdCBhcyBfX3JlcXVlc3QgfSBmcm9tICcuLi9jb3JlL3JlcXVlc3QudHMnO1xuXG5leHBvcnQgY2xhc3MgU2NyaXB0U2VydmljZSB7XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGFsbCBhdmFpbGFibGUgaHViIHNjcmlwdHNcbiAgICAgKiBAcmV0dXJucyBhbnkgaHViIHNjcmlwdHMgbGlzdFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RIdWJTY3JpcHRzKCk6IENhbmNlbGFibGVQcm9taXNlPHtcbiAgICAgICAgYXNrcz86IEFycmF5PHtcbiAgICAgICAgICAgIGlkOiBudW1iZXI7XG4gICAgICAgICAgICBhc2tfaWQ6IG51bWJlcjtcbiAgICAgICAgICAgIHN1bW1hcnk6IHN0cmluZztcbiAgICAgICAgICAgIGFwcDogc3RyaW5nO1xuICAgICAgICAgICAgYXBwcm92ZWQ6IGJvb2xlYW47XG4gICAgICAgICAgICBraW5kOiAnc2NyaXB0JyB8ICdmYWlsdXJlJyB8ICd0cmlnZ2VyJyB8ICdjb21tYW5kJyB8ICdhcHByb3ZhbCc7XG4gICAgICAgICAgICB2b3RlczogbnVtYmVyO1xuICAgICAgICAgICAgdmlld3M6IG51bWJlcjtcbiAgICAgICAgfT47XG4gICAgfT4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvc2NyaXB0cy9odWIvbGlzdCcsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBodWIgc2NyaXB0IGNvbnRlbnQgYnkgcGF0aFxuICAgICAqIEByZXR1cm5zIHN0cmluZyBzY3JpcHQgZGV0YWlsc1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdldEh1YlNjcmlwdENvbnRlbnRCeVBhdGgoe1xuICAgICAgICBwYXRoLFxuICAgIH06IHtcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3NjcmlwdHMvaHViL2dldC97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBmdWxsIGh1YiBzY3JpcHQgYnkgcGF0aFxuICAgICAqIEByZXR1cm5zIGFueSBzY3JpcHQgZGV0YWlsc1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdldEh1YlNjcmlwdEJ5UGF0aCh7XG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHtcbiAgICAgICAgY29udGVudDogc3RyaW5nO1xuICAgICAgICBsb2NrZmlsZT86IHN0cmluZztcbiAgICAgICAgc2NoZW1hPzogYW55O1xuICAgICAgICBsYW5ndWFnZTogJ2Rlbm8nIHwgJ3B5dGhvbjMnIHwgJ2dvJyB8ICdiYXNoJztcbiAgICAgICAgc3VtbWFyeT86IHN0cmluZztcbiAgICB9PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy9zY3JpcHRzL2h1Yi9nZXRfZnVsbC97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxpc3QgYWxsIGF2YWlsYWJsZSBzY3JpcHRzXG4gICAgICogQHJldHVybnMgU2NyaXB0IEFsbCBhdmFpbGFibGUgc2NyaXB0c1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RTY3JpcHRzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYWdlLFxuICAgICAgICBwZXJQYWdlLFxuICAgICAgICBvcmRlckRlc2MsXG4gICAgICAgIGNyZWF0ZWRCeSxcbiAgICAgICAgcGF0aFN0YXJ0LFxuICAgICAgICBwYXRoRXhhY3QsXG4gICAgICAgIGZpcnN0UGFyZW50SGFzaCxcbiAgICAgICAgbGFzdFBhcmVudEhhc2gsXG4gICAgICAgIHBhcmVudEhhc2gsXG4gICAgICAgIHNob3dBcmNoaXZlZCxcbiAgICAgICAgaXNUZW1wbGF0ZSxcbiAgICAgICAga2luZCxcbiAgICAgICAgc3RhcnJlZE9ubHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHdoaWNoIHBhZ2UgdG8gcmV0dXJuIChzdGFydCBhdCAxLCBkZWZhdWx0IDEpXG4gICAgICAgICAqL1xuICAgICAgICBwYWdlPzogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogbnVtYmVyIG9mIGl0ZW1zIHRvIHJldHVybiBmb3IgYSBnaXZlbiBwYWdlIChkZWZhdWx0IDMwLCBtYXggMTAwKVxuICAgICAgICAgKi9cbiAgICAgICAgcGVyUGFnZT86IG51bWJlcixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG9yZGVyIGJ5IGRlc2Mgb3JkZXIgKGRlZmF1bHQgdHJ1ZSlcbiAgICAgICAgICovXG4gICAgICAgIG9yZGVyRGVzYz86IGJvb2xlYW4sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBtYXNrIHRvIGZpbHRlciBleGFjdCBtYXRjaGluZyB1c2VyIGNyZWF0b3JcbiAgICAgICAgICovXG4gICAgICAgIGNyZWF0ZWRCeT86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIG1hdGNoaW5nIHN0YXJ0aW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHBhdGhTdGFydD86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIGV4YWN0IG1hdGNoaW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHBhdGhFeGFjdD86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIHNjcmlwdHMgd2hvbSBmaXJzdCBkaXJlY3QgcGFyZW50IGhhcyBleGFjdCBoYXNoXG4gICAgICAgICAqL1xuICAgICAgICBmaXJzdFBhcmVudEhhc2g/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBtYXNrIHRvIGZpbHRlciBzY3JpcHRzIHdob20gbGFzdCBwYXJlbnQgaW4gdGhlIGNoYWluIGhhcyBleGFjdCBoYXNoLlxuICAgICAgICAgKiBCZXdhcmUgdGhhdCBlYWNoIHNjcmlwdCBzdG9yZXMgb25seSBhIGxpbWl0ZWQgbnVtYmVyIG9mIHBhcmVudHMuIEhlbmNlXG4gICAgICAgICAqIHRoZSBsYXN0IHBhcmVudCBoYXNoIGZvciBhIHNjcmlwdCBpcyBub3QgbmVjZXNzYXJpbHkgaXRzIHRvcC1tb3N0IHBhcmVudC5cbiAgICAgICAgICogVG8gZmluZCB0aGUgdG9wLW1vc3QgcGFyZW50IHlvdSB3aWxsIGhhdmUgdG8ganVtcCBmcm9tIGxhc3QgdG8gbGFzdCBoYXNoXG4gICAgICAgICAqIHVudGlsIGZpbmRpbmcgdGhlIHBhcmVudFxuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgbGFzdFBhcmVudEhhc2g/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBpcyB0aGUgaGFzaCBwcmVzZW50IGluIHRoZSBhcnJheSBvZiBzdG9yZWQgcGFyZW50IGhhc2hlcyBmb3IgdGhpcyBzY3JpcHQuXG4gICAgICAgICAqIFRoZSBzYW1lIHdhcm5pbmcgYXBwbGllcyB0aGFuIGZvciBsYXN0X3BhcmVudF9oYXNoLiBBIHNjcmlwdCBvbmx5IHN0b3JlIGFcbiAgICAgICAgICogbGltaXRlZCBudW1iZXIgb2YgZGlyZWN0IHBhcmVudFxuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgcGFyZW50SGFzaD86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIChkZWZhdWx0IGZhbHNlKVxuICAgICAgICAgKiBzaG93IGFsc28gdGhlIGFyY2hpdmVkIGZpbGVzLlxuICAgICAgICAgKiB3aGVuIG11bHRpcGxlIGFyY2hpdmVkIGhhc2ggc2hhcmUgdGhlIHNhbWUgcGF0aCwgb25seSB0aGUgb25lcyB3aXRoIHRoZSBsYXRlc3QgY3JlYXRlX2F0XG4gICAgICAgICAqIGFyZVxuICAgICAgICAgKiBlZC5cbiAgICAgICAgICpcbiAgICAgICAgICovXG4gICAgICAgIHNob3dBcmNoaXZlZD86IGJvb2xlYW4sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiAoZGVmYXVsdCByZWdhcmRsZXNzKVxuICAgICAgICAgKiBpZiB0cnVlIHNob3cgb25seSB0aGUgdGVtcGxhdGVzXG4gICAgICAgICAqIGlmIGZhbHNlIHNob3cgb25seSB0aGUgbm9uIHRlbXBsYXRlc1xuICAgICAgICAgKiBpZiBub3QgZGVmaW5lZCwgc2hvdyBhbGwgcmVnYXJkbGVzcyBvZiBpZiB0aGUgc2NyaXB0IGlzIGEgdGVtcGxhdGVcbiAgICAgICAgICpcbiAgICAgICAgICovXG4gICAgICAgIGlzVGVtcGxhdGU/OiBib29sZWFuLFxuICAgICAgICAvKipcbiAgICAgICAgICogKGRlZmF1bHQgcmVnYXJkbGVzcylcbiAgICAgICAgICogc2NyaXB0IGtpbmRcbiAgICAgICAgICpcbiAgICAgICAgICovXG4gICAgICAgIGtpbmQ/OiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiAoZGVmYXVsdCBmYWxzZSlcbiAgICAgICAgICogc2hvdyBvbmx5IHRoZSBzdGFycmVkIGl0ZW1zXG4gICAgICAgICAqXG4gICAgICAgICAqL1xuICAgICAgICBzdGFycmVkT25seT86IGJvb2xlYW4sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PFNjcmlwdD4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vc2NyaXB0cy9saXN0JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ3BhZ2UnOiBwYWdlLFxuICAgICAgICAgICAgICAgICdwZXJfcGFnZSc6IHBlclBhZ2UsXG4gICAgICAgICAgICAgICAgJ29yZGVyX2Rlc2MnOiBvcmRlckRlc2MsXG4gICAgICAgICAgICAgICAgJ2NyZWF0ZWRfYnknOiBjcmVhdGVkQnksXG4gICAgICAgICAgICAgICAgJ3BhdGhfc3RhcnQnOiBwYXRoU3RhcnQsXG4gICAgICAgICAgICAgICAgJ3BhdGhfZXhhY3QnOiBwYXRoRXhhY3QsXG4gICAgICAgICAgICAgICAgJ2ZpcnN0X3BhcmVudF9oYXNoJzogZmlyc3RQYXJlbnRIYXNoLFxuICAgICAgICAgICAgICAgICdsYXN0X3BhcmVudF9oYXNoJzogbGFzdFBhcmVudEhhc2gsXG4gICAgICAgICAgICAgICAgJ3BhcmVudF9oYXNoJzogcGFyZW50SGFzaCxcbiAgICAgICAgICAgICAgICAnc2hvd19hcmNoaXZlZCc6IHNob3dBcmNoaXZlZCxcbiAgICAgICAgICAgICAgICAnaXNfdGVtcGxhdGUnOiBpc1RlbXBsYXRlLFxuICAgICAgICAgICAgICAgICdraW5kJzoga2luZCxcbiAgICAgICAgICAgICAgICAnc3RhcnJlZF9vbmx5Jzogc3RhcnJlZE9ubHksXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGFsbCBhdmFpbGFibGUgc2NyaXB0cyBwYXRoc1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBsaXN0IG9mIHNjcmlwdCBwYXRoc1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RTY3JpcHRQYXRocyh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxzdHJpbmc+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3NjcmlwdHMvbGlzdF9wYXRocycsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGNyZWF0ZSBzY3JpcHRcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgc2NyaXB0IGNyZWF0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGVTY3JpcHQoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBQYXJ0aWFsbHkgZmlsbGVkIHNjcmlwdFxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IE5ld1NjcmlwdCxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9zY3JpcHRzL2NyZWF0ZScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBpbnNwZWN0IHB5dGhvbiBjb2RlIHRvIGluZmVyIGpzb25zY2hlbWEgb2YgYXJndW1lbnRzXG4gICAgICogQHJldHVybnMgTWFpbkFyZ1NpZ25hdHVyZSBwYXJzZWQgYXJnc1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHB5dGhvblRvSnNvbnNjaGVtYSh7XG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHB5dGhvbiBjb2RlIHdpdGggdGhlIG1haW4gZnVuY3Rpb25cbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPE1haW5BcmdTaWduYXR1cmU+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy9zY3JpcHRzL3B5dGhvbi90b2pzb25zY2hlbWEnLFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogaW5zcGVjdCBkZW5vIGNvZGUgdG8gaW5mZXIganNvbnNjaGVtYSBvZiBhcmd1bWVudHNcbiAgICAgKiBAcmV0dXJucyBNYWluQXJnU2lnbmF0dXJlIHBhcnNlZCBhcmdzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZGVub1RvSnNvbnNjaGVtYSh7XG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGRlbm8gY29kZSB3aXRoIHRoZSBtYWluIGZ1bmN0aW9uXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxNYWluQXJnU2lnbmF0dXJlPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvc2NyaXB0cy9kZW5vL3RvanNvbnNjaGVtYScsXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBpbnNwZWN0IGJhc2ggY29kZSB0byBpbmZlciBqc29uc2NoZW1hIG9mIGFyZ3VtZW50c1xuICAgICAqIEByZXR1cm5zIE1haW5BcmdTaWduYXR1cmUgcGFyc2VkIGFyZ3NcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBiYXNoVG9Kc29uc2NoZW1hKHtcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICAvKipcbiAgICAgICAgICogYmFzaCBjb2RlIHdpdGggdGhlIG1haW4gZnVuY3Rpb25cbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPE1haW5BcmdTaWduYXR1cmU+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy9zY3JpcHRzL2Jhc2gvdG9qc29uc2NoZW1hJyxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGluc3BlY3QgZ28gY29kZSB0byBpbmZlciBqc29uc2NoZW1hIG9mIGFyZ3VtZW50c1xuICAgICAqIEByZXR1cm5zIE1haW5BcmdTaWduYXR1cmUgcGFyc2VkIGFyZ3NcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnb1RvSnNvbnNjaGVtYSh7XG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGdvIGNvZGUgd2l0aCB0aGUgbWFpbiBmdW5jdGlvblxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8TWFpbkFyZ1NpZ25hdHVyZT4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3NjcmlwdHMvZ28vdG9qc29uc2NoZW1hJyxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGFyY2hpdmUgc2NyaXB0IGJ5IHBhdGhcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgc2NyaXB0IGFyY2hpdmVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgYXJjaGl2ZVNjcmlwdEJ5UGF0aCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vc2NyaXB0cy9hcmNoaXZlL3Ave3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGFyY2hpdmUgc2NyaXB0IGJ5IGhhc2hcbiAgICAgKiBAcmV0dXJucyBTY3JpcHQgc2NyaXB0IGRldGFpbHNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBhcmNoaXZlU2NyaXB0QnlIYXNoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBoYXNoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGhhc2g6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8U2NyaXB0PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9zY3JpcHRzL2FyY2hpdmUvaC97aGFzaH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2hhc2gnOiBoYXNoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlIHNjcmlwdCBieSBoYXNoIChlcmFzZSBjb250ZW50IGJ1dCBrZWVwIGhhc2gsIHJlcXVpcmUgYWRtaW4pXG4gICAgICogQHJldHVybnMgU2NyaXB0IHNjcmlwdCBkZXRhaWxzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZGVsZXRlU2NyaXB0QnlIYXNoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBoYXNoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGhhc2g6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8U2NyaXB0PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9zY3JpcHRzL2RlbGV0ZS9oL3toYXNofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAnaGFzaCc6IGhhc2gsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBkZWxldGUgYWxsIHNjcmlwdHMgYXQgYSBnaXZlbiBwYXRoIChyZXF1aXJlIGFkbWluKVxuICAgICAqIEByZXR1cm5zIHN0cmluZyBzY3JpcHQgcGF0aFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGRlbGV0ZVNjcmlwdEJ5UGF0aCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vc2NyaXB0cy9kZWxldGUvcC97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZ2V0IHNjcmlwdCBieSBwYXRoXG4gICAgICogQHJldHVybnMgU2NyaXB0IHNjcmlwdCBkZXRhaWxzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0U2NyaXB0QnlQYXRoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8U2NyaXB0PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3NjcmlwdHMvZ2V0L3Ave3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBzY3JpcHQgYnkgcGF0aCB3aXRoIGRyYWZ0XG4gICAgICogQHJldHVybnMgTmV3U2NyaXB0V2l0aERyYWZ0IHNjcmlwdCBkZXRhaWxzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0U2NyaXB0QnlQYXRoV2l0aERyYWZ0KHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8TmV3U2NyaXB0V2l0aERyYWZ0PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3NjcmlwdHMvZ2V0L2RyYWZ0L3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiByYXcgc2NyaXB0IGJ5IHBhdGhcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgc2NyaXB0IGNvbnRlbnRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyByYXdTY3JpcHRCeVBhdGgoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vc2NyaXB0cy9yYXcvcC97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcmF3IHNjcmlwdCBieSBwYXRoIHdpdGggYSB0b2tlbiAobW9zdGx5IHVzZWQgYnkgbHNwIHRvIGJlIHVzZWQgd2l0aCBpbXBvcnQgbWFwcyB0byByZXNvbHZlIHNjcmlwdHMpXG4gICAgICogQHJldHVybnMgc3RyaW5nIHNjcmlwdCBjb250ZW50XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcmF3U2NyaXB0QnlQYXRoVG9rZW5lZCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgdG9rZW4sXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgdG9rZW46IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3NjcmlwdHNfdS90b2tlbmVkX3Jhdy97d29ya3NwYWNlfS97dG9rZW59L3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAndG9rZW4nOiB0b2tlbixcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBleGlzdHMgc2NyaXB0IGJ5IHBhdGhcbiAgICAgKiBAcmV0dXJucyBib29sZWFuIGRvZXMgaXQgZXhpc3RzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZXhpc3RzU2NyaXB0QnlQYXRoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8Ym9vbGVhbj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9zY3JpcHRzL2V4aXN0cy9wL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgc2NyaXB0IGJ5IGhhc2hcbiAgICAgKiBAcmV0dXJucyBTY3JpcHQgc2NyaXB0IGRldGFpbHNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRTY3JpcHRCeUhhc2goe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIGhhc2gsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgaGFzaDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxTY3JpcHQ+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vc2NyaXB0cy9nZXQvaC97aGFzaH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ2hhc2gnOiBoYXNoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogcmF3IHNjcmlwdCBieSBoYXNoXG4gICAgICogQHJldHVybnMgc3RyaW5nIHNjcmlwdCBjb250ZW50XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgcmF3U2NyaXB0QnlIYXNoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3NjcmlwdHMvcmF3L2gve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBzY3JpcHQgZGVwbG95bWVudCBzdGF0dXNcbiAgICAgKiBAcmV0dXJucyBhbnkgc2NyaXB0IGRldGFpbHNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRTY3JpcHREZXBsb3ltZW50U3RhdHVzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBoYXNoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIGhhc2g6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8e1xuICAgICAgICBsb2NrPzogc3RyaW5nO1xuICAgICAgICBsb2NrX2Vycm9yX2xvZ3M/OiBzdHJpbmc7XG4gICAgfT4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9zY3JpcHRzL2RlcGxveW1lbnRfc3RhdHVzL2gve2hhc2h9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdoYXNoJzogaGFzaCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCLEdBT2xCLFNBQVMsT0FBTyxRQUFRLHFCQUFxQjtBQUM3QyxTQUFTLFdBQVcsU0FBUyxRQUFRLHFCQUFxQjtBQUUxRCxPQUFPLE1BQU07RUFFVDs7OztLQUlDLEdBQ0QsT0FBYyxpQkFXWDtJQUNDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO0lBQ1Q7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLDBCQUEwQixFQUNwQyxJQUFJLEVBR1AsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG1CQUFtQixFQUM3QixJQUFJLEVBR1AsRUFNRTtJQUNDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxZQUFZLEVBQ3RCLFNBQVMsRUFDVCxJQUFJLEVBQ0osT0FBTyxFQUNQLFNBQVMsRUFDVCxTQUFTLEVBQ1QsU0FBUyxFQUNULFNBQVMsRUFDVCxlQUFlLEVBQ2YsY0FBYyxFQUNkLFVBQVUsRUFDVixZQUFZLEVBQ1osVUFBVSxFQUNWLElBQUksRUFDSixXQUFXLEVBNEVkLEVBQW9DO0lBQ2pDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxPQUFPO1FBQ0gsUUFBUTtRQUNSLFlBQVk7UUFDWixjQUFjO1FBQ2QsY0FBYztRQUNkLGNBQWM7UUFDZCxjQUFjO1FBQ2QscUJBQXFCO1FBQ3JCLG9CQUFvQjtRQUNwQixlQUFlO1FBQ2YsaUJBQWlCO1FBQ2pCLGVBQWU7UUFDZixRQUFRO1FBQ1IsZ0JBQWdCO01BQ3BCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGdCQUFnQixFQUMxQixTQUFTLEVBR1osRUFBb0M7SUFDakMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxhQUFhLEVBQ3ZCLFNBQVMsRUFDVCxXQUFXLEVBT2QsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG1CQUFtQixFQUM3QixXQUFXLEVBTWQsRUFBdUM7SUFDcEMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxpQkFBaUIsRUFDM0IsV0FBVyxFQU1kLEVBQXVDO0lBQ3BDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsaUJBQWlCLEVBQzNCLFdBQVcsRUFNZCxFQUF1QztJQUNwQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsV0FBVyxFQU1kLEVBQXVDO0lBQ3BDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsb0JBQW9CLEVBQzlCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxvQkFBb0IsRUFDOUIsU0FBUyxFQUNULElBQUksRUFJUCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG1CQUFtQixFQUM3QixTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsbUJBQW1CLEVBQzdCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxnQkFBZ0IsRUFDMUIsU0FBUyxFQUNULElBQUksRUFJUCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLHlCQUF5QixFQUNuQyxTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBQXlDO0lBQ3RDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZ0JBQWdCLEVBQzFCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyx1QkFBdUIsRUFDakMsU0FBUyxFQUNULEtBQUssRUFDTCxJQUFJLEVBS1AsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFNBQVM7UUFDVCxRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsbUJBQW1CLEVBQzdCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBOEI7SUFDM0IsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxnQkFBZ0IsRUFDMUIsU0FBUyxFQUNULElBQUksRUFJUCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGdCQUFnQixFQUMxQixTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsMEJBQTBCLEVBQ3BDLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFHRTtJQUNDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0FBRUoifQ==
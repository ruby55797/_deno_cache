/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class FlowService {
  /**
     * list all available hub flows
     * @returns any hub flows list
     * @throws ApiError
     */ static listHubFlows() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/flows/hub/list'
    });
  }
  /**
     * get hub flow by id
     * @returns any flow
     * @throws ApiError
     */ static getHubFlowById({ id }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/flows/hub/get/{id}',
      path: {
        'id': id
      }
    });
  }
  /**
     * list all available flow paths
     * @returns string list of flow paths
     * @throws ApiError
     */ static listFlowPaths({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/flows/list_paths',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * list all available flows
     * @returns any All available flow
     * @throws ApiError
     */ static listFlows({ workspace, page, perPage, orderDesc, createdBy, pathStart, pathExact, showArchived, starredOnly }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/flows/list',
      path: {
        'workspace': workspace
      },
      query: {
        'page': page,
        'per_page': perPage,
        'order_desc': orderDesc,
        'created_by': createdBy,
        'path_start': pathStart,
        'path_exact': pathExact,
        'show_archived': showArchived,
        'starred_only': starredOnly
      }
    });
  }
  /**
     * get flow by path
     * @returns Flow flow details
     * @throws ApiError
     */ static getFlowByPath({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/flows/get/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * get flow by path with draft
     * @returns any flow details with draft
     * @throws ApiError
     */ static getFlowByPathWithDraft({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/flows/get/draft/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * exists flow by path
     * @returns boolean flow details
     * @throws ApiError
     */ static existsFlowByPath({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/flows/exists/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * create flow
     * @returns string flow created
     * @throws ApiError
     */ static createFlow({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/flows/create',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * update flow
     * @returns string flow updated
     * @throws ApiError
     */ static updateFlow({ workspace, path, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/flows/update/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * archive flow by path
     * @returns string flow archived
     * @throws ApiError
     */ static archiveFlowByPath({ workspace, path, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/flows/archive/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete flow by path
     * @returns string flow delete
     * @throws ApiError
     */ static deleteFlowByPath({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/w/{workspace}/flows/delete/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * list inputs for previous completed flow jobs
     * @returns Input input history for completed jobs with this flow path
     * @throws ApiError
     */ static getFlowInputHistoryByPath({ workspace, path, page, perPage }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/flows/input_history/p/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      query: {
        'page': page,
        'per_page': perPage
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvRmxvd1NlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogaXN0YW5idWwgaWdub3JlIGZpbGUgKi9cbi8qIHRzbGludDpkaXNhYmxlICovXG4vKiBlc2xpbnQtZGlzYWJsZSAqL1xuaW1wb3J0IHR5cGUgeyBGbG93IH0gZnJvbSAnLi4vbW9kZWxzL0Zsb3cudHMnO1xuaW1wb3J0IHR5cGUgeyBJbnB1dCB9IGZyb20gJy4uL21vZGVscy9JbnB1dC50cyc7XG5pbXBvcnQgdHlwZSB7IE9wZW5GbG93IH0gZnJvbSAnLi4vbW9kZWxzL09wZW5GbG93LnRzJztcbmltcG9ydCB0eXBlIHsgT3BlbkZsb3dXUGF0aCB9IGZyb20gJy4uL21vZGVscy9PcGVuRmxvd1dQYXRoLnRzJztcblxuaW1wb3J0IHR5cGUgeyBDYW5jZWxhYmxlUHJvbWlzZSB9IGZyb20gJy4uL2NvcmUvQ2FuY2VsYWJsZVByb21pc2UudHMnO1xuaW1wb3J0IHsgT3BlbkFQSSB9IGZyb20gJy4uL2NvcmUvT3BlbkFQSS50cyc7XG5pbXBvcnQgeyByZXF1ZXN0IGFzIF9fcmVxdWVzdCB9IGZyb20gJy4uL2NvcmUvcmVxdWVzdC50cyc7XG5cbmV4cG9ydCBjbGFzcyBGbG93U2VydmljZSB7XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGFsbCBhdmFpbGFibGUgaHViIGZsb3dzXG4gICAgICogQHJldHVybnMgYW55IGh1YiBmbG93cyBsaXN0XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdEh1YkZsb3dzKCk6IENhbmNlbGFibGVQcm9taXNlPHtcbiAgICAgICAgZmxvd3M/OiBBcnJheTx7XG4gICAgICAgICAgICBpZDogbnVtYmVyO1xuICAgICAgICAgICAgZmxvd19pZDogbnVtYmVyO1xuICAgICAgICAgICAgc3VtbWFyeTogc3RyaW5nO1xuICAgICAgICAgICAgYXBwczogQXJyYXk8c3RyaW5nPjtcbiAgICAgICAgICAgIGFwcHJvdmVkOiBib29sZWFuO1xuICAgICAgICAgICAgdm90ZXM6IG51bWJlcjtcbiAgICAgICAgfT47XG4gICAgfT4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvZmxvd3MvaHViL2xpc3QnLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgaHViIGZsb3cgYnkgaWRcbiAgICAgKiBAcmV0dXJucyBhbnkgZmxvd1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdldEh1YkZsb3dCeUlkKHtcbiAgICAgICAgaWQsXG4gICAgfToge1xuICAgICAgICBpZDogbnVtYmVyLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTx7XG4gICAgICAgIGZsb3c/OiBPcGVuRmxvdztcbiAgICB9PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy9mbG93cy9odWIvZ2V0L3tpZH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICdpZCc6IGlkLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbGlzdCBhbGwgYXZhaWxhYmxlIGZsb3cgcGF0aHNcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgbGlzdCBvZiBmbG93IHBhdGhzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdEZsb3dQYXRocyh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxzdHJpbmc+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2Zsb3dzL2xpc3RfcGF0aHMnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGFsbCBhdmFpbGFibGUgZmxvd3NcbiAgICAgKiBAcmV0dXJucyBhbnkgQWxsIGF2YWlsYWJsZSBmbG93XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdEZsb3dzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYWdlLFxuICAgICAgICBwZXJQYWdlLFxuICAgICAgICBvcmRlckRlc2MsXG4gICAgICAgIGNyZWF0ZWRCeSxcbiAgICAgICAgcGF0aFN0YXJ0LFxuICAgICAgICBwYXRoRXhhY3QsXG4gICAgICAgIHNob3dBcmNoaXZlZCxcbiAgICAgICAgc3RhcnJlZE9ubHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHdoaWNoIHBhZ2UgdG8gcmV0dXJuIChzdGFydCBhdCAxLCBkZWZhdWx0IDEpXG4gICAgICAgICAqL1xuICAgICAgICBwYWdlPzogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogbnVtYmVyIG9mIGl0ZW1zIHRvIHJldHVybiBmb3IgYSBnaXZlbiBwYWdlIChkZWZhdWx0IDMwLCBtYXggMTAwKVxuICAgICAgICAgKi9cbiAgICAgICAgcGVyUGFnZT86IG51bWJlcixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG9yZGVyIGJ5IGRlc2Mgb3JkZXIgKGRlZmF1bHQgdHJ1ZSlcbiAgICAgICAgICovXG4gICAgICAgIG9yZGVyRGVzYz86IGJvb2xlYW4sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBtYXNrIHRvIGZpbHRlciBleGFjdCBtYXRjaGluZyB1c2VyIGNyZWF0b3JcbiAgICAgICAgICovXG4gICAgICAgIGNyZWF0ZWRCeT86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIG1hdGNoaW5nIHN0YXJ0aW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHBhdGhTdGFydD86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG1hc2sgdG8gZmlsdGVyIGV4YWN0IG1hdGNoaW5nIHBhdGhcbiAgICAgICAgICovXG4gICAgICAgIHBhdGhFeGFjdD86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIChkZWZhdWx0IGZhbHNlKVxuICAgICAgICAgKiBzaG93IGFsc28gdGhlIGFyY2hpdmVkIGZpbGVzLlxuICAgICAgICAgKiB3aGVuIG11bHRpcGxlIGFyY2hpdmVkIGhhc2ggc2hhcmUgdGhlIHNhbWUgcGF0aCwgb25seSB0aGUgb25lcyB3aXRoIHRoZSBsYXRlc3QgY3JlYXRlX2F0XG4gICAgICAgICAqIGFyZSBkaXNwbGF5ZWQuXG4gICAgICAgICAqXG4gICAgICAgICAqL1xuICAgICAgICBzaG93QXJjaGl2ZWQ/OiBib29sZWFuLFxuICAgICAgICAvKipcbiAgICAgICAgICogKGRlZmF1bHQgZmFsc2UpXG4gICAgICAgICAqIHNob3cgb25seSB0aGUgc3RhcnJlZCBpdGVtc1xuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgc3RhcnJlZE9ubHk/OiBib29sZWFuLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTwoRmxvdyAmIHtcbiAgICAgICAgaGFzX2RyYWZ0PzogYm9vbGVhbjtcbiAgICAgICAgZHJhZnRfb25seT86IGJvb2xlYW47XG4gICAgfSk+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2Zsb3dzL2xpc3QnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAncGFnZSc6IHBhZ2UsXG4gICAgICAgICAgICAgICAgJ3Blcl9wYWdlJzogcGVyUGFnZSxcbiAgICAgICAgICAgICAgICAnb3JkZXJfZGVzYyc6IG9yZGVyRGVzYyxcbiAgICAgICAgICAgICAgICAnY3JlYXRlZF9ieSc6IGNyZWF0ZWRCeSxcbiAgICAgICAgICAgICAgICAncGF0aF9zdGFydCc6IHBhdGhTdGFydCxcbiAgICAgICAgICAgICAgICAncGF0aF9leGFjdCc6IHBhdGhFeGFjdCxcbiAgICAgICAgICAgICAgICAnc2hvd19hcmNoaXZlZCc6IHNob3dBcmNoaXZlZCxcbiAgICAgICAgICAgICAgICAnc3RhcnJlZF9vbmx5Jzogc3RhcnJlZE9ubHksXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgZmxvdyBieSBwYXRoXG4gICAgICogQHJldHVybnMgRmxvdyBmbG93IGRldGFpbHNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRGbG93QnlQYXRoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8Rmxvdz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9mbG93cy9nZXQve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBmbG93IGJ5IHBhdGggd2l0aCBkcmFmdFxuICAgICAqIEByZXR1cm5zIGFueSBmbG93IGRldGFpbHMgd2l0aCBkcmFmdFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdldEZsb3dCeVBhdGhXaXRoRHJhZnQoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTwoRmxvdyAmIHtcbiAgICAgICAgZHJhZnQ/OiBGbG93O1xuICAgIH0pPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2Zsb3dzL2dldC9kcmFmdC97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZXhpc3RzIGZsb3cgYnkgcGF0aFxuICAgICAqIEByZXR1cm5zIGJvb2xlYW4gZmxvdyBkZXRhaWxzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZXhpc3RzRmxvd0J5UGF0aCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPGJvb2xlYW4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZmxvd3MvZXhpc3RzL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjcmVhdGUgZmxvd1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBmbG93IGNyZWF0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGVGbG93KHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogUGFydGlhbGx5IGZpbGxlZCBmbG93XG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogKE9wZW5GbG93V1BhdGggJiB7XG4gICAgICAgICAgICBkcmFmdF9vbmx5PzogYm9vbGVhbjtcbiAgICAgICAgfSksXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZmxvd3MvY3JlYXRlJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHVwZGF0ZSBmbG93XG4gICAgICogQHJldHVybnMgc3RyaW5nIGZsb3cgdXBkYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVwZGF0ZUZsb3coe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFBhcnRpYWxseSBmaWxsZWQgZmxvd1xuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IE9wZW5GbG93V1BhdGgsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZmxvd3MvdXBkYXRlL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogYXJjaGl2ZSBmbG93IGJ5IHBhdGhcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgZmxvdyBhcmNoaXZlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGFyY2hpdmVGbG93QnlQYXRoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBhcmNoaXZlRmxvd1xuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIGFyY2hpdmVkPzogYm9vbGVhbjtcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9mbG93cy9hcmNoaXZlL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlIGZsb3cgYnkgcGF0aFxuICAgICAqIEByZXR1cm5zIHN0cmluZyBmbG93IGRlbGV0ZVxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGRlbGV0ZUZsb3dCeVBhdGgoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdERUxFVEUnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZmxvd3MvZGVsZXRlL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGlucHV0cyBmb3IgcHJldmlvdXMgY29tcGxldGVkIGZsb3cgam9ic1xuICAgICAqIEByZXR1cm5zIElucHV0IGlucHV0IGhpc3RvcnkgZm9yIGNvbXBsZXRlZCBqb2JzIHdpdGggdGhpcyBmbG93IHBhdGhcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRGbG93SW5wdXRIaXN0b3J5QnlQYXRoKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICBwYWdlLFxuICAgICAgICBwZXJQYWdlLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHdoaWNoIHBhZ2UgdG8gcmV0dXJuIChzdGFydCBhdCAxLCBkZWZhdWx0IDEpXG4gICAgICAgICAqL1xuICAgICAgICBwYWdlPzogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogbnVtYmVyIG9mIGl0ZW1zIHRvIHJldHVybiBmb3IgYSBnaXZlbiBwYWdlIChkZWZhdWx0IDMwLCBtYXggMTAwKVxuICAgICAgICAgKi9cbiAgICAgICAgcGVyUGFnZT86IG51bWJlcixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8QXJyYXk8SW5wdXQ+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L2Zsb3dzL2lucHV0X2hpc3RvcnkvcC97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ3BhZ2UnOiBwYWdlLFxuICAgICAgICAgICAgICAgICdwZXJfcGFnZSc6IHBlclBhZ2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQixHQU9sQixTQUFTLE9BQU8sUUFBUSxxQkFBcUI7QUFDN0MsU0FBUyxXQUFXLFNBQVMsUUFBUSxxQkFBcUI7QUFFMUQsT0FBTyxNQUFNO0VBRVQ7Ozs7S0FJQyxHQUNELE9BQWMsZUFTWDtJQUNDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO0lBQ1Q7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsRUFBRSxFQUdMLEVBRUU7SUFDQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixNQUFNO01BQ1Y7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsY0FBYyxFQUN4QixTQUFTLEVBR1osRUFBb0M7SUFDakMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxVQUFVLEVBQ3BCLFNBQVMsRUFDVCxJQUFJLEVBQ0osT0FBTyxFQUNQLFNBQVMsRUFDVCxTQUFTLEVBQ1QsU0FBUyxFQUNULFNBQVMsRUFDVCxZQUFZLEVBQ1osV0FBVyxFQXlDZCxFQUdJO0lBQ0QsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE9BQU87UUFDSCxRQUFRO1FBQ1IsWUFBWTtRQUNaLGNBQWM7UUFDZCxjQUFjO1FBQ2QsY0FBYztRQUNkLGNBQWM7UUFDZCxpQkFBaUI7UUFDakIsZ0JBQWdCO01BQ3BCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGNBQWMsRUFDeEIsU0FBUyxFQUNULElBQUksRUFJUCxFQUEyQjtJQUN4QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLHVCQUF1QixFQUNqQyxTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBRUc7SUFDQSxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGlCQUFpQixFQUMzQixTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBQThCO0lBQzNCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsV0FBVyxFQUNyQixTQUFTLEVBQ1QsV0FBVyxFQVNkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxXQUFXLEVBQ3JCLFNBQVMsRUFDVCxJQUFJLEVBQ0osV0FBVyxFQVFkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxrQkFBa0IsRUFDNUIsU0FBUyxFQUNULElBQUksRUFDSixXQUFXLEVBVWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGlCQUFpQixFQUMzQixTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsMEJBQTBCLEVBQ3BDLFNBQVMsRUFDVCxJQUFJLEVBQ0osSUFBSSxFQUNKLE9BQU8sRUFZVixFQUFtQztJQUNoQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO01BQ0EsT0FBTztRQUNILFFBQVE7UUFDUixZQUFZO01BQ2hCO0lBQ0o7RUFDSjtBQUVKIn0=
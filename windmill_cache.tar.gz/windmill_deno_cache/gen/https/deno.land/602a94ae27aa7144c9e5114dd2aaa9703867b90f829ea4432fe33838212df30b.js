/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class ScheduleService {
  /**
     * preview schedule
     * @returns string List of 5 estimated upcoming execution events (in UTC)
     * @throws ApiError
     */ static previewSchedule({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/schedules/preview',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * create schedule
     * @returns string schedule created
     * @throws ApiError
     */ static createSchedule({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/schedules/create',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * update schedule
     * @returns string schedule updated
     * @throws ApiError
     */ static updateSchedule({ workspace, path, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/schedules/update/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * set enabled schedule
     * @returns string schedule enabled set
     * @throws ApiError
     */ static setScheduleEnabled({ workspace, path, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/schedules/setenabled/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete schedule
     * @returns string schedule deleted
     * @throws ApiError
     */ static deleteSchedule({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/w/{workspace}/schedules/delete/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * get schedule
     * @returns Schedule schedule deleted
     * @throws ApiError
     */ static getSchedule({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/schedules/get/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * does schedule exists
     * @returns boolean schedule exists
     * @throws ApiError
     */ static existsSchedule({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/schedules/exists/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * list schedules
     * @returns Schedule schedule list
     * @throws ApiError
     */ static listSchedules({ workspace, page, perPage }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/schedules/list',
      path: {
        'workspace': workspace
      },
      query: {
        'page': page,
        'per_page': perPage
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvU2NoZWR1bGVTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgRWRpdFNjaGVkdWxlIH0gZnJvbSAnLi4vbW9kZWxzL0VkaXRTY2hlZHVsZS50cyc7XG5pbXBvcnQgdHlwZSB7IE5ld1NjaGVkdWxlIH0gZnJvbSAnLi4vbW9kZWxzL05ld1NjaGVkdWxlLnRzJztcbmltcG9ydCB0eXBlIHsgU2NoZWR1bGUgfSBmcm9tICcuLi9tb2RlbHMvU2NoZWR1bGUudHMnO1xuXG5pbXBvcnQgdHlwZSB7IENhbmNlbGFibGVQcm9taXNlIH0gZnJvbSAnLi4vY29yZS9DYW5jZWxhYmxlUHJvbWlzZS50cyc7XG5pbXBvcnQgeyBPcGVuQVBJIH0gZnJvbSAnLi4vY29yZS9PcGVuQVBJLnRzJztcbmltcG9ydCB7IHJlcXVlc3QgYXMgX19yZXF1ZXN0IH0gZnJvbSAnLi4vY29yZS9yZXF1ZXN0LnRzJztcblxuZXhwb3J0IGNsYXNzIFNjaGVkdWxlU2VydmljZSB7XG5cbiAgICAvKipcbiAgICAgKiBwcmV2aWV3IHNjaGVkdWxlXG4gICAgICogQHJldHVybnMgc3RyaW5nIExpc3Qgb2YgNSBlc3RpbWF0ZWQgdXBjb21pbmcgZXhlY3V0aW9uIGV2ZW50cyAoaW4gVVRDKVxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHByZXZpZXdTY2hlZHVsZSh7XG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHNjaGVkdWxlXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keToge1xuICAgICAgICAgICAgc2NoZWR1bGU6IHN0cmluZztcbiAgICAgICAgICAgIHRpbWV6b25lOiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PHN0cmluZz4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy9zY2hlZHVsZXMvcHJldmlldycsXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBjcmVhdGUgc2NoZWR1bGVcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgc2NoZWR1bGUgY3JlYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGNyZWF0ZVNjaGVkdWxlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogbmV3IHNjaGVkdWxlXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogTmV3U2NoZWR1bGUsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vc2NoZWR1bGVzL2NyZWF0ZScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiB1cGRhdGUgc2NoZWR1bGVcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgc2NoZWR1bGUgdXBkYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVwZGF0ZVNjaGVkdWxlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiB1cGRhdGVkIHNjaGVkdWxlXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogRWRpdFNjaGVkdWxlLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3NjaGVkdWxlcy91cGRhdGUve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBzZXQgZW5hYmxlZCBzY2hlZHVsZVxuICAgICAqIEByZXR1cm5zIHN0cmluZyBzY2hlZHVsZSBlbmFibGVkIHNldFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHNldFNjaGVkdWxlRW5hYmxlZCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogdXBkYXRlZCBzY2hlZHVsZSBlbmFibGVcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBlbmFibGVkOiBib29sZWFuO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3NjaGVkdWxlcy9zZXRlbmFibGVkL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlIHNjaGVkdWxlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHNjaGVkdWxlIGRlbGV0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkZWxldGVTY2hlZHVsZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9zY2hlZHVsZXMvZGVsZXRlL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgc2NoZWR1bGVcbiAgICAgKiBAcmV0dXJucyBTY2hlZHVsZSBzY2hlZHVsZSBkZWxldGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZ2V0U2NoZWR1bGUoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxTY2hlZHVsZT4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9zY2hlZHVsZXMvZ2V0L3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBkb2VzIHNjaGVkdWxlIGV4aXN0c1xuICAgICAqIEByZXR1cm5zIGJvb2xlYW4gc2NoZWR1bGUgZXhpc3RzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZXhpc3RzU2NoZWR1bGUoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxib29sZWFuPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3NjaGVkdWxlcy9leGlzdHMve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxpc3Qgc2NoZWR1bGVzXG4gICAgICogQHJldHVybnMgU2NoZWR1bGUgc2NoZWR1bGUgbGlzdFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RTY2hlZHVsZXMoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhZ2UsXG4gICAgICAgIHBlclBhZ2UsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHdoaWNoIHBhZ2UgdG8gcmV0dXJuIChzdGFydCBhdCAxLCBkZWZhdWx0IDEpXG4gICAgICAgICAqL1xuICAgICAgICBwYWdlPzogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogbnVtYmVyIG9mIGl0ZW1zIHRvIHJldHVybiBmb3IgYSBnaXZlbiBwYWdlIChkZWZhdWx0IDMwLCBtYXggMTAwKVxuICAgICAgICAgKi9cbiAgICAgICAgcGVyUGFnZT86IG51bWJlcixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8QXJyYXk8U2NoZWR1bGU+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3NjaGVkdWxlcy9saXN0JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ3BhZ2UnOiBwYWdlLFxuICAgICAgICAgICAgICAgICdwZXJfcGFnZSc6IHBlclBhZ2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQixHQU1sQixTQUFTLE9BQU8sUUFBUSxxQkFBcUI7QUFDN0MsU0FBUyxXQUFXLFNBQVMsUUFBUSxxQkFBcUI7QUFFMUQsT0FBTyxNQUFNO0VBRVQ7Ozs7S0FJQyxHQUNELE9BQWMsZ0JBQWdCLEVBQzFCLFdBQVcsRUFTZCxFQUFvQztJQUNqQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsU0FBUyxFQUNULFdBQVcsRUFPZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZUFBZSxFQUN6QixTQUFTLEVBQ1QsSUFBSSxFQUNKLFdBQVcsRUFRZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsbUJBQW1CLEVBQzdCLFNBQVMsRUFDVCxJQUFJLEVBQ0osV0FBVyxFQVVkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxlQUFlLEVBQ3pCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxZQUFZLEVBQ3RCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBK0I7SUFDNUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxlQUFlLEVBQ3pCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBOEI7SUFDM0IsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxjQUFjLEVBQ3hCLFNBQVMsRUFDVCxJQUFJLEVBQ0osT0FBTyxFQVdWLEVBQXNDO0lBQ25DLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxPQUFPO1FBQ0gsUUFBUTtRQUNSLFlBQVk7TUFDaEI7SUFDSjtFQUNKO0FBRUoifQ==
/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ export var GlobalUserInfo;
(function(GlobalUserInfo) {
  let login_type;
  (function(login_type) {
    login_type["PASSWORD"] = "password";
    login_type["GITHUB"] = "github";
  })(login_type = GlobalUserInfo.login_type || (GlobalUserInfo.login_type = {}));
})(GlobalUserInfo || (GlobalUserInfo = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvbW9kZWxzL0dsb2JhbFVzZXJJbmZvLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cblxuZXhwb3J0IHR5cGUgR2xvYmFsVXNlckluZm8gPSB7XG4gICAgZW1haWw6IHN0cmluZztcbiAgICBsb2dpbl90eXBlOiBHbG9iYWxVc2VySW5mby5sb2dpbl90eXBlO1xuICAgIHN1cGVyX2FkbWluOiBib29sZWFuO1xuICAgIHZlcmlmaWVkOiBib29sZWFuO1xuICAgIG5hbWU/OiBzdHJpbmc7XG4gICAgY29tcGFueT86IHN0cmluZztcbn07XG5cbmV4cG9ydCBuYW1lc3BhY2UgR2xvYmFsVXNlckluZm8ge1xuXG4gICAgZXhwb3J0IGVudW0gbG9naW5fdHlwZSB7XG4gICAgICAgIFBBU1NXT1JEID0gJ3Bhc3N3b3JkJyxcbiAgICAgICAgR0lUSFVCID0gJ2dpdGh1YicsXG4gICAgfVxuXG5cbn1cblxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCO1VBV0Q7O1lBRUQ7OztLQUFBLDRCQUFBLDhCQUFBO0FBTWhCLEdBUmlCLG1CQUFBIn0=
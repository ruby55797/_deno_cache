/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class WorkspaceService {
  /**
     * list all workspaces visible to me
     * @returns Workspace all workspaces
     * @throws ApiError
     */ static listWorkspaces() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/workspaces/list'
    });
  }
  /**
     * is domain allowed for auto invi
     * @returns boolean domain allowed or not
     * @throws ApiError
     */ static isDomainAllowed() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/workspaces/allowed_domain_auto_invite'
    });
  }
  /**
     * list all workspaces visible to me with user info
     * @returns UserWorkspaceList workspace with associated username
     * @throws ApiError
     */ static listUserWorkspaces() {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/workspaces/users'
    });
  }
  /**
     * list all workspaces as super admin (require to be super admin)
     * @returns Workspace workspaces
     * @throws ApiError
     */ static listWorkspacesAsSuperAdmin({ page, perPage }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/workspaces/list_as_superadmin',
      query: {
        'page': page,
        'per_page': perPage
      }
    });
  }
  /**
     * create workspace
     * @returns string token created
     * @throws ApiError
     */ static createWorkspace({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/workspaces/create',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * exists workspace
     * @returns boolean status
     * @throws ApiError
     */ static existsWorkspace({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/workspaces/exists',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * exists username
     * @returns boolean status
     * @throws ApiError
     */ static existsUsername({ requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/workspaces/exists_username',
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * invite user to workspace
     * @returns string status
     * @throws ApiError
     */ static inviteUser({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/workspaces/invite_user',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * add user to workspace
     * @returns string status
     * @throws ApiError
     */ static addUser({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/workspaces/add_user',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete user invite
     * @returns string status
     * @throws ApiError
     */ static deleteInvite({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/workspaces/delete_invite',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * archive workspace
     * @returns string status
     * @throws ApiError
     */ static archiveWorkspace({ workspace }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/workspaces/archive',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * unarchive workspace
     * @returns string status
     * @throws ApiError
     */ static unarchiveWorkspace({ workspace }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/workspaces/unarchive/{workspace}',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * delete workspace (require super admin)
     * @returns string status
     * @throws ApiError
     */ static deleteWorkspace({ workspace }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/workspaces/delete/{workspace}',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * list pending invites for a workspace
     * @returns WorkspaceInvite user
     * @throws ApiError
     */ static listPendingInvites({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/workspaces/list_pending_invites',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * get settings
     * @returns any status
     * @throws ApiError
     */ static getSettings({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/workspaces/get_settings',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * get premium info
     * @returns any status
     * @throws ApiError
     */ static getPremiumInfo({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/workspaces/premium_info',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * edit slack command
     * @returns string status
     * @throws ApiError
     */ static editSlackCommand({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/workspaces/edit_slack_command',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * edit auto invite
     * @returns string status
     * @throws ApiError
     */ static editAutoInvite({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/workspaces/edit_auto_invite',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * edit webhook
     * @returns string status
     * @throws ApiError
     */ static editWebhook({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/workspaces/edit_webhook',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvV29ya3NwYWNlU2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBpc3RhbmJ1bCBpZ25vcmUgZmlsZSAqL1xuLyogdHNsaW50OmRpc2FibGUgKi9cbi8qIGVzbGludC1kaXNhYmxlICovXG5pbXBvcnQgdHlwZSB7IENyZWF0ZVdvcmtzcGFjZSB9IGZyb20gJy4uL21vZGVscy9DcmVhdGVXb3Jrc3BhY2UudHMnO1xuaW1wb3J0IHR5cGUgeyBVc2VyV29ya3NwYWNlTGlzdCB9IGZyb20gJy4uL21vZGVscy9Vc2VyV29ya3NwYWNlTGlzdC50cyc7XG5pbXBvcnQgdHlwZSB7IFdvcmtzcGFjZSB9IGZyb20gJy4uL21vZGVscy9Xb3Jrc3BhY2UudHMnO1xuaW1wb3J0IHR5cGUgeyBXb3Jrc3BhY2VJbnZpdGUgfSBmcm9tICcuLi9tb2RlbHMvV29ya3NwYWNlSW52aXRlLnRzJztcblxuaW1wb3J0IHR5cGUgeyBDYW5jZWxhYmxlUHJvbWlzZSB9IGZyb20gJy4uL2NvcmUvQ2FuY2VsYWJsZVByb21pc2UudHMnO1xuaW1wb3J0IHsgT3BlbkFQSSB9IGZyb20gJy4uL2NvcmUvT3BlbkFQSS50cyc7XG5pbXBvcnQgeyByZXF1ZXN0IGFzIF9fcmVxdWVzdCB9IGZyb20gJy4uL2NvcmUvcmVxdWVzdC50cyc7XG5cbmV4cG9ydCBjbGFzcyBXb3Jrc3BhY2VTZXJ2aWNlIHtcblxuICAgIC8qKlxuICAgICAqIGxpc3QgYWxsIHdvcmtzcGFjZXMgdmlzaWJsZSB0byBtZVxuICAgICAqIEByZXR1cm5zIFdvcmtzcGFjZSBhbGwgd29ya3NwYWNlc1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RXb3Jrc3BhY2VzKCk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PFdvcmtzcGFjZT4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3dvcmtzcGFjZXMvbGlzdCcsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGlzIGRvbWFpbiBhbGxvd2VkIGZvciBhdXRvIGludmlcbiAgICAgKiBAcmV0dXJucyBib29sZWFuIGRvbWFpbiBhbGxvd2VkIG9yIG5vdFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGlzRG9tYWluQWxsb3dlZCgpOiBDYW5jZWxhYmxlUHJvbWlzZTxib29sZWFuPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93b3Jrc3BhY2VzL2FsbG93ZWRfZG9tYWluX2F1dG9faW52aXRlJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbGlzdCBhbGwgd29ya3NwYWNlcyB2aXNpYmxlIHRvIG1lIHdpdGggdXNlciBpbmZvXG4gICAgICogQHJldHVybnMgVXNlcldvcmtzcGFjZUxpc3Qgd29ya3NwYWNlIHdpdGggYXNzb2NpYXRlZCB1c2VybmFtZVxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGxpc3RVc2VyV29ya3NwYWNlcygpOiBDYW5jZWxhYmxlUHJvbWlzZTxVc2VyV29ya3NwYWNlTGlzdD4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvd29ya3NwYWNlcy91c2VycycsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxpc3QgYWxsIHdvcmtzcGFjZXMgYXMgc3VwZXIgYWRtaW4gKHJlcXVpcmUgdG8gYmUgc3VwZXIgYWRtaW4pXG4gICAgICogQHJldHVybnMgV29ya3NwYWNlIHdvcmtzcGFjZXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBsaXN0V29ya3NwYWNlc0FzU3VwZXJBZG1pbih7XG4gICAgICAgIHBhZ2UsXG4gICAgICAgIHBlclBhZ2UsXG4gICAgfToge1xuICAgICAgICAvKipcbiAgICAgICAgICogd2hpY2ggcGFnZSB0byByZXR1cm4gKHN0YXJ0IGF0IDEsIGRlZmF1bHQgMSlcbiAgICAgICAgICovXG4gICAgICAgIHBhZ2U/OiBudW1iZXIsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBudW1iZXIgb2YgaXRlbXMgdG8gcmV0dXJuIGZvciBhIGdpdmVuIHBhZ2UgKGRlZmF1bHQgMzAsIG1heCAxMDApXG4gICAgICAgICAqL1xuICAgICAgICBwZXJQYWdlPzogbnVtYmVyLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxXb3Jrc3BhY2U+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93b3Jrc3BhY2VzL2xpc3RfYXNfc3VwZXJhZG1pbicsXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdwYWdlJzogcGFnZSxcbiAgICAgICAgICAgICAgICAncGVyX3BhZ2UnOiBwZXJQYWdlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY3JlYXRlIHdvcmtzcGFjZVxuICAgICAqIEByZXR1cm5zIHN0cmluZyB0b2tlbiBjcmVhdGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgY3JlYXRlV29ya3NwYWNlKHtcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICAvKipcbiAgICAgICAgICogbmV3IHRva2VuXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogQ3JlYXRlV29ya3NwYWNlLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93b3Jrc3BhY2VzL2NyZWF0ZScsXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBleGlzdHMgd29ya3NwYWNlXG4gICAgICogQHJldHVybnMgYm9vbGVhbiBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBleGlzdHNXb3Jrc3BhY2Uoe1xuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBpZCBvZiB3b3Jrc3BhY2VcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBpZDogc3RyaW5nO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxib29sZWFuPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvd29ya3NwYWNlcy9leGlzdHMnLFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZXhpc3RzIHVzZXJuYW1lXG4gICAgICogQHJldHVybnMgYm9vbGVhbiBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBleGlzdHNVc2VybmFtZSh7XG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIGlkOiBzdHJpbmc7XG4gICAgICAgICAgICB1c2VybmFtZTogc3RyaW5nO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxib29sZWFuPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvd29ya3NwYWNlcy9leGlzdHNfdXNlcm5hbWUnLFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogaW52aXRlIHVzZXIgdG8gd29ya3NwYWNlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHN0YXR1c1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGludml0ZVVzZXIoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXb3Jrc3BhY2VJbnZpdGVcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBlbWFpbDogc3RyaW5nO1xuICAgICAgICAgICAgaXNfYWRtaW46IGJvb2xlYW47XG4gICAgICAgICAgICBvcGVyYXRvcjogYm9vbGVhbjtcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS93b3Jrc3BhY2VzL2ludml0ZV91c2VyJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGFkZCB1c2VyIHRvIHdvcmtzcGFjZVxuICAgICAqIEByZXR1cm5zIHN0cmluZyBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBhZGRVc2VyKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogV29ya3NwYWNlSW52aXRlXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keToge1xuICAgICAgICAgICAgZW1haWw6IHN0cmluZztcbiAgICAgICAgICAgIGlzX2FkbWluOiBib29sZWFuO1xuICAgICAgICAgICAgdXNlcm5hbWU6IHN0cmluZztcbiAgICAgICAgICAgIG9wZXJhdG9yOiBib29sZWFuO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3dvcmtzcGFjZXMvYWRkX3VzZXInLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlIHVzZXIgaW52aXRlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHN0YXR1c1xuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGRlbGV0ZUludml0ZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFdvcmtzcGFjZUludml0ZVxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIGVtYWlsOiBzdHJpbmc7XG4gICAgICAgICAgICBpc19hZG1pbjogYm9vbGVhbjtcbiAgICAgICAgICAgIG9wZXJhdG9yOiBib29sZWFuO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3dvcmtzcGFjZXMvZGVsZXRlX2ludml0ZScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBhcmNoaXZlIHdvcmtzcGFjZVxuICAgICAqIEByZXR1cm5zIHN0cmluZyBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBhcmNoaXZlV29ya3NwYWNlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vd29ya3NwYWNlcy9hcmNoaXZlJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogdW5hcmNoaXZlIHdvcmtzcGFjZVxuICAgICAqIEByZXR1cm5zIHN0cmluZyBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyB1bmFyY2hpdmVXb3Jrc3BhY2Uoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvd29ya3NwYWNlcy91bmFyY2hpdmUve3dvcmtzcGFjZX0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBkZWxldGUgd29ya3NwYWNlIChyZXF1aXJlIHN1cGVyIGFkbWluKVxuICAgICAqIEByZXR1cm5zIHN0cmluZyBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkZWxldGVXb3Jrc3BhY2Uoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgICAgICAgIHVybDogJy93b3Jrc3BhY2VzL2RlbGV0ZS97d29ya3NwYWNlfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxpc3QgcGVuZGluZyBpbnZpdGVzIGZvciBhIHdvcmtzcGFjZVxuICAgICAqIEByZXR1cm5zIFdvcmtzcGFjZUludml0ZSB1c2VyXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdFBlbmRpbmdJbnZpdGVzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PFdvcmtzcGFjZUludml0ZT4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vd29ya3NwYWNlcy9saXN0X3BlbmRpbmdfaW52aXRlcycsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCBzZXR0aW5nc1xuICAgICAqIEByZXR1cm5zIGFueSBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRTZXR0aW5ncyh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTx7XG4gICAgICAgIHdvcmtzcGFjZV9pZD86IHN0cmluZztcbiAgICAgICAgc2xhY2tfbmFtZT86IHN0cmluZztcbiAgICAgICAgc2xhY2tfdGVhbV9pZD86IHN0cmluZztcbiAgICAgICAgc2xhY2tfY29tbWFuZF9zY3JpcHQ/OiBzdHJpbmc7XG4gICAgICAgIGF1dG9faW52aXRlX2RvbWFpbj86IHN0cmluZztcbiAgICAgICAgYXV0b19pbnZpdGVfb3BlcmF0b3I/OiBib29sZWFuO1xuICAgICAgICBwbGFuPzogc3RyaW5nO1xuICAgICAgICBjdXN0b21lcl9pZD86IHN0cmluZztcbiAgICAgICAgd2ViaG9vaz86IHN0cmluZztcbiAgICB9PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3dvcmtzcGFjZXMvZ2V0X3NldHRpbmdzJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZ2V0IHByZW1pdW0gaW5mb1xuICAgICAqIEByZXR1cm5zIGFueSBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRQcmVtaXVtSW5mbyh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTx7XG4gICAgICAgIHByZW1pdW06IGJvb2xlYW47XG4gICAgICAgIHVzYWdlPzogbnVtYmVyO1xuICAgIH0+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vd29ya3NwYWNlcy9wcmVtaXVtX2luZm8nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBlZGl0IHNsYWNrIGNvbW1hbmRcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgc3RhdHVzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZWRpdFNsYWNrQ29tbWFuZCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFdvcmtzcGFjZUludml0ZVxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIHNsYWNrX2NvbW1hbmRfc2NyaXB0Pzogc3RyaW5nO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3dvcmtzcGFjZXMvZWRpdF9zbGFja19jb21tYW5kJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGVkaXQgYXV0byBpbnZpdGVcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgc3RhdHVzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZWRpdEF1dG9JbnZpdGUoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXb3Jrc3BhY2VJbnZpdGVcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICBvcGVyYXRvcj86IGJvb2xlYW47XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vd29ya3NwYWNlcy9lZGl0X2F1dG9faW52aXRlJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGVkaXQgd2ViaG9va1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBzdGF0dXNcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBlZGl0V2ViaG9vayh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFdvcmtzcGFjZVdlYmhvb2tcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICB3ZWJob29rPzogc3RyaW5nO1xuICAgICAgICB9LFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3dvcmtzcGFjZXMvZWRpdF93ZWJob29rJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCLEdBT2xCLFNBQVMsT0FBTyxRQUFRLHFCQUFxQjtBQUM3QyxTQUFTLFdBQVcsU0FBUyxRQUFRLHFCQUFxQjtBQUUxRCxPQUFPLE1BQU07RUFFVDs7OztLQUlDLEdBQ0QsT0FBYyxpQkFBc0Q7SUFDaEUsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7SUFDVDtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsa0JBQThDO0lBQ3hELE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO0lBQ1Q7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLHFCQUEyRDtJQUNyRSxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztJQUNUO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYywyQkFBMkIsRUFDckMsSUFBSSxFQUNKLE9BQU8sRUFVVixFQUF1QztJQUNwQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE9BQU87UUFDSCxRQUFRO1FBQ1IsWUFBWTtNQUNoQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxnQkFBZ0IsRUFDMUIsV0FBVyxFQU1kLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZ0JBQWdCLEVBQzFCLFdBQVcsRUFRZCxFQUE4QjtJQUMzQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsV0FBVyxFQU1kLEVBQThCO0lBQzNCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsV0FBVyxFQUNyQixTQUFTLEVBQ1QsV0FBVyxFQVdkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxRQUFRLEVBQ2xCLFNBQVMsRUFDVCxXQUFXLEVBWWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGFBQWEsRUFDdkIsU0FBUyxFQUNULFdBQVcsRUFXZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsaUJBQWlCLEVBQzNCLFNBQVMsRUFHWixFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG1CQUFtQixFQUM3QixTQUFTLEVBR1osRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxnQkFBZ0IsRUFDMUIsU0FBUyxFQUdaLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsbUJBQW1CLEVBQzdCLFNBQVMsRUFHWixFQUE2QztJQUMxQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFlBQVksRUFDdEIsU0FBUyxFQUdaLEVBVUU7SUFDQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsU0FBUyxFQUdaLEVBR0U7SUFDQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGlCQUFpQixFQUMzQixTQUFTLEVBQ1QsV0FBVyxFQVNkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxlQUFlLEVBQ3pCLFNBQVMsRUFDVCxXQUFXLEVBU2QsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFlBQVksRUFDdEIsU0FBUyxFQUNULFdBQVcsRUFTZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0FBRUoifQ==
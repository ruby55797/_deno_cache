import { Client } from "https://deno.land/x/postgres@v0.17.0/mod.ts";
/**
 * deno-postgres client API is very flexible:
 * https://deno.land/x/postgres@v0.17.0/mod.ts?s=QueryClient
 * 
 * @param db the PostgreSQL resource to generate the client for
 * 
 * @returns the client for the resource
 * 
 * @example
 * // Static query
 * ```ts
 * const { rows } = await pgClient(db).queryObject(
 *   "SELECT ID, NAME FROM CLIENTS"
 * );
 * ```
 * 
 * // Prepared Statements
 * ```ts
 * const { rows } = await pgClient(db).queryObject`SELECT ID, NAME FROM CLIENTS WHERE ID = ${id}`;
 * ```
 */ export function pgClient(db) {
  const databaseUrl = 'postgresql://' + db.user + ':' + db.password + '@' + db.host + ':' + db.port + '/' + db.dbname + '?sslmode=' + db.sslmode;
  return new Client(databaseUrl);
}
/**
 * deno-postgres client API is very flexible:
 * https://deno.land/x/postgres@v0.17.0/mod.ts?s=QueryClient
 * 
 * @param db the PostgreSQL resource to run sql query for
 * 
 * @returns the rows corresponding to the returned objetcs
 * 
 * @example
 * // Prepared Statements
 * ```ts
 * const { rows } = await pgSql(db)`SELECT ID, NAME FROM CLIENTS WHERE ID = ${id}`;
 * ```
 */ export function pgSql(db, asObjects = false) {
  return async function queryObject(query, ...args) {
    const client = pgClient(db);
    return asObjects ? await client.queryObject(query, ...args) : await client.queryArray(query, ...args);
  };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC9wZy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDbGllbnQgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQveC9wb3N0Z3Jlc0B2MC4xNy4wL21vZC50c1wiXG5pbXBvcnQgeyB0eXBlIFJlc291cmNlIH0gZnJvbSBcIi4vbW9kLnRzXCJcblxuLyoqXG4gKiBkZW5vLXBvc3RncmVzIGNsaWVudCBBUEkgaXMgdmVyeSBmbGV4aWJsZTpcbiAqIGh0dHBzOi8vZGVuby5sYW5kL3gvcG9zdGdyZXNAdjAuMTcuMC9tb2QudHM/cz1RdWVyeUNsaWVudFxuICogXG4gKiBAcGFyYW0gZGIgdGhlIFBvc3RncmVTUUwgcmVzb3VyY2UgdG8gZ2VuZXJhdGUgdGhlIGNsaWVudCBmb3JcbiAqIFxuICogQHJldHVybnMgdGhlIGNsaWVudCBmb3IgdGhlIHJlc291cmNlXG4gKiBcbiAqIEBleGFtcGxlXG4gKiAvLyBTdGF0aWMgcXVlcnlcbiAqIGBgYHRzXG4gKiBjb25zdCB7IHJvd3MgfSA9IGF3YWl0IHBnQ2xpZW50KGRiKS5xdWVyeU9iamVjdChcbiAqICAgXCJTRUxFQ1QgSUQsIE5BTUUgRlJPTSBDTElFTlRTXCJcbiAqICk7XG4gKiBgYGBcbiAqIFxuICogLy8gUHJlcGFyZWQgU3RhdGVtZW50c1xuICogYGBgdHNcbiAqIGNvbnN0IHsgcm93cyB9ID0gYXdhaXQgcGdDbGllbnQoZGIpLnF1ZXJ5T2JqZWN0YFNFTEVDVCBJRCwgTkFNRSBGUk9NIENMSUVOVFMgV0hFUkUgSUQgPSAke2lkfWA7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBnQ2xpZW50KFxuICAgIGRiOiBSZXNvdXJjZTxcInBvc3RncmVzcWxcIj5cbikge1xuICAgIGNvbnN0IGRhdGFiYXNlVXJsID0gJ3Bvc3RncmVzcWw6Ly8nICsgZGIudXNlciArICc6JyArIGRiLnBhc3N3b3JkICsgJ0AnICsgZGIuaG9zdCArICc6JyArIGRiLnBvcnQgKyAnLycgKyBkYi5kYm5hbWUgKyAnP3NzbG1vZGU9JyArIGRiLnNzbG1vZGVcbiAgICByZXR1cm4gbmV3IENsaWVudChkYXRhYmFzZVVybClcbn1cblxuLyoqXG4gKiBkZW5vLXBvc3RncmVzIGNsaWVudCBBUEkgaXMgdmVyeSBmbGV4aWJsZTpcbiAqIGh0dHBzOi8vZGVuby5sYW5kL3gvcG9zdGdyZXNAdjAuMTcuMC9tb2QudHM/cz1RdWVyeUNsaWVudFxuICogXG4gKiBAcGFyYW0gZGIgdGhlIFBvc3RncmVTUUwgcmVzb3VyY2UgdG8gcnVuIHNxbCBxdWVyeSBmb3JcbiAqIFxuICogQHJldHVybnMgdGhlIHJvd3MgY29ycmVzcG9uZGluZyB0byB0aGUgcmV0dXJuZWQgb2JqZXRjc1xuICogXG4gKiBAZXhhbXBsZVxuICogLy8gUHJlcGFyZWQgU3RhdGVtZW50c1xuICogYGBgdHNcbiAqIGNvbnN0IHsgcm93cyB9ID0gYXdhaXQgcGdTcWwoZGIpYFNFTEVDVCBJRCwgTkFNRSBGUk9NIENMSUVOVFMgV0hFUkUgSUQgPSAke2lkfWA7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBnU3FsKFxuICAgIGRiOiBSZXNvdXJjZTxcInBvc3RncmVzcWxcIj4sXG4gICAgYXNPYmplY3RzID0gZmFsc2Vcbikge1xuICAgIHJldHVybiBhc3luYyBmdW5jdGlvbiBxdWVyeU9iamVjdChcbiAgICAgICAgcXVlcnk6IFRlbXBsYXRlU3RyaW5nc0FycmF5LFxuICAgICAgICAuLi5hcmdzOiB1bmtub3duW11cbiAgICApIHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gcGdDbGllbnQoZGIpXG4gICAgICAgIHJldHVybiBhc09iamVjdHMgPyBhd2FpdCBjbGllbnQucXVlcnlPYmplY3QocXVlcnksIC4uLmFyZ3MpIDogYXdhaXQgY2xpZW50LnF1ZXJ5QXJyYXkocXVlcnksIC4uLmFyZ3MpXG4gICAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsTUFBTSxRQUFRLDhDQUE2QztBQUdwRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvQkMsR0FDRCxPQUFPLFNBQVMsU0FDWixFQUEwQjtFQUUxQixNQUFNLGNBQWMsa0JBQWtCLEdBQUcsSUFBSSxHQUFHLE1BQU0sR0FBRyxRQUFRLEdBQUcsTUFBTSxHQUFHLElBQUksR0FBRyxNQUFNLEdBQUcsSUFBSSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsY0FBYyxHQUFHLE9BQU87RUFDOUksT0FBTyxJQUFJLE9BQU87QUFDdEI7QUFFQTs7Ozs7Ozs7Ozs7OztDQWFDLEdBQ0QsT0FBTyxTQUFTLE1BQ1osRUFBMEIsRUFDMUIsWUFBWSxLQUFLO0VBRWpCLE9BQU8sZUFBZSxZQUNsQixLQUEyQixFQUMzQixHQUFHLElBQWU7SUFFbEIsTUFBTSxTQUFTLFNBQVM7SUFDeEIsT0FBTyxZQUFZLE1BQU0sT0FBTyxXQUFXLENBQUMsVUFBVSxRQUFRLE1BQU0sT0FBTyxVQUFVLENBQUMsVUFBVTtFQUNwRztBQUNKIn0=
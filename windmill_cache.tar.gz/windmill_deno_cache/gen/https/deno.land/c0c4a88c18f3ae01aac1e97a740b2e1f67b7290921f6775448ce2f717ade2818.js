/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class GroupService {
  /**
     * list groups
     * @returns Group group list
     * @throws ApiError
     */ static listGroups({ workspace, page, perPage }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/groups/list',
      path: {
        'workspace': workspace
      },
      query: {
        'page': page,
        'per_page': perPage
      }
    });
  }
  /**
     * list group names
     * @returns string group list
     * @throws ApiError
     */ static listGroupNames({ workspace, onlyMemberOf }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/groups/listnames',
      path: {
        'workspace': workspace
      },
      query: {
        'only_member_of': onlyMemberOf
      }
    });
  }
  /**
     * create group
     * @returns string group created
     * @throws ApiError
     */ static createGroup({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/groups/create',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * update group
     * @returns string group updated
     * @throws ApiError
     */ static updateGroup({ workspace, name, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/groups/update/{name}',
      path: {
        'workspace': workspace,
        'name': name
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete group
     * @returns string group deleted
     * @throws ApiError
     */ static deleteGroup({ workspace, name }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/w/{workspace}/groups/delete/{name}',
      path: {
        'workspace': workspace,
        'name': name
      }
    });
  }
  /**
     * get group
     * @returns Group group
     * @throws ApiError
     */ static getGroup({ workspace, name }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/groups/get/{name}',
      path: {
        'workspace': workspace,
        'name': name
      }
    });
  }
  /**
     * add user to group
     * @returns string user added to group
     * @throws ApiError
     */ static addUserToGroup({ workspace, name, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/groups/adduser/{name}',
      path: {
        'workspace': workspace,
        'name': name
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * remove user to group
     * @returns string user removed from group
     * @throws ApiError
     */ static removeUserToGroup({ workspace, name, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/groups/removeuser/{name}',
      path: {
        'workspace': workspace,
        'name': name
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvR3JvdXBTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgR3JvdXAgfSBmcm9tICcuLi9tb2RlbHMvR3JvdXAudHMnO1xuXG5pbXBvcnQgdHlwZSB7IENhbmNlbGFibGVQcm9taXNlIH0gZnJvbSAnLi4vY29yZS9DYW5jZWxhYmxlUHJvbWlzZS50cyc7XG5pbXBvcnQgeyBPcGVuQVBJIH0gZnJvbSAnLi4vY29yZS9PcGVuQVBJLnRzJztcbmltcG9ydCB7IHJlcXVlc3QgYXMgX19yZXF1ZXN0IH0gZnJvbSAnLi4vY29yZS9yZXF1ZXN0LnRzJztcblxuZXhwb3J0IGNsYXNzIEdyb3VwU2VydmljZSB7XG5cbiAgICAvKipcbiAgICAgKiBsaXN0IGdyb3Vwc1xuICAgICAqIEByZXR1cm5zIEdyb3VwIGdyb3VwIGxpc3RcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBsaXN0R3JvdXBzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYWdlLFxuICAgICAgICBwZXJQYWdlLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiB3aGljaCBwYWdlIHRvIHJldHVybiAoc3RhcnQgYXQgMSwgZGVmYXVsdCAxKVxuICAgICAgICAgKi9cbiAgICAgICAgcGFnZT86IG51bWJlcixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG51bWJlciBvZiBpdGVtcyB0byByZXR1cm4gZm9yIGEgZ2l2ZW4gcGFnZSAoZGVmYXVsdCAzMCwgbWF4IDEwMClcbiAgICAgICAgICovXG4gICAgICAgIHBlclBhZ2U/OiBudW1iZXIsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PEdyb3VwPj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9ncm91cHMvbGlzdCcsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdwYWdlJzogcGFnZSxcbiAgICAgICAgICAgICAgICAncGVyX3BhZ2UnOiBwZXJQYWdlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbGlzdCBncm91cCBuYW1lc1xuICAgICAqIEByZXR1cm5zIHN0cmluZyBncm91cCBsaXN0XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdEdyb3VwTmFtZXMoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIG9ubHlNZW1iZXJPZixcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogb25seSBsaXN0IHRoZSBncm91cHMgdGhlIHVzZXIgaXMgbWVtYmVyIG9mIChkZWZhdWx0IGZhbHNlKVxuICAgICAgICAgKi9cbiAgICAgICAgb25seU1lbWJlck9mPzogYm9vbGVhbixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8QXJyYXk8c3RyaW5nPj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9ncm91cHMvbGlzdG5hbWVzJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ29ubHlfbWVtYmVyX29mJzogb25seU1lbWJlck9mLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY3JlYXRlIGdyb3VwXG4gICAgICogQHJldHVybnMgc3RyaW5nIGdyb3VwIGNyZWF0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGVHcm91cCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIGNyZWF0ZSBncm91cFxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IHtcbiAgICAgICAgICAgIG5hbWU6IHN0cmluZztcbiAgICAgICAgICAgIHN1bW1hcnk/OiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZ3JvdXBzL2NyZWF0ZScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiB1cGRhdGUgZ3JvdXBcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgZ3JvdXAgdXBkYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVwZGF0ZUdyb3VwKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBuYW1lLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBuYW1lOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiB1cGRhdGVkIGdyb3VwXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keToge1xuICAgICAgICAgICAgc3VtbWFyeT86IHN0cmluZztcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9ncm91cHMvdXBkYXRlL3tuYW1lfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAnbmFtZSc6IG5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlIGdyb3VwXG4gICAgICogQHJldHVybnMgc3RyaW5nIGdyb3VwIGRlbGV0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkZWxldGVHcm91cCh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgbmFtZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBuYW1lOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9ncm91cHMvZGVsZXRlL3tuYW1lfScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAnbmFtZSc6IG5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgZ3JvdXBcbiAgICAgKiBAcmV0dXJucyBHcm91cCBncm91cFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdldEdyb3VwKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBuYW1lLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIG5hbWU6IHN0cmluZyxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8R3JvdXA+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZ3JvdXBzL2dldC97bmFtZX0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ25hbWUnOiBuYW1lLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogYWRkIHVzZXIgdG8gZ3JvdXBcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgdXNlciBhZGRlZCB0byBncm91cFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGFkZFVzZXJUb0dyb3VwKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBuYW1lLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBuYW1lOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBhZGRlZCB1c2VyIHRvIGdyb3VwXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keToge1xuICAgICAgICAgICAgdXNlcm5hbWU/OiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZ3JvdXBzL2FkZHVzZXIve25hbWV9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICduYW1lJzogbmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiByZW1vdmUgdXNlciB0byBncm91cFxuICAgICAqIEByZXR1cm5zIHN0cmluZyB1c2VyIHJlbW92ZWQgZnJvbSBncm91cFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHJlbW92ZVVzZXJUb0dyb3VwKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBuYW1lLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBuYW1lOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBhZGRlZCB1c2VyIHRvIGdyb3VwXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keToge1xuICAgICAgICAgICAgdXNlcm5hbWU/OiBzdHJpbmc7XG4gICAgICAgIH0sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vZ3JvdXBzL3JlbW92ZXVzZXIve25hbWV9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICduYW1lJzogbmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQixHQUlsQixTQUFTLE9BQU8sUUFBUSxxQkFBcUI7QUFDN0MsU0FBUyxXQUFXLFNBQVMsUUFBUSxxQkFBcUI7QUFFMUQsT0FBTyxNQUFNO0VBRVQ7Ozs7S0FJQyxHQUNELE9BQWMsV0FBVyxFQUNyQixTQUFTLEVBQ1QsSUFBSSxFQUNKLE9BQU8sRUFXVixFQUFtQztJQUNoQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsT0FBTztRQUNILFFBQVE7UUFDUixZQUFZO01BQ2hCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsU0FBUyxFQUNULFlBQVksRUFPZixFQUFvQztJQUNqQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsT0FBTztRQUNILGtCQUFrQjtNQUN0QjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxZQUFZLEVBQ3RCLFNBQVMsRUFDVCxXQUFXLEVBVWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFlBQVksRUFDdEIsU0FBUyxFQUNULElBQUksRUFDSixXQUFXLEVBVWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFlBQVksRUFDdEIsU0FBUyxFQUNULElBQUksRUFJUCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLFNBQVMsRUFDbkIsU0FBUyxFQUNULElBQUksRUFJUCxFQUE0QjtJQUN6QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsU0FBUyxFQUNULElBQUksRUFDSixXQUFXLEVBVWQsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGtCQUFrQixFQUM1QixTQUFTLEVBQ1QsSUFBSSxFQUNKLFdBQVcsRUFVZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0FBRUoifQ==
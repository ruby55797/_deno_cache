/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class VariableService {
  /**
     * create variable
     * @returns string variable created
     * @throws ApiError
     */ static createVariable({ workspace, requestBody, alreadyEncrypted }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/variables/create',
      path: {
        'workspace': workspace
      },
      query: {
        'already_encrypted': alreadyEncrypted
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete variable
     * @returns string variable deleted
     * @throws ApiError
     */ static deleteVariable({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/w/{workspace}/variables/delete/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * update variable
     * @returns string variable updated
     * @throws ApiError
     */ static updateVariable({ workspace, path, requestBody, alreadyEncrypted }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/variables/update/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      query: {
        'already_encrypted': alreadyEncrypted
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * get variable
     * @returns ListableVariable variable
     * @throws ApiError
     */ static getVariable({ workspace, path, decryptSecret }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/variables/get/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      query: {
        'decrypt_secret': decryptSecret
      }
    });
  }
  /**
     * does variable exists at path
     * @returns boolean variable
     * @throws ApiError
     */ static existsVariable({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/variables/exists/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * list variables
     * @returns ListableVariable variable list
     * @throws ApiError
     */ static listVariable({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/variables/list',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * list contextual variables
     * @returns ContextualVariable contextual variable list
     * @throws ApiError
     */ static listContextualVariables({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/variables/list_contextual',
      path: {
        'workspace': workspace
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvVmFyaWFibGVTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgQ29udGV4dHVhbFZhcmlhYmxlIH0gZnJvbSAnLi4vbW9kZWxzL0NvbnRleHR1YWxWYXJpYWJsZS50cyc7XG5pbXBvcnQgdHlwZSB7IENyZWF0ZVZhcmlhYmxlIH0gZnJvbSAnLi4vbW9kZWxzL0NyZWF0ZVZhcmlhYmxlLnRzJztcbmltcG9ydCB0eXBlIHsgRWRpdFZhcmlhYmxlIH0gZnJvbSAnLi4vbW9kZWxzL0VkaXRWYXJpYWJsZS50cyc7XG5pbXBvcnQgdHlwZSB7IExpc3RhYmxlVmFyaWFibGUgfSBmcm9tICcuLi9tb2RlbHMvTGlzdGFibGVWYXJpYWJsZS50cyc7XG5cbmltcG9ydCB0eXBlIHsgQ2FuY2VsYWJsZVByb21pc2UgfSBmcm9tICcuLi9jb3JlL0NhbmNlbGFibGVQcm9taXNlLnRzJztcbmltcG9ydCB7IE9wZW5BUEkgfSBmcm9tICcuLi9jb3JlL09wZW5BUEkudHMnO1xuaW1wb3J0IHsgcmVxdWVzdCBhcyBfX3JlcXVlc3QgfSBmcm9tICcuLi9jb3JlL3JlcXVlc3QudHMnO1xuXG5leHBvcnQgY2xhc3MgVmFyaWFibGVTZXJ2aWNlIHtcblxuICAgIC8qKlxuICAgICAqIGNyZWF0ZSB2YXJpYWJsZVxuICAgICAqIEByZXR1cm5zIHN0cmluZyB2YXJpYWJsZSBjcmVhdGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgY3JlYXRlVmFyaWFibGUoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgICAgICBhbHJlYWR5RW5jcnlwdGVkLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBuZXcgdmFyaWFibGVcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiBDcmVhdGVWYXJpYWJsZSxcbiAgICAgICAgYWxyZWFkeUVuY3J5cHRlZD86IGJvb2xlYW4sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vdmFyaWFibGVzL2NyZWF0ZScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdhbHJlYWR5X2VuY3J5cHRlZCc6IGFscmVhZHlFbmNyeXB0ZWQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlIHZhcmlhYmxlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHZhcmlhYmxlIGRlbGV0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkZWxldGVWYXJpYWJsZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS92YXJpYWJsZXMvZGVsZXRlL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiB1cGRhdGUgdmFyaWFibGVcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgdmFyaWFibGUgdXBkYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVwZGF0ZVZhcmlhYmxlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICAgICAgYWxyZWFkeUVuY3J5cHRlZCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiB1cGRhdGVkIHZhcmlhYmxlXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogRWRpdFZhcmlhYmxlLFxuICAgICAgICBhbHJlYWR5RW5jcnlwdGVkPzogYm9vbGVhbixcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS92YXJpYWJsZXMvdXBkYXRlL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICAnYWxyZWFkeV9lbmNyeXB0ZWQnOiBhbHJlYWR5RW5jcnlwdGVkLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCB2YXJpYWJsZVxuICAgICAqIEByZXR1cm5zIExpc3RhYmxlVmFyaWFibGUgdmFyaWFibGVcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRWYXJpYWJsZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICAgICAgZGVjcnlwdFNlY3JldCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBhc2sgdG8gZGVjcnlwdCBzZWNyZXQgaWYgdGhpcyB2YXJpYWJsZSBpcyBzZWNyZXRcbiAgICAgICAgICogKGlmIG5vdCBzZWNyZXQgbm8gZWZmZWN0LCBkZWZhdWx0OiB0cnVlKVxuICAgICAgICAgKlxuICAgICAgICAgKi9cbiAgICAgICAgZGVjcnlwdFNlY3JldD86IGJvb2xlYW4sXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPExpc3RhYmxlVmFyaWFibGU+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vdmFyaWFibGVzL2dldC97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgJ2RlY3J5cHRfc2VjcmV0JzogZGVjcnlwdFNlY3JldCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGRvZXMgdmFyaWFibGUgZXhpc3RzIGF0IHBhdGhcbiAgICAgKiBAcmV0dXJucyBib29sZWFuIHZhcmlhYmxlXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZXhpc3RzVmFyaWFibGUoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxib29sZWFuPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3ZhcmlhYmxlcy9leGlzdHMve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxpc3QgdmFyaWFibGVzXG4gICAgICogQHJldHVybnMgTGlzdGFibGVWYXJpYWJsZSB2YXJpYWJsZSBsaXN0XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdFZhcmlhYmxlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PExpc3RhYmxlVmFyaWFibGU+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3ZhcmlhYmxlcy9saXN0JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbGlzdCBjb250ZXh0dWFsIHZhcmlhYmxlc1xuICAgICAqIEByZXR1cm5zIENvbnRleHR1YWxWYXJpYWJsZSBjb250ZXh0dWFsIHZhcmlhYmxlIGxpc3RcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBsaXN0Q29udGV4dHVhbFZhcmlhYmxlcyh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxDb250ZXh0dWFsVmFyaWFibGU+PiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3ZhcmlhYmxlcy9saXN0X2NvbnRleHR1YWwnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQixHQU9sQixTQUFTLE9BQU8sUUFBUSxxQkFBcUI7QUFDN0MsU0FBUyxXQUFXLFNBQVMsUUFBUSxxQkFBcUI7QUFFMUQsT0FBTyxNQUFNO0VBRVQ7Ozs7S0FJQyxHQUNELE9BQWMsZUFBZSxFQUN6QixTQUFTLEVBQ1QsV0FBVyxFQUNYLGdCQUFnQixFQVFuQixFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsT0FBTztRQUNILHFCQUFxQjtNQUN6QjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsU0FBUyxFQUNULElBQUksRUFJUCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsU0FBUyxFQUNULElBQUksRUFDSixXQUFXLEVBQ1gsZ0JBQWdCLEVBU25CLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7TUFDQSxPQUFPO1FBQ0gscUJBQXFCO01BQ3pCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsWUFBWSxFQUN0QixTQUFTLEVBQ1QsSUFBSSxFQUNKLGFBQWEsRUFVaEIsRUFBdUM7SUFDcEMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtNQUNBLE9BQU87UUFDSCxrQkFBa0I7TUFDdEI7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZUFBZSxFQUN6QixTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBQThCO0lBQzNCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsYUFBYSxFQUN2QixTQUFTLEVBR1osRUFBOEM7SUFDM0MsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyx3QkFBd0IsRUFDbEMsU0FBUyxFQUdaLEVBQWdEO0lBQzdDLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7TUFDakI7SUFDSjtFQUNKO0FBRUoifQ==
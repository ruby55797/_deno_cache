/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ export var AuditLog;
(function(AuditLog) {
  let operation;
  (function(operation) {
    operation["JOBS_RUN"] = "jobs.run";
    operation["SCRIPTS_CREATE"] = "scripts.create";
    operation["SCRIPTS_UPDATE"] = "scripts.update";
    operation["USERS_CREATE"] = "users.create";
    operation["USERS_DELETE"] = "users.delete";
    operation["USERS_SETPASSWORD"] = "users.setpassword";
    operation["USERS_UPDATE"] = "users.update";
    operation["USERS_LOGIN"] = "users.login";
    operation["USERS_TOKEN_CREATE"] = "users.token.create";
    operation["USERS_TOKEN_DELETE"] = "users.token.delete";
    operation["VARIABLES_CREATE"] = "variables.create";
    operation["VARIABLES_DELETE"] = "variables.delete";
    operation["VARIABLES_UPDATE"] = "variables.update";
  })(operation = AuditLog.operation || (AuditLog.operation = {}));
  let action_kind;
  (function(action_kind) {
    action_kind["CREATED"] = "Created";
    action_kind["UPDATED"] = "Updated";
    action_kind["DELETE"] = "Delete";
    action_kind["EXECUTE"] = "Execute";
  })(action_kind = AuditLog.action_kind || (AuditLog.action_kind = {}));
})(AuditLog || (AuditLog = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvbW9kZWxzL0F1ZGl0TG9nLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cblxuZXhwb3J0IHR5cGUgQXVkaXRMb2cgPSB7XG4gICAgaWQ6IG51bWJlcjtcbiAgICB0aW1lc3RhbXA6IHN0cmluZztcbiAgICB1c2VybmFtZTogc3RyaW5nO1xuICAgIG9wZXJhdGlvbjogQXVkaXRMb2cub3BlcmF0aW9uO1xuICAgIGFjdGlvbl9raW5kOiBBdWRpdExvZy5hY3Rpb25fa2luZDtcbiAgICByZXNvdXJjZT86IHN0cmluZztcbiAgICBwYXJhbWV0ZXJzPzogYW55O1xufTtcblxuZXhwb3J0IG5hbWVzcGFjZSBBdWRpdExvZyB7XG5cbiAgICBleHBvcnQgZW51bSBvcGVyYXRpb24ge1xuICAgICAgICBKT0JTX1JVTiA9ICdqb2JzLnJ1bicsXG4gICAgICAgIFNDUklQVFNfQ1JFQVRFID0gJ3NjcmlwdHMuY3JlYXRlJyxcbiAgICAgICAgU0NSSVBUU19VUERBVEUgPSAnc2NyaXB0cy51cGRhdGUnLFxuICAgICAgICBVU0VSU19DUkVBVEUgPSAndXNlcnMuY3JlYXRlJyxcbiAgICAgICAgVVNFUlNfREVMRVRFID0gJ3VzZXJzLmRlbGV0ZScsXG4gICAgICAgIFVTRVJTX1NFVFBBU1NXT1JEID0gJ3VzZXJzLnNldHBhc3N3b3JkJyxcbiAgICAgICAgVVNFUlNfVVBEQVRFID0gJ3VzZXJzLnVwZGF0ZScsXG4gICAgICAgIFVTRVJTX0xPR0lOID0gJ3VzZXJzLmxvZ2luJyxcbiAgICAgICAgVVNFUlNfVE9LRU5fQ1JFQVRFID0gJ3VzZXJzLnRva2VuLmNyZWF0ZScsXG4gICAgICAgIFVTRVJTX1RPS0VOX0RFTEVURSA9ICd1c2Vycy50b2tlbi5kZWxldGUnLFxuICAgICAgICBWQVJJQUJMRVNfQ1JFQVRFID0gJ3ZhcmlhYmxlcy5jcmVhdGUnLFxuICAgICAgICBWQVJJQUJMRVNfREVMRVRFID0gJ3ZhcmlhYmxlcy5kZWxldGUnLFxuICAgICAgICBWQVJJQUJMRVNfVVBEQVRFID0gJ3ZhcmlhYmxlcy51cGRhdGUnLFxuICAgIH1cblxuICAgIGV4cG9ydCBlbnVtIGFjdGlvbl9raW5kIHtcbiAgICAgICAgQ1JFQVRFRCA9ICdDcmVhdGVkJyxcbiAgICAgICAgVVBEQVRFRCA9ICdVcGRhdGVkJyxcbiAgICAgICAgREVMRVRFID0gJ0RlbGV0ZScsXG4gICAgICAgIEVYRUNVVEUgPSAnRXhlY3V0ZScsXG4gICAgfVxuXG5cbn1cblxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHdCQUF3QixHQUN4QixrQkFBa0IsR0FDbEIsa0JBQWtCO1VBWUQ7O1lBRUQ7Ozs7Ozs7Ozs7Ozs7O0tBQUEscUJBQUEsdUJBQUE7O1lBZ0JBOzs7OztLQUFBLHVCQUFBLHlCQUFBO0FBUWhCLEdBMUJpQixhQUFBIn0=
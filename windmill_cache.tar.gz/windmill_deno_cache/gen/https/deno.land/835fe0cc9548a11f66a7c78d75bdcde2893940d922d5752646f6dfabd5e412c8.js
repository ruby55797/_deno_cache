import { JobService, ResourceService, VariableService } from "./windmill-api/index.ts";
import { OpenAPI } from "./windmill-api/index.ts";
export { AdminService, AuditService, FlowService, GranularAclService, GroupService, JobService, ResourceService, VariableService, ScriptService, ScheduleService, SettingsService, UserService, WorkspaceService } from "./windmill-api/index.ts";
// @ts-ignore: Otherwise BigInt is not supported for export
BigInt.prototype.toJSON = function() {
  return this.toString();
};
export { pgSql, pgClient } from "./pg.ts";
export const SHARED_FOLDER = "/shared";
export function setClient(token, baseUrl) {
  OpenAPI.WITH_CREDENTIALS = true;
  OpenAPI.TOKEN = token;
  OpenAPI.BASE = baseUrl + "/api";
}
setClient(Deno.env.get("WM_TOKEN") ?? "no_token", Deno.env.get("BASE_INTERNAL_URL") ?? Deno.env.get("BASE_URL") ?? "http://localhost:8000");
/**
 * Create a client configuration from env variables
 * @returns client configuration
 */ export function getWorkspace() {
  return Deno.env.get("WM_WORKSPACE") ?? "no_workspace";
}
/**
 * Get a resource value by path
 * @param path path of the resource,  default to internal state path
 * @param undefinedIfEmpty if the resource does not exist, return undefined instead of throwing an error
 * @returns resource value
 */ export async function getResource(path, undefinedIfEmpty) {
  const workspace = getWorkspace();
  path = path ?? getStatePath();
  try {
    const resource = await ResourceService.getResource({
      workspace,
      path
    });
    return await _transformLeaf(resource.value);
  } catch (e) {
    if (undefinedIfEmpty && e.status === 404) {
      return undefined;
    } else {
      throw Error(`Resource not found at ${path} or not visible to you`);
    }
  }
}
/**
 * Get the full resource value by path
 * @param path path of the resource,  default to internal state path
 * @param undefinedIfEmpty if the resource does not exist, return undefined instead of throwing an error
 * @returns full resource
 */ export async function getFullResource(path, undefinedIfEmpty) {
  const workspace = getWorkspace();
  path = path ?? getStatePath();
  try {
    const resource = await ResourceService.getResource({
      workspace,
      path
    });
    const value = await _transformLeaf(resource.value);
    return {
      ...resource,
      value
    };
  } catch (e) {
    if (undefinedIfEmpty && e.status === 404) {
      return undefined;
    } else {
      throw Error(`Resource not found at ${path} or not visible to you`);
    }
  }
}
export function getStatePath() {
  const state_path = Deno.env.get("WM_STATE_PATH");
  if (state_path === undefined) {
    throw Error("State path not set");
  }
  return state_path;
}
/**
 * Set a resource value by path
 * @param path path of the resource to set, default to state path
 * @param value new value of the resource to set
 * @param initializeToTypeIfNotExist if the resource does not exist, initialize it with this type
 */ export async function setResource(value, path, initializeToTypeIfNotExist) {
  path = path ?? getStatePath();
  const workspace = getWorkspace();
  if (await ResourceService.existsResource({
    workspace,
    path
  })) {
    await ResourceService.updateResourceValue({
      workspace,
      path,
      requestBody: {
        value
      }
    });
  } else if (initializeToTypeIfNotExist) {
    await ResourceService.createResource({
      workspace,
      requestBody: {
        path,
        value,
        resource_type: initializeToTypeIfNotExist
      }
    });
  } else {
    throw Error(`Resource at path ${path} does not exist and no type was provided to initialize it`);
  }
}
/**
 * Set the state
 * @param state state to set
 * @deprecated use setState instead
 */ export async function setInternalState(state) {
  await setResource(state, undefined, "state");
}
/**
 * Set the state
 * @param state state to set
 */ export async function setState(state) {
  await setResource(state, undefined, "state");
}
/**
 * Set the shared state
 * @param state state to set
 */ export async function setSharedState(state, path = "state.json") {
  await Deno.writeTextFile(SHARED_FOLDER + "/" + path, JSON.stringify(state));
}
/**
 * Get the shared state
 * @param state state to set
 */ export async function getSharedState(path = "state.json") {
  return JSON.parse(await Deno.readTextFile(SHARED_FOLDER + "/" + path));
}
/**
 * Get the internal state
 * @deprecated use getState instead
 */ export async function getInternalState() {
  return await getResource(getStatePath(), true);
}
/**
 * Get the state shared across executions
 */ export async function getState() {
  return await getResource(getStatePath(), true);
}
/**
 * Get a variable by path
 * @param path path of the variable
 * @returns variable value
 */ export async function getVariable(path) {
  const workspace = getWorkspace();
  try {
    const variable = await VariableService.getVariable({
      workspace,
      path
    });
    return variable.value;
  } catch (e) {
    throw Error(`Variable not found at ${path} or not visible to you`);
  }
}
async function transformLeaves(d) {
  for(const k in d){
    d[k] = await _transformLeaf(d[k]);
  }
  return d;
}
const VAR_RESOURCE_PREFIX = "$var:";
const RES_RESOURCE_PREFIX = "$res:";
async function _transformLeaf(v) {
  if (typeof v === "object") {
    return transformLeaves(v);
  } else if (typeof v === "string" && v.startsWith(VAR_RESOURCE_PREFIX)) {
    const varName = v.substring(VAR_RESOURCE_PREFIX.length);
    return await getVariable(varName);
  } else if (typeof v === "string" && v.startsWith(RES_RESOURCE_PREFIX)) {
    const resName = v.substring(RES_RESOURCE_PREFIX.length);
    return await getResource(resName);
  } else {
    return v;
  }
}
export async function databaseUrlFromResource(path) {
  const resource = await getResource(path);
  return `postgresql://${resource.user}:${resource.password}@${resource.host}:${resource.port}/${resource.dbname}?sslmode=${resource.sslmode}`;
}
/**
 * Get URLs needed for resuming a flow after this step
 * @param approver approver name
 * @returns approval page UI URL, resume and cancel API URLs for resumeing the flow
 */ export async function getResumeUrls(approver) {
  const nonce = Math.floor(Math.random() * 4294967295);
  const workspace = getWorkspace();
  return await JobService.getResumeUrls({
    workspace,
    resumeId: nonce,
    approver,
    id: Deno.env.get("WM_JOB_ID") ?? "NO_JOB_ID"
  });
}
/**
 * @deprecated use getResumeUrls instead
 */ export function getResumeEndpoints(approver) {
  return getResumeUrls(approver);
}
export function base64ToUint8Array(data) {
  return Uint8Array.from(atob(data), (c)=>c.charCodeAt(0));
}
export function uint8ArrayToBase64(arrayBuffer) {
  let base64 = "";
  const encodings = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const bytes = new Uint8Array(arrayBuffer);
  const byteLength = bytes.byteLength;
  const byteRemainder = byteLength % 3;
  const mainLength = byteLength - byteRemainder;
  let a, b, c, d;
  let chunk;
  // Main loop deals with bytes in chunks of 3
  for(let i = 0; i < mainLength; i = i + 3){
    // Combine the three bytes into a single integer
    chunk = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
    // Use bitmasks to extract 6-bit segments from the triplet
    a = (chunk & 16515072) >> 18; // 16515072 = (2^6 - 1) << 18
    b = (chunk & 258048) >> 12; // 258048   = (2^6 - 1) << 12
    c = (chunk & 4032) >> 6; // 4032     = (2^6 - 1) << 6
    d = chunk & 63; // 63       = 2^6 - 1
    // Convert the raw binary segments to the appropriate ASCII encoding
    base64 += encodings[a] + encodings[b] + encodings[c] + encodings[d];
  }
  // Deal with the remaining bytes and padding
  if (byteRemainder == 1) {
    chunk = bytes[mainLength];
    a = (chunk & 252) >> 2; // 252 = (2^6 - 1) << 2
    // Set the 4 least significant bits to zero
    b = (chunk & 3) << 4; // 3   = 2^2 - 1
    base64 += encodings[a] + encodings[b] + "==";
  } else if (byteRemainder == 2) {
    chunk = bytes[mainLength] << 8 | bytes[mainLength + 1];
    a = (chunk & 64512) >> 10; // 64512 = (2^6 - 1) << 10
    b = (chunk & 1008) >> 4; // 1008  = (2^6 - 1) << 4
    // Set the 2 least significant bits to zero
    c = (chunk & 15) << 2; // 15    = 2^4 - 1
    base64 += encodings[a] + encodings[b] + encodings[c] + "=";
  }
  return base64;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC9tb2QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgSm9iU2VydmljZSxcbiAgUmVzb3VyY2VTZXJ2aWNlLFxuICBWYXJpYWJsZVNlcnZpY2UsXG59IGZyb20gXCIuL3dpbmRtaWxsLWFwaS9pbmRleC50c1wiO1xuaW1wb3J0IHsgT3BlbkFQSSB9IGZyb20gXCIuL3dpbmRtaWxsLWFwaS9pbmRleC50c1wiO1xuXG5leHBvcnQge1xuICBBZG1pblNlcnZpY2UsXG4gIEF1ZGl0U2VydmljZSxcbiAgRmxvd1NlcnZpY2UsXG4gIEdyYW51bGFyQWNsU2VydmljZSxcbiAgR3JvdXBTZXJ2aWNlLFxuICBKb2JTZXJ2aWNlLFxuICBSZXNvdXJjZVNlcnZpY2UsXG4gIFZhcmlhYmxlU2VydmljZSxcbiAgU2NyaXB0U2VydmljZSxcbiAgU2NoZWR1bGVTZXJ2aWNlLFxuICBTZXR0aW5nc1NlcnZpY2UsXG4gIFVzZXJTZXJ2aWNlLFxuICBXb3Jrc3BhY2VTZXJ2aWNlLFxufSBmcm9tIFwiLi93aW5kbWlsbC1hcGkvaW5kZXgudHNcIjtcblxuLy8gQHRzLWlnbm9yZTogT3RoZXJ3aXNlIEJpZ0ludCBpcyBub3Qgc3VwcG9ydGVkIGZvciBleHBvcnRcbkJpZ0ludC5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcy50b1N0cmluZygpO1xufTtcblxuZXhwb3J0IHsgcGdTcWwsIHBnQ2xpZW50IH0gZnJvbSBcIi4vcGcudHNcIjtcblxuZXhwb3J0IHR5cGUgU3FsID0gc3RyaW5nO1xuZXhwb3J0IHR5cGUgRW1haWwgPSBzdHJpbmc7XG5leHBvcnQgdHlwZSBCYXNlNjQgPSBzdHJpbmc7XG5leHBvcnQgdHlwZSBSZXNvdXJjZTxTIGV4dGVuZHMgc3RyaW5nPiA9IGFueTtcblxuZXhwb3J0IGNvbnN0IFNIQVJFRF9GT0xERVIgPSBcIi9zaGFyZWRcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldENsaWVudCh0b2tlbjogc3RyaW5nLCBiYXNlVXJsOiBzdHJpbmcpIHtcbiAgT3BlbkFQSS5XSVRIX0NSRURFTlRJQUxTID0gdHJ1ZTtcbiAgT3BlbkFQSS5UT0tFTiA9IHRva2VuO1xuICBPcGVuQVBJLkJBU0UgPSBiYXNlVXJsICsgXCIvYXBpXCI7XG59XG5cbnNldENsaWVudChcbiAgRGVuby5lbnYuZ2V0KFwiV01fVE9LRU5cIikgPz8gXCJub190b2tlblwiLFxuICBEZW5vLmVudi5nZXQoXCJCQVNFX0lOVEVSTkFMX1VSTFwiKSA/P1xuICAgIERlbm8uZW52LmdldChcIkJBU0VfVVJMXCIpID8/XG4gICAgXCJodHRwOi8vbG9jYWxob3N0OjgwMDBcIlxuKTtcblxuLyoqXG4gKiBDcmVhdGUgYSBjbGllbnQgY29uZmlndXJhdGlvbiBmcm9tIGVudiB2YXJpYWJsZXNcbiAqIEByZXR1cm5zIGNsaWVudCBjb25maWd1cmF0aW9uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRXb3Jrc3BhY2UoKTogc3RyaW5nIHtcbiAgcmV0dXJuIERlbm8uZW52LmdldChcIldNX1dPUktTUEFDRVwiKSA/PyBcIm5vX3dvcmtzcGFjZVwiO1xufVxuXG4vKipcbiAqIEdldCBhIHJlc291cmNlIHZhbHVlIGJ5IHBhdGhcbiAqIEBwYXJhbSBwYXRoIHBhdGggb2YgdGhlIHJlc291cmNlLCAgZGVmYXVsdCB0byBpbnRlcm5hbCBzdGF0ZSBwYXRoXG4gKiBAcGFyYW0gdW5kZWZpbmVkSWZFbXB0eSBpZiB0aGUgcmVzb3VyY2UgZG9lcyBub3QgZXhpc3QsIHJldHVybiB1bmRlZmluZWQgaW5zdGVhZCBvZiB0aHJvd2luZyBhbiBlcnJvclxuICogQHJldHVybnMgcmVzb3VyY2UgdmFsdWVcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlc291cmNlKFxuICBwYXRoPzogc3RyaW5nLFxuICB1bmRlZmluZWRJZkVtcHR5PzogYm9vbGVhblxuKTogUHJvbWlzZTxhbnk+IHtcbiAgY29uc3Qgd29ya3NwYWNlID0gZ2V0V29ya3NwYWNlKCk7XG4gIHBhdGggPSBwYXRoID8/IGdldFN0YXRlUGF0aCgpO1xuICB0cnkge1xuICAgIGNvbnN0IHJlc291cmNlID0gYXdhaXQgUmVzb3VyY2VTZXJ2aWNlLmdldFJlc291cmNlKHsgd29ya3NwYWNlLCBwYXRoIH0pO1xuICAgIHJldHVybiBhd2FpdCBfdHJhbnNmb3JtTGVhZihyZXNvdXJjZS52YWx1ZSk7XG4gIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgIGlmICh1bmRlZmluZWRJZkVtcHR5ICYmIGUuc3RhdHVzID09PSA0MDQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IEVycm9yKGBSZXNvdXJjZSBub3QgZm91bmQgYXQgJHtwYXRofSBvciBub3QgdmlzaWJsZSB0byB5b3VgKTtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBHZXQgdGhlIGZ1bGwgcmVzb3VyY2UgdmFsdWUgYnkgcGF0aFxuICogQHBhcmFtIHBhdGggcGF0aCBvZiB0aGUgcmVzb3VyY2UsICBkZWZhdWx0IHRvIGludGVybmFsIHN0YXRlIHBhdGhcbiAqIEBwYXJhbSB1bmRlZmluZWRJZkVtcHR5IGlmIHRoZSByZXNvdXJjZSBkb2VzIG5vdCBleGlzdCwgcmV0dXJuIHVuZGVmaW5lZCBpbnN0ZWFkIG9mIHRocm93aW5nIGFuIGVycm9yXG4gKiBAcmV0dXJucyBmdWxsIHJlc291cmNlXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRGdWxsUmVzb3VyY2UoXG4gIHBhdGg/OiBzdHJpbmcsXG4gIHVuZGVmaW5lZElmRW1wdHk/OiBib29sZWFuXG4pOiBQcm9taXNlPGFueT4ge1xuICBjb25zdCB3b3Jrc3BhY2UgPSBnZXRXb3Jrc3BhY2UoKTtcbiAgcGF0aCA9IHBhdGggPz8gZ2V0U3RhdGVQYXRoKCk7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzb3VyY2UgPSBhd2FpdCBSZXNvdXJjZVNlcnZpY2UuZ2V0UmVzb3VyY2UoeyB3b3Jrc3BhY2UsIHBhdGggfSk7XG4gICAgY29uc3QgdmFsdWUgPSBhd2FpdCBfdHJhbnNmb3JtTGVhZihyZXNvdXJjZS52YWx1ZSk7XG4gICAgcmV0dXJuIHsgLi4ucmVzb3VyY2UsIHZhbHVlIH07XG4gIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgIGlmICh1bmRlZmluZWRJZkVtcHR5ICYmIGUuc3RhdHVzID09PSA0MDQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IEVycm9yKGBSZXNvdXJjZSBub3QgZm91bmQgYXQgJHtwYXRofSBvciBub3QgdmlzaWJsZSB0byB5b3VgKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFN0YXRlUGF0aCgpOiBzdHJpbmcge1xuICBjb25zdCBzdGF0ZV9wYXRoID0gRGVuby5lbnYuZ2V0KFwiV01fU1RBVEVfUEFUSFwiKTtcbiAgaWYgKHN0YXRlX3BhdGggPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IEVycm9yKFwiU3RhdGUgcGF0aCBub3Qgc2V0XCIpO1xuICB9XG4gIHJldHVybiBzdGF0ZV9wYXRoO1xufVxuXG4vKipcbiAqIFNldCBhIHJlc291cmNlIHZhbHVlIGJ5IHBhdGhcbiAqIEBwYXJhbSBwYXRoIHBhdGggb2YgdGhlIHJlc291cmNlIHRvIHNldCwgZGVmYXVsdCB0byBzdGF0ZSBwYXRoXG4gKiBAcGFyYW0gdmFsdWUgbmV3IHZhbHVlIG9mIHRoZSByZXNvdXJjZSB0byBzZXRcbiAqIEBwYXJhbSBpbml0aWFsaXplVG9UeXBlSWZOb3RFeGlzdCBpZiB0aGUgcmVzb3VyY2UgZG9lcyBub3QgZXhpc3QsIGluaXRpYWxpemUgaXQgd2l0aCB0aGlzIHR5cGVcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlc291cmNlKFxuICB2YWx1ZTogYW55LFxuICBwYXRoPzogc3RyaW5nLFxuICBpbml0aWFsaXplVG9UeXBlSWZOb3RFeGlzdD86IHN0cmluZ1xuKTogUHJvbWlzZTx2b2lkPiB7XG4gIHBhdGggPSBwYXRoID8/IGdldFN0YXRlUGF0aCgpO1xuICBjb25zdCB3b3Jrc3BhY2UgPSBnZXRXb3Jrc3BhY2UoKTtcbiAgaWYgKGF3YWl0IFJlc291cmNlU2VydmljZS5leGlzdHNSZXNvdXJjZSh7IHdvcmtzcGFjZSwgcGF0aCB9KSkge1xuICAgIGF3YWl0IFJlc291cmNlU2VydmljZS51cGRhdGVSZXNvdXJjZVZhbHVlKHtcbiAgICAgIHdvcmtzcGFjZSxcbiAgICAgIHBhdGgsXG4gICAgICByZXF1ZXN0Qm9keTogeyB2YWx1ZSB9LFxuICAgIH0pO1xuICB9IGVsc2UgaWYgKGluaXRpYWxpemVUb1R5cGVJZk5vdEV4aXN0KSB7XG4gICAgYXdhaXQgUmVzb3VyY2VTZXJ2aWNlLmNyZWF0ZVJlc291cmNlKHtcbiAgICAgIHdvcmtzcGFjZSxcbiAgICAgIHJlcXVlc3RCb2R5OiB7IHBhdGgsIHZhbHVlLCByZXNvdXJjZV90eXBlOiBpbml0aWFsaXplVG9UeXBlSWZOb3RFeGlzdCB9LFxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIHRocm93IEVycm9yKFxuICAgICAgYFJlc291cmNlIGF0IHBhdGggJHtwYXRofSBkb2VzIG5vdCBleGlzdCBhbmQgbm8gdHlwZSB3YXMgcHJvdmlkZWQgdG8gaW5pdGlhbGl6ZSBpdGBcbiAgICApO1xuICB9XG59XG5cbi8qKlxuICogU2V0IHRoZSBzdGF0ZVxuICogQHBhcmFtIHN0YXRlIHN0YXRlIHRvIHNldFxuICogQGRlcHJlY2F0ZWQgdXNlIHNldFN0YXRlIGluc3RlYWRcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEludGVybmFsU3RhdGUoc3RhdGU6IGFueSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSZXNvdXJjZShzdGF0ZSwgdW5kZWZpbmVkLCBcInN0YXRlXCIpO1xufVxuXG4vKipcbiAqIFNldCB0aGUgc3RhdGVcbiAqIEBwYXJhbSBzdGF0ZSBzdGF0ZSB0byBzZXRcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFN0YXRlKHN0YXRlOiBhbnkpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmVzb3VyY2Uoc3RhdGUsIHVuZGVmaW5lZCwgXCJzdGF0ZVwiKTtcbn1cblxuLyoqXG4gKiBTZXQgdGhlIHNoYXJlZCBzdGF0ZVxuICogQHBhcmFtIHN0YXRlIHN0YXRlIHRvIHNldFxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2hhcmVkU3RhdGUoXG4gIHN0YXRlOiBhbnksXG4gIHBhdGggPSBcInN0YXRlLmpzb25cIlxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IERlbm8ud3JpdGVUZXh0RmlsZShTSEFSRURfRk9MREVSICsgXCIvXCIgKyBwYXRoLCBKU09OLnN0cmluZ2lmeShzdGF0ZSkpO1xufVxuXG4vKipcbiAqIEdldCB0aGUgc2hhcmVkIHN0YXRlXG4gKiBAcGFyYW0gc3RhdGUgc3RhdGUgdG8gc2V0XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTaGFyZWRTdGF0ZShwYXRoID0gXCJzdGF0ZS5qc29uXCIpOiBQcm9taXNlPGFueT4ge1xuICByZXR1cm4gSlNPTi5wYXJzZShhd2FpdCBEZW5vLnJlYWRUZXh0RmlsZShTSEFSRURfRk9MREVSICsgXCIvXCIgKyBwYXRoKSk7XG59XG5cbi8qKlxuICogR2V0IHRoZSBpbnRlcm5hbCBzdGF0ZVxuICogQGRlcHJlY2F0ZWQgdXNlIGdldFN0YXRlIGluc3RlYWRcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEludGVybmFsU3RhdGUoKTogUHJvbWlzZTxhbnk+IHtcbiAgcmV0dXJuIGF3YWl0IGdldFJlc291cmNlKGdldFN0YXRlUGF0aCgpLCB0cnVlKTtcbn1cblxuLyoqXG4gKiBHZXQgdGhlIHN0YXRlIHNoYXJlZCBhY3Jvc3MgZXhlY3V0aW9uc1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdGUoKTogUHJvbWlzZTxhbnk+IHtcbiAgcmV0dXJuIGF3YWl0IGdldFJlc291cmNlKGdldFN0YXRlUGF0aCgpLCB0cnVlKTtcbn1cblxuLyoqXG4gKiBHZXQgYSB2YXJpYWJsZSBieSBwYXRoXG4gKiBAcGFyYW0gcGF0aCBwYXRoIG9mIHRoZSB2YXJpYWJsZVxuICogQHJldHVybnMgdmFyaWFibGUgdmFsdWVcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFZhcmlhYmxlKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgdW5kZWZpbmVkPiB7XG4gIGNvbnN0IHdvcmtzcGFjZSA9IGdldFdvcmtzcGFjZSgpO1xuICB0cnkge1xuICAgIGNvbnN0IHZhcmlhYmxlID0gYXdhaXQgVmFyaWFibGVTZXJ2aWNlLmdldFZhcmlhYmxlKHsgd29ya3NwYWNlLCBwYXRoIH0pO1xuICAgIHJldHVybiB2YXJpYWJsZS52YWx1ZTtcbiAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgdGhyb3cgRXJyb3IoYFZhcmlhYmxlIG5vdCBmb3VuZCBhdCAke3BhdGh9IG9yIG5vdCB2aXNpYmxlIHRvIHlvdWApO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHRyYW5zZm9ybUxlYXZlcyhkOiB7XG4gIFtrZXk6IHN0cmluZ106IGFueTtcbn0pOiBQcm9taXNlPHsgW2tleTogc3RyaW5nXTogYW55IH0+IHtcbiAgZm9yIChjb25zdCBrIGluIGQpIHtcbiAgICBkW2tdID0gYXdhaXQgX3RyYW5zZm9ybUxlYWYoZFtrXSk7XG4gIH1cbiAgcmV0dXJuIGQ7XG59XG5cbmNvbnN0IFZBUl9SRVNPVVJDRV9QUkVGSVggPSBcIiR2YXI6XCI7XG5jb25zdCBSRVNfUkVTT1VSQ0VfUFJFRklYID0gXCIkcmVzOlwiO1xuYXN5bmMgZnVuY3Rpb24gX3RyYW5zZm9ybUxlYWYodjogYW55KTogUHJvbWlzZTxhbnk+IHtcbiAgaWYgKHR5cGVvZiB2ID09PSBcIm9iamVjdFwiKSB7XG4gICAgcmV0dXJuIHRyYW5zZm9ybUxlYXZlcyh2KTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gXCJzdHJpbmdcIiAmJiB2LnN0YXJ0c1dpdGgoVkFSX1JFU09VUkNFX1BSRUZJWCkpIHtcbiAgICBjb25zdCB2YXJOYW1lID0gdi5zdWJzdHJpbmcoVkFSX1JFU09VUkNFX1BSRUZJWC5sZW5ndGgpO1xuICAgIHJldHVybiBhd2FpdCBnZXRWYXJpYWJsZSh2YXJOYW1lKTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gXCJzdHJpbmdcIiAmJiB2LnN0YXJ0c1dpdGgoUkVTX1JFU09VUkNFX1BSRUZJWCkpIHtcbiAgICBjb25zdCByZXNOYW1lID0gdi5zdWJzdHJpbmcoUkVTX1JFU09VUkNFX1BSRUZJWC5sZW5ndGgpO1xuICAgIHJldHVybiBhd2FpdCBnZXRSZXNvdXJjZShyZXNOYW1lKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gdjtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGF0YWJhc2VVcmxGcm9tUmVzb3VyY2UocGF0aDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgcmVzb3VyY2UgPSBhd2FpdCBnZXRSZXNvdXJjZShwYXRoKTtcbiAgcmV0dXJuIGBwb3N0Z3Jlc3FsOi8vJHtyZXNvdXJjZS51c2VyfToke3Jlc291cmNlLnBhc3N3b3JkfUAke3Jlc291cmNlLmhvc3R9OiR7cmVzb3VyY2UucG9ydH0vJHtyZXNvdXJjZS5kYm5hbWV9P3NzbG1vZGU9JHtyZXNvdXJjZS5zc2xtb2RlfWA7XG59XG5cbi8qKlxuICogR2V0IFVSTHMgbmVlZGVkIGZvciByZXN1bWluZyBhIGZsb3cgYWZ0ZXIgdGhpcyBzdGVwXG4gKiBAcGFyYW0gYXBwcm92ZXIgYXBwcm92ZXIgbmFtZVxuICogQHJldHVybnMgYXBwcm92YWwgcGFnZSBVSSBVUkwsIHJlc3VtZSBhbmQgY2FuY2VsIEFQSSBVUkxzIGZvciByZXN1bWVpbmcgdGhlIGZsb3dcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlc3VtZVVybHMoYXBwcm92ZXI/OiBzdHJpbmcpOiBQcm9taXNlPHtcbiAgYXBwcm92YWxQYWdlOiBzdHJpbmc7XG4gIHJlc3VtZTogc3RyaW5nO1xuICBjYW5jZWw6IHN0cmluZztcbn0+IHtcbiAgY29uc3Qgbm9uY2UgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0Mjk0OTY3Mjk1KTtcbiAgY29uc3Qgd29ya3NwYWNlID0gZ2V0V29ya3NwYWNlKCk7XG4gIHJldHVybiBhd2FpdCBKb2JTZXJ2aWNlLmdldFJlc3VtZVVybHMoe1xuICAgIHdvcmtzcGFjZSxcbiAgICByZXN1bWVJZDogbm9uY2UsXG4gICAgYXBwcm92ZXIsXG4gICAgaWQ6IERlbm8uZW52LmdldChcIldNX0pPQl9JRFwiKSA/PyBcIk5PX0pPQl9JRFwiLFxuICB9KTtcbn1cblxuLyoqXG4gKiBAZGVwcmVjYXRlZCB1c2UgZ2V0UmVzdW1lVXJscyBpbnN0ZWFkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRSZXN1bWVFbmRwb2ludHMoYXBwcm92ZXI/OiBzdHJpbmcpOiBQcm9taXNlPHtcbiAgYXBwcm92YWxQYWdlOiBzdHJpbmc7XG4gIHJlc3VtZTogc3RyaW5nO1xuICBjYW5jZWw6IHN0cmluZztcbn0+IHtcbiAgcmV0dXJuIGdldFJlc3VtZVVybHMoYXBwcm92ZXIpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYmFzZTY0VG9VaW50OEFycmF5KGRhdGE6IHN0cmluZyk6IFVpbnQ4QXJyYXkge1xuICByZXR1cm4gVWludDhBcnJheS5mcm9tKGF0b2IoZGF0YSksIChjKSA9PiBjLmNoYXJDb2RlQXQoMCkpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdWludDhBcnJheVRvQmFzZTY0KGFycmF5QnVmZmVyOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgbGV0IGJhc2U2NCA9IFwiXCI7XG4gIGNvbnN0IGVuY29kaW5ncyA9XG4gICAgXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvXCI7XG5cbiAgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShhcnJheUJ1ZmZlcik7XG4gIGNvbnN0IGJ5dGVMZW5ndGggPSBieXRlcy5ieXRlTGVuZ3RoO1xuICBjb25zdCBieXRlUmVtYWluZGVyID0gYnl0ZUxlbmd0aCAlIDM7XG4gIGNvbnN0IG1haW5MZW5ndGggPSBieXRlTGVuZ3RoIC0gYnl0ZVJlbWFpbmRlcjtcblxuICBsZXQgYSwgYiwgYywgZDtcbiAgbGV0IGNodW5rO1xuXG4gIC8vIE1haW4gbG9vcCBkZWFscyB3aXRoIGJ5dGVzIGluIGNodW5rcyBvZiAzXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbWFpbkxlbmd0aDsgaSA9IGkgKyAzKSB7XG4gICAgLy8gQ29tYmluZSB0aGUgdGhyZWUgYnl0ZXMgaW50byBhIHNpbmdsZSBpbnRlZ2VyXG4gICAgY2h1bmsgPSAoYnl0ZXNbaV0gPDwgMTYpIHwgKGJ5dGVzW2kgKyAxXSA8PCA4KSB8IGJ5dGVzW2kgKyAyXTtcblxuICAgIC8vIFVzZSBiaXRtYXNrcyB0byBleHRyYWN0IDYtYml0IHNlZ21lbnRzIGZyb20gdGhlIHRyaXBsZXRcbiAgICBhID0gKGNodW5rICYgMTY1MTUwNzIpID4+IDE4OyAvLyAxNjUxNTA3MiA9ICgyXjYgLSAxKSA8PCAxOFxuICAgIGIgPSAoY2h1bmsgJiAyNTgwNDgpID4+IDEyOyAvLyAyNTgwNDggICA9ICgyXjYgLSAxKSA8PCAxMlxuICAgIGMgPSAoY2h1bmsgJiA0MDMyKSA+PiA2OyAvLyA0MDMyICAgICA9ICgyXjYgLSAxKSA8PCA2XG4gICAgZCA9IGNodW5rICYgNjM7IC8vIDYzICAgICAgID0gMl42IC0gMVxuXG4gICAgLy8gQ29udmVydCB0aGUgcmF3IGJpbmFyeSBzZWdtZW50cyB0byB0aGUgYXBwcm9wcmlhdGUgQVNDSUkgZW5jb2RpbmdcbiAgICBiYXNlNjQgKz0gZW5jb2RpbmdzW2FdICsgZW5jb2RpbmdzW2JdICsgZW5jb2RpbmdzW2NdICsgZW5jb2RpbmdzW2RdO1xuICB9XG5cbiAgLy8gRGVhbCB3aXRoIHRoZSByZW1haW5pbmcgYnl0ZXMgYW5kIHBhZGRpbmdcbiAgaWYgKGJ5dGVSZW1haW5kZXIgPT0gMSkge1xuICAgIGNodW5rID0gYnl0ZXNbbWFpbkxlbmd0aF07XG5cbiAgICBhID0gKGNodW5rICYgMjUyKSA+PiAyOyAvLyAyNTIgPSAoMl42IC0gMSkgPDwgMlxuXG4gICAgLy8gU2V0IHRoZSA0IGxlYXN0IHNpZ25pZmljYW50IGJpdHMgdG8gemVyb1xuICAgIGIgPSAoY2h1bmsgJiAzKSA8PCA0OyAvLyAzICAgPSAyXjIgLSAxXG5cbiAgICBiYXNlNjQgKz0gZW5jb2RpbmdzW2FdICsgZW5jb2RpbmdzW2JdICsgXCI9PVwiO1xuICB9IGVsc2UgaWYgKGJ5dGVSZW1haW5kZXIgPT0gMikge1xuICAgIGNodW5rID0gKGJ5dGVzW21haW5MZW5ndGhdIDw8IDgpIHwgYnl0ZXNbbWFpbkxlbmd0aCArIDFdO1xuXG4gICAgYSA9IChjaHVuayAmIDY0NTEyKSA+PiAxMDsgLy8gNjQ1MTIgPSAoMl42IC0gMSkgPDwgMTBcbiAgICBiID0gKGNodW5rICYgMTAwOCkgPj4gNDsgLy8gMTAwOCAgPSAoMl42IC0gMSkgPDwgNFxuXG4gICAgLy8gU2V0IHRoZSAyIGxlYXN0IHNpZ25pZmljYW50IGJpdHMgdG8gemVyb1xuICAgIGMgPSAoY2h1bmsgJiAxNSkgPDwgMjsgLy8gMTUgICAgPSAyXjQgLSAxXG5cbiAgICBiYXNlNjQgKz0gZW5jb2RpbmdzW2FdICsgZW5jb2RpbmdzW2JdICsgZW5jb2RpbmdzW2NdICsgXCI9XCI7XG4gIH1cblxuICByZXR1cm4gYmFzZTY0O1xufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFNBQ0UsVUFBVSxFQUNWLGVBQWUsRUFDZixlQUFlLFFBQ1YsMEJBQTBCO0FBQ2pDLFNBQVMsT0FBTyxRQUFRLDBCQUEwQjtBQUVsRCxTQUNFLFlBQVksRUFDWixZQUFZLEVBQ1osV0FBVyxFQUNYLGtCQUFrQixFQUNsQixZQUFZLEVBQ1osVUFBVSxFQUNWLGVBQWUsRUFDZixlQUFlLEVBQ2YsYUFBYSxFQUNiLGVBQWUsRUFDZixlQUFlLEVBQ2YsV0FBVyxFQUNYLGdCQUFnQixRQUNYLDBCQUEwQjtBQUVqQywyREFBMkQ7QUFDM0QsT0FBTyxTQUFTLENBQUMsTUFBTSxHQUFHO0VBQ3hCLE9BQU8sSUFBSSxDQUFDLFFBQVE7QUFDdEI7QUFFQSxTQUFTLEtBQUssRUFBRSxRQUFRLFFBQVEsVUFBVTtBQU8xQyxPQUFPLE1BQU0sZ0JBQWdCLFVBQVU7QUFFdkMsT0FBTyxTQUFTLFVBQVUsS0FBYSxFQUFFLE9BQWU7RUFDdEQsUUFBUSxnQkFBZ0IsR0FBRztFQUMzQixRQUFRLEtBQUssR0FBRztFQUNoQixRQUFRLElBQUksR0FBRyxVQUFVO0FBQzNCO0FBRUEsVUFDRSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZUFBZSxZQUM1QixLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsd0JBQ1gsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLGVBQ2I7QUFHSjs7O0NBR0MsR0FDRCxPQUFPLFNBQVM7RUFDZCxPQUFPLEtBQUssR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUI7QUFDekM7QUFFQTs7Ozs7Q0FLQyxHQUNELE9BQU8sZUFBZSxZQUNwQixJQUFhLEVBQ2IsZ0JBQTBCO0VBRTFCLE1BQU0sWUFBWTtFQUNsQixPQUFPLFFBQVE7RUFDZixJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sZ0JBQWdCLFdBQVcsQ0FBQztNQUFFO01BQVc7SUFBSztJQUNyRSxPQUFPLE1BQU0sZUFBZSxTQUFTLEtBQUs7RUFDNUMsRUFBRSxPQUFPLEdBQVE7SUFDZixJQUFJLG9CQUFvQixFQUFFLE1BQU0sS0FBSyxLQUFLO01BQ3hDLE9BQU87SUFDVCxPQUFPO01BQ0wsTUFBTSxNQUFNLENBQUMsc0JBQXNCLEVBQUUsS0FBSyxzQkFBc0IsQ0FBQztJQUNuRTtFQUNGO0FBQ0Y7QUFFQTs7Ozs7Q0FLQyxHQUNELE9BQU8sZUFBZSxnQkFDcEIsSUFBYSxFQUNiLGdCQUEwQjtFQUUxQixNQUFNLFlBQVk7RUFDbEIsT0FBTyxRQUFRO0VBQ2YsSUFBSTtJQUNGLE1BQU0sV0FBVyxNQUFNLGdCQUFnQixXQUFXLENBQUM7TUFBRTtNQUFXO0lBQUs7SUFDckUsTUFBTSxRQUFRLE1BQU0sZUFBZSxTQUFTLEtBQUs7SUFDakQsT0FBTztNQUFFLEdBQUcsUUFBUTtNQUFFO0lBQU07RUFDOUIsRUFBRSxPQUFPLEdBQVE7SUFDZixJQUFJLG9CQUFvQixFQUFFLE1BQU0sS0FBSyxLQUFLO01BQ3hDLE9BQU87SUFDVCxPQUFPO01BQ0wsTUFBTSxNQUFNLENBQUMsc0JBQXNCLEVBQUUsS0FBSyxzQkFBc0IsQ0FBQztJQUNuRTtFQUNGO0FBQ0Y7QUFFQSxPQUFPLFNBQVM7RUFDZCxNQUFNLGFBQWEsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDO0VBQ2hDLElBQUksZUFBZSxXQUFXO0lBQzVCLE1BQU0sTUFBTTtFQUNkO0VBQ0EsT0FBTztBQUNUO0FBRUE7Ozs7O0NBS0MsR0FDRCxPQUFPLGVBQWUsWUFDcEIsS0FBVSxFQUNWLElBQWEsRUFDYiwwQkFBbUM7RUFFbkMsT0FBTyxRQUFRO0VBQ2YsTUFBTSxZQUFZO0VBQ2xCLElBQUksTUFBTSxnQkFBZ0IsY0FBYyxDQUFDO0lBQUU7SUFBVztFQUFLLElBQUk7SUFDN0QsTUFBTSxnQkFBZ0IsbUJBQW1CLENBQUM7TUFDeEM7TUFDQTtNQUNBLGFBQWE7UUFBRTtNQUFNO0lBQ3ZCO0VBQ0YsT0FBTyxJQUFJLDRCQUE0QjtJQUNyQyxNQUFNLGdCQUFnQixjQUFjLENBQUM7TUFDbkM7TUFDQSxhQUFhO1FBQUU7UUFBTTtRQUFPLGVBQWU7TUFBMkI7SUFDeEU7RUFDRixPQUFPO0lBQ0wsTUFBTSxNQUNKLENBQUMsaUJBQWlCLEVBQUUsS0FBSyx5REFBeUQsQ0FBQztFQUV2RjtBQUNGO0FBRUE7Ozs7Q0FJQyxHQUNELE9BQU8sZUFBZSxpQkFBaUIsS0FBVTtFQUMvQyxNQUFNLFlBQVksT0FBTyxXQUFXO0FBQ3RDO0FBRUE7OztDQUdDLEdBQ0QsT0FBTyxlQUFlLFNBQVMsS0FBVTtFQUN2QyxNQUFNLFlBQVksT0FBTyxXQUFXO0FBQ3RDO0FBRUE7OztDQUdDLEdBQ0QsT0FBTyxlQUFlLGVBQ3BCLEtBQVUsRUFDVixPQUFPLFlBQVk7RUFFbkIsTUFBTSxLQUFLLGFBQWEsQ0FBQyxnQkFBZ0IsTUFBTSxNQUFNLEtBQUssU0FBUyxDQUFDO0FBQ3RFO0FBRUE7OztDQUdDLEdBQ0QsT0FBTyxlQUFlLGVBQWUsT0FBTyxZQUFZO0VBQ3RELE9BQU8sS0FBSyxLQUFLLENBQUMsTUFBTSxLQUFLLFlBQVksQ0FBQyxnQkFBZ0IsTUFBTTtBQUNsRTtBQUVBOzs7Q0FHQyxHQUNELE9BQU8sZUFBZTtFQUNwQixPQUFPLE1BQU0sWUFBWSxnQkFBZ0I7QUFDM0M7QUFFQTs7Q0FFQyxHQUNELE9BQU8sZUFBZTtFQUNwQixPQUFPLE1BQU0sWUFBWSxnQkFBZ0I7QUFDM0M7QUFFQTs7OztDQUlDLEdBQ0QsT0FBTyxlQUFlLFlBQVksSUFBWTtFQUM1QyxNQUFNLFlBQVk7RUFDbEIsSUFBSTtJQUNGLE1BQU0sV0FBVyxNQUFNLGdCQUFnQixXQUFXLENBQUM7TUFBRTtNQUFXO0lBQUs7SUFDckUsT0FBTyxTQUFTLEtBQUs7RUFDdkIsRUFBRSxPQUFPLEdBQVE7SUFDZixNQUFNLE1BQU0sQ0FBQyxzQkFBc0IsRUFBRSxLQUFLLHNCQUFzQixDQUFDO0VBQ25FO0FBQ0Y7QUFFQSxlQUFlLGdCQUFnQixDQUU5QjtFQUNDLElBQUssTUFBTSxLQUFLLEVBQUc7SUFDakIsQ0FBQyxDQUFDLEVBQUUsR0FBRyxNQUFNLGVBQWUsQ0FBQyxDQUFDLEVBQUU7RUFDbEM7RUFDQSxPQUFPO0FBQ1Q7QUFFQSxNQUFNLHNCQUFzQjtBQUM1QixNQUFNLHNCQUFzQjtBQUM1QixlQUFlLGVBQWUsQ0FBTTtFQUNsQyxJQUFJLE9BQU8sTUFBTSxVQUFVO0lBQ3pCLE9BQU8sZ0JBQWdCO0VBQ3pCLE9BQU8sSUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFVBQVUsQ0FBQyxzQkFBc0I7SUFDckUsTUFBTSxVQUFVLEVBQUUsU0FBUyxDQUFDLG9CQUFvQixNQUFNO0lBQ3RELE9BQU8sTUFBTSxZQUFZO0VBQzNCLE9BQU8sSUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFVBQVUsQ0FBQyxzQkFBc0I7SUFDckUsTUFBTSxVQUFVLEVBQUUsU0FBUyxDQUFDLG9CQUFvQixNQUFNO0lBQ3RELE9BQU8sTUFBTSxZQUFZO0VBQzNCLE9BQU87SUFDTCxPQUFPO0VBQ1Q7QUFDRjtBQUVBLE9BQU8sZUFBZSx3QkFBd0IsSUFBWTtFQUN4RCxNQUFNLFdBQVcsTUFBTSxZQUFZO0VBQ25DLE9BQU8sQ0FBQyxhQUFhLEVBQUUsU0FBUyxJQUFJLENBQUMsQ0FBQyxFQUFFLFNBQVMsUUFBUSxDQUFDLENBQUMsRUFBRSxTQUFTLElBQUksQ0FBQyxDQUFDLEVBQUUsU0FBUyxJQUFJLENBQUMsQ0FBQyxFQUFFLFNBQVMsTUFBTSxDQUFDLFNBQVMsRUFBRSxTQUFTLE9BQU8sQ0FBQyxDQUFDO0FBQzlJO0FBRUE7Ozs7Q0FJQyxHQUNELE9BQU8sZUFBZSxjQUFjLFFBQWlCO0VBS25ELE1BQU0sUUFBUSxLQUFLLEtBQUssQ0FBQyxLQUFLLE1BQU0sS0FBSztFQUN6QyxNQUFNLFlBQVk7RUFDbEIsT0FBTyxNQUFNLFdBQVcsYUFBYSxDQUFDO0lBQ3BDO0lBQ0EsVUFBVTtJQUNWO0lBQ0EsSUFBSSxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCO0VBQ25DO0FBQ0Y7QUFFQTs7Q0FFQyxHQUNELE9BQU8sU0FBUyxtQkFBbUIsUUFBaUI7RUFLbEQsT0FBTyxjQUFjO0FBQ3ZCO0FBRUEsT0FBTyxTQUFTLG1CQUFtQixJQUFZO0VBQzdDLE9BQU8sV0FBVyxJQUFJLENBQUMsS0FBSyxPQUFPLENBQUMsSUFBTSxFQUFFLFVBQVUsQ0FBQztBQUN6RDtBQUVBLE9BQU8sU0FBUyxtQkFBbUIsV0FBdUI7RUFDeEQsSUFBSSxTQUFTO0VBQ2IsTUFBTSxZQUNKO0VBRUYsTUFBTSxRQUFRLElBQUksV0FBVztFQUM3QixNQUFNLGFBQWEsTUFBTSxVQUFVO0VBQ25DLE1BQU0sZ0JBQWdCLGFBQWE7RUFDbkMsTUFBTSxhQUFhLGFBQWE7RUFFaEMsSUFBSSxHQUFHLEdBQUcsR0FBRztFQUNiLElBQUk7RUFFSiw0Q0FBNEM7RUFDNUMsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLFlBQVksSUFBSSxJQUFJLEVBQUc7SUFDekMsZ0RBQWdEO0lBQ2hELFFBQVEsQUFBQyxLQUFLLENBQUMsRUFBRSxJQUFJLEtBQU8sS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLElBQUssS0FBSyxDQUFDLElBQUksRUFBRTtJQUU3RCwwREFBMEQ7SUFDMUQsSUFBSSxDQUFDLFFBQVEsUUFBUSxLQUFLLElBQUksNkJBQTZCO0lBQzNELElBQUksQ0FBQyxRQUFRLE1BQU0sS0FBSyxJQUFJLDZCQUE2QjtJQUN6RCxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssR0FBRyw0QkFBNEI7SUFDckQsSUFBSSxRQUFRLElBQUkscUJBQXFCO0lBRXJDLG9FQUFvRTtJQUNwRSxVQUFVLFNBQVMsQ0FBQyxFQUFFLEdBQUcsU0FBUyxDQUFDLEVBQUUsR0FBRyxTQUFTLENBQUMsRUFBRSxHQUFHLFNBQVMsQ0FBQyxFQUFFO0VBQ3JFO0VBRUEsNENBQTRDO0VBQzVDLElBQUksaUJBQWlCLEdBQUc7SUFDdEIsUUFBUSxLQUFLLENBQUMsV0FBVztJQUV6QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssR0FBRyx1QkFBdUI7SUFFL0MsMkNBQTJDO0lBQzNDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLGdCQUFnQjtJQUV0QyxVQUFVLFNBQVMsQ0FBQyxFQUFFLEdBQUcsU0FBUyxDQUFDLEVBQUUsR0FBRztFQUMxQyxPQUFPLElBQUksaUJBQWlCLEdBQUc7SUFDN0IsUUFBUSxBQUFDLEtBQUssQ0FBQyxXQUFXLElBQUksSUFBSyxLQUFLLENBQUMsYUFBYSxFQUFFO0lBRXhELElBQUksQ0FBQyxRQUFRLEtBQUssS0FBSyxJQUFJLDBCQUEwQjtJQUNyRCxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssR0FBRyx5QkFBeUI7SUFFbEQsMkNBQTJDO0lBQzNDLElBQUksQ0FBQyxRQUFRLEVBQUUsS0FBSyxHQUFHLGtCQUFrQjtJQUV6QyxVQUFVLFNBQVMsQ0FBQyxFQUFFLEdBQUcsU0FBUyxDQUFDLEVBQUUsR0FBRyxTQUFTLENBQUMsRUFBRSxHQUFHO0VBQ3pEO0VBRUEsT0FBTztBQUNUIn0=
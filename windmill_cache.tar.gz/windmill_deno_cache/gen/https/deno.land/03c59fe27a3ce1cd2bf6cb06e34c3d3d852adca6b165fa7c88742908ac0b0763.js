/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ import { OpenAPI } from '../core/OpenAPI.ts';
import { request as __request } from '../core/request.ts';
export class ResourceService {
  /**
     * create resource
     * @returns string resource created
     * @throws ApiError
     */ static createResource({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/resources/create',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete resource
     * @returns string resource deleted
     * @throws ApiError
     */ static deleteResource({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/w/{workspace}/resources/delete/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * update resource
     * @returns string resource updated
     * @throws ApiError
     */ static updateResource({ workspace, path, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/resources/update/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * update resource value
     * @returns string resource value updated
     * @throws ApiError
     */ static updateResourceValue({ workspace, path, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/resources/update_value/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * get resource
     * @returns Resource resource
     * @throws ApiError
     */ static getResource({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/resources/get/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * get resource value
     * @returns any resource value
     * @throws ApiError
     */ static getResourceValue({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/resources/get_value/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * does resource exists
     * @returns boolean does resource exists
     * @throws ApiError
     */ static existsResource({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/resources/exists/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * list resources
     * @returns ListableResource resource list
     * @throws ApiError
     */ static listResource({ workspace, page, perPage, resourceType, resourceTypeExclude }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/resources/list',
      path: {
        'workspace': workspace
      },
      query: {
        'page': page,
        'per_page': perPage,
        'resource_type': resourceType,
        'resource_type_exclude': resourceTypeExclude
      }
    });
  }
  /**
     * create resource_type
     * @returns string resource_type created
     * @throws ApiError
     */ static createResourceType({ workspace, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/resources/type/create',
      path: {
        'workspace': workspace
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * delete resource_type
     * @returns string resource_type deleted
     * @throws ApiError
     */ static deleteResourceType({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'DELETE',
      url: '/w/{workspace}/resources/type/delete/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * update resource_type
     * @returns string resource_type updated
     * @throws ApiError
     */ static updateResourceType({ workspace, path, requestBody }) {
    return __request(OpenAPI, {
      method: 'POST',
      url: '/w/{workspace}/resources/type/update/{path}',
      path: {
        'workspace': workspace,
        'path': path
      },
      body: requestBody,
      mediaType: 'application/json'
    });
  }
  /**
     * get resource_type
     * @returns ResourceType resource_type deleted
     * @throws ApiError
     */ static getResourceType({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/resources/type/get/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * does resource_type exists
     * @returns boolean does resource_type exist
     * @throws ApiError
     */ static existsResourceType({ workspace, path }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/resources/type/exists/{path}',
      path: {
        'workspace': workspace,
        'path': path
      }
    });
  }
  /**
     * list resource_types
     * @returns ResourceType resource_type list
     * @throws ApiError
     */ static listResourceType({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/resources/type/list',
      path: {
        'workspace': workspace
      }
    });
  }
  /**
     * list resource_types names
     * @returns string resource_type list
     * @throws ApiError
     */ static listResourceTypeNames({ workspace }) {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/w/{workspace}/resources/type/listnames',
      path: {
        'workspace': workspace
      }
    });
  }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvc2VydmljZXMvUmVzb3VyY2VTZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qIGlzdGFuYnVsIGlnbm9yZSBmaWxlICovXG4vKiB0c2xpbnQ6ZGlzYWJsZSAqL1xuLyogZXNsaW50LWRpc2FibGUgKi9cbmltcG9ydCB0eXBlIHsgQ3JlYXRlUmVzb3VyY2UgfSBmcm9tICcuLi9tb2RlbHMvQ3JlYXRlUmVzb3VyY2UudHMnO1xuaW1wb3J0IHR5cGUgeyBFZGl0UmVzb3VyY2UgfSBmcm9tICcuLi9tb2RlbHMvRWRpdFJlc291cmNlLnRzJztcbmltcG9ydCB0eXBlIHsgRWRpdFJlc291cmNlVHlwZSB9IGZyb20gJy4uL21vZGVscy9FZGl0UmVzb3VyY2VUeXBlLnRzJztcbmltcG9ydCB0eXBlIHsgTGlzdGFibGVSZXNvdXJjZSB9IGZyb20gJy4uL21vZGVscy9MaXN0YWJsZVJlc291cmNlLnRzJztcbmltcG9ydCB0eXBlIHsgUmVzb3VyY2UgfSBmcm9tICcuLi9tb2RlbHMvUmVzb3VyY2UudHMnO1xuaW1wb3J0IHR5cGUgeyBSZXNvdXJjZVR5cGUgfSBmcm9tICcuLi9tb2RlbHMvUmVzb3VyY2VUeXBlLnRzJztcblxuaW1wb3J0IHR5cGUgeyBDYW5jZWxhYmxlUHJvbWlzZSB9IGZyb20gJy4uL2NvcmUvQ2FuY2VsYWJsZVByb21pc2UudHMnO1xuaW1wb3J0IHsgT3BlbkFQSSB9IGZyb20gJy4uL2NvcmUvT3BlbkFQSS50cyc7XG5pbXBvcnQgeyByZXF1ZXN0IGFzIF9fcmVxdWVzdCB9IGZyb20gJy4uL2NvcmUvcmVxdWVzdC50cyc7XG5cbmV4cG9ydCBjbGFzcyBSZXNvdXJjZVNlcnZpY2Uge1xuXG4gICAgLyoqXG4gICAgICogY3JlYXRlIHJlc291cmNlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHJlc291cmNlIGNyZWF0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBjcmVhdGVSZXNvdXJjZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIG5ldyByZXNvdXJjZVxuICAgICAgICAgKi9cbiAgICAgICAgcmVxdWVzdEJvZHk6IENyZWF0ZVJlc291cmNlLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3Jlc291cmNlcy9jcmVhdGUnLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZGVsZXRlIHJlc291cmNlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHJlc291cmNlIGRlbGV0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBkZWxldGVSZXNvdXJjZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9yZXNvdXJjZXMvZGVsZXRlL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiB1cGRhdGUgcmVzb3VyY2VcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgcmVzb3VyY2UgdXBkYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVwZGF0ZVJlc291cmNlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYXRoLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgICAgIC8qKlxuICAgICAgICAgKiB1cGRhdGVkIHJlc291cmNlXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogRWRpdFJlc291cmNlLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxzdHJpbmc+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3Jlc291cmNlcy91cGRhdGUve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiB1cGRhdGUgcmVzb3VyY2UgdmFsdWVcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgcmVzb3VyY2UgdmFsdWUgdXBkYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVwZGF0ZVJlc291cmNlVmFsdWUoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgICAgIHJlcXVlc3RCb2R5LFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgICAgIHBhdGg6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHVwZGF0ZWQgcmVzb3VyY2VcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiB7XG4gICAgICAgICAgICB2YWx1ZT86IGFueTtcbiAgICAgICAgfSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9yZXNvdXJjZXMvdXBkYXRlX3ZhbHVlL3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgYm9keTogcmVxdWVzdEJvZHksXG4gICAgICAgICAgICBtZWRpYVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZ2V0IHJlc291cmNlXG4gICAgICogQHJldHVybnMgUmVzb3VyY2UgcmVzb3VyY2VcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRSZXNvdXJjZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPFJlc291cmNlPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3Jlc291cmNlcy9nZXQve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGdldCByZXNvdXJjZSB2YWx1ZVxuICAgICAqIEByZXR1cm5zIGFueSByZXNvdXJjZSB2YWx1ZVxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGdldFJlc291cmNlVmFsdWUoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxhbnk+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vcmVzb3VyY2VzL2dldF92YWx1ZS97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogZG9lcyByZXNvdXJjZSBleGlzdHNcbiAgICAgKiBAcmV0dXJucyBib29sZWFuIGRvZXMgcmVzb3VyY2UgZXhpc3RzXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgZXhpc3RzUmVzb3VyY2Uoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxib29sZWFuPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3Jlc291cmNlcy9leGlzdHMve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxpc3QgcmVzb3VyY2VzXG4gICAgICogQHJldHVybnMgTGlzdGFibGVSZXNvdXJjZSByZXNvdXJjZSBsaXN0XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdFJlc291cmNlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICBwYWdlLFxuICAgICAgICBwZXJQYWdlLFxuICAgICAgICByZXNvdXJjZVR5cGUsXG4gICAgICAgIHJlc291cmNlVHlwZUV4Y2x1ZGUsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHdoaWNoIHBhZ2UgdG8gcmV0dXJuIChzdGFydCBhdCAxLCBkZWZhdWx0IDEpXG4gICAgICAgICAqL1xuICAgICAgICBwYWdlPzogbnVtYmVyLFxuICAgICAgICAvKipcbiAgICAgICAgICogbnVtYmVyIG9mIGl0ZW1zIHRvIHJldHVybiBmb3IgYSBnaXZlbiBwYWdlIChkZWZhdWx0IDMwLCBtYXggMTAwKVxuICAgICAgICAgKi9cbiAgICAgICAgcGVyUGFnZT86IG51bWJlcixcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHJlc291cmNlX3R5cGVzIHRvIGxpc3QgZnJvbSwgc2VwYXJhdGVkIGJ5ICcsJyxcbiAgICAgICAgICovXG4gICAgICAgIHJlc291cmNlVHlwZT86IHN0cmluZyxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHJlc291cmNlX3R5cGVzIHRvIG5vdCBsaXN0IGZyb20sIHNlcGFyYXRlZCBieSAnLCcsXG4gICAgICAgICAqL1xuICAgICAgICByZXNvdXJjZVR5cGVFeGNsdWRlPzogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxBcnJheTxMaXN0YWJsZVJlc291cmNlPj4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9yZXNvdXJjZXMvbGlzdCcsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgICdwYWdlJzogcGFnZSxcbiAgICAgICAgICAgICAgICAncGVyX3BhZ2UnOiBwZXJQYWdlLFxuICAgICAgICAgICAgICAgICdyZXNvdXJjZV90eXBlJzogcmVzb3VyY2VUeXBlLFxuICAgICAgICAgICAgICAgICdyZXNvdXJjZV90eXBlX2V4Y2x1ZGUnOiByZXNvdXJjZVR5cGVFeGNsdWRlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogY3JlYXRlIHJlc291cmNlX3R5cGVcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgcmVzb3VyY2VfdHlwZSBjcmVhdGVkXG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgY3JlYXRlUmVzb3VyY2VUeXBlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgICAgICByZXF1ZXN0Qm9keSxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogbmV3IHJlc291cmNlX3R5cGVcbiAgICAgICAgICovXG4gICAgICAgIHJlcXVlc3RCb2R5OiBSZXNvdXJjZVR5cGUsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vcmVzb3VyY2VzL3R5cGUvY3JlYXRlJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IHJlcXVlc3RCb2R5LFxuICAgICAgICAgICAgbWVkaWFUeXBlOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGRlbGV0ZSByZXNvdXJjZV90eXBlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHJlc291cmNlX3R5cGUgZGVsZXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIGRlbGV0ZVJlc291cmNlVHlwZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICB9OiB7XG4gICAgICAgIHdvcmtzcGFjZTogc3RyaW5nLFxuICAgICAgICBwYXRoOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPHN0cmluZz4ge1xuICAgICAgICByZXR1cm4gX19yZXF1ZXN0KE9wZW5BUEksIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURScsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9yZXNvdXJjZXMvdHlwZS9kZWxldGUve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHVwZGF0ZSByZXNvdXJjZV90eXBlXG4gICAgICogQHJldHVybnMgc3RyaW5nIHJlc291cmNlX3R5cGUgdXBkYXRlZFxuICAgICAqIEB0aHJvd3MgQXBpRXJyb3JcbiAgICAgKi9cbiAgICBwdWJsaWMgc3RhdGljIHVwZGF0ZVJlc291cmNlVHlwZSh7XG4gICAgICAgIHdvcmtzcGFjZSxcbiAgICAgICAgcGF0aCxcbiAgICAgICAgcmVxdWVzdEJvZHksXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgICAgICAvKipcbiAgICAgICAgICogdXBkYXRlZCByZXNvdXJjZV90eXBlXG4gICAgICAgICAqL1xuICAgICAgICByZXF1ZXN0Qm9keTogRWRpdFJlc291cmNlVHlwZSxcbiAgICB9KTogQ2FuY2VsYWJsZVByb21pc2U8c3RyaW5nPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICB1cmw6ICcvdy97d29ya3NwYWNlfS9yZXNvdXJjZXMvdHlwZS91cGRhdGUve3BhdGh9JyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgICAgICdwYXRoJzogcGF0aCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiByZXF1ZXN0Qm9keSxcbiAgICAgICAgICAgIG1lZGlhVHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBnZXQgcmVzb3VyY2VfdHlwZVxuICAgICAqIEByZXR1cm5zIFJlc291cmNlVHlwZSByZXNvdXJjZV90eXBlIGRlbGV0ZWRcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBnZXRSZXNvdXJjZVR5cGUoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxSZXNvdXJjZVR5cGU+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vcmVzb3VyY2VzL3R5cGUvZ2V0L3twYXRofScsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgICAgICAncGF0aCc6IHBhdGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBkb2VzIHJlc291cmNlX3R5cGUgZXhpc3RzXG4gICAgICogQHJldHVybnMgYm9vbGVhbiBkb2VzIHJlc291cmNlX3R5cGUgZXhpc3RcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBleGlzdHNSZXNvdXJjZVR5cGUoe1xuICAgICAgICB3b3Jrc3BhY2UsXG4gICAgICAgIHBhdGgsXG4gICAgfToge1xuICAgICAgICB3b3Jrc3BhY2U6IHN0cmluZyxcbiAgICAgICAgcGF0aDogc3RyaW5nLFxuICAgIH0pOiBDYW5jZWxhYmxlUHJvbWlzZTxib29sZWFuPiB7XG4gICAgICAgIHJldHVybiBfX3JlcXVlc3QoT3BlbkFQSSwge1xuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgIHVybDogJy93L3t3b3Jrc3BhY2V9L3Jlc291cmNlcy90eXBlL2V4aXN0cy97cGF0aH0nLFxuICAgICAgICAgICAgcGF0aDoge1xuICAgICAgICAgICAgICAgICd3b3Jrc3BhY2UnOiB3b3Jrc3BhY2UsXG4gICAgICAgICAgICAgICAgJ3BhdGgnOiBwYXRoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogbGlzdCByZXNvdXJjZV90eXBlc1xuICAgICAqIEByZXR1cm5zIFJlc291cmNlVHlwZSByZXNvdXJjZV90eXBlIGxpc3RcbiAgICAgKiBAdGhyb3dzIEFwaUVycm9yXG4gICAgICovXG4gICAgcHVibGljIHN0YXRpYyBsaXN0UmVzb3VyY2VUeXBlKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PFJlc291cmNlVHlwZT4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vcmVzb3VyY2VzL3R5cGUvbGlzdCcsXG4gICAgICAgICAgICBwYXRoOiB7XG4gICAgICAgICAgICAgICAgJ3dvcmtzcGFjZSc6IHdvcmtzcGFjZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIGxpc3QgcmVzb3VyY2VfdHlwZXMgbmFtZXNcbiAgICAgKiBAcmV0dXJucyBzdHJpbmcgcmVzb3VyY2VfdHlwZSBsaXN0XG4gICAgICogQHRocm93cyBBcGlFcnJvclxuICAgICAqL1xuICAgIHB1YmxpYyBzdGF0aWMgbGlzdFJlc291cmNlVHlwZU5hbWVzKHtcbiAgICAgICAgd29ya3NwYWNlLFxuICAgIH06IHtcbiAgICAgICAgd29ya3NwYWNlOiBzdHJpbmcsXG4gICAgfSk6IENhbmNlbGFibGVQcm9taXNlPEFycmF5PHN0cmluZz4+IHtcbiAgICAgICAgcmV0dXJuIF9fcmVxdWVzdChPcGVuQVBJLCB7XG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAnL3cve3dvcmtzcGFjZX0vcmVzb3VyY2VzL3R5cGUvbGlzdG5hbWVzJyxcbiAgICAgICAgICAgIHBhdGg6IHtcbiAgICAgICAgICAgICAgICAnd29ya3NwYWNlJzogd29ya3NwYWNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuXG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsd0JBQXdCLEdBQ3hCLGtCQUFrQixHQUNsQixrQkFBa0IsR0FTbEIsU0FBUyxPQUFPLFFBQVEscUJBQXFCO0FBQzdDLFNBQVMsV0FBVyxTQUFTLFFBQVEscUJBQXFCO0FBRTFELE9BQU8sTUFBTTtFQUVUOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsU0FBUyxFQUNULFdBQVcsRUFPZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZUFBZSxFQUN6QixTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsZUFBZSxFQUN6QixTQUFTLEVBQ1QsSUFBSSxFQUNKLFdBQVcsRUFRZCxFQUE2QjtJQUMxQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO01BQ0EsTUFBTTtNQUNOLFdBQVc7SUFDZjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsb0JBQW9CLEVBQzlCLFNBQVMsRUFDVCxJQUFJLEVBQ0osV0FBVyxFQVVkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxZQUFZLEVBQ3RCLFNBQVMsRUFDVCxJQUFJLEVBSVAsRUFBK0I7SUFDNUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtRQUNiLFFBQVE7TUFDWjtJQUNKO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxpQkFBaUIsRUFDM0IsU0FBUyxFQUNULElBQUksRUFJUCxFQUEwQjtJQUN2QixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGVBQWUsRUFDekIsU0FBUyxFQUNULElBQUksRUFJUCxFQUE4QjtJQUMzQixPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLGFBQWEsRUFDdkIsU0FBUyxFQUNULElBQUksRUFDSixPQUFPLEVBQ1AsWUFBWSxFQUNaLG1CQUFtQixFQW1CdEIsRUFBOEM7SUFDM0MsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE9BQU87UUFDSCxRQUFRO1FBQ1IsWUFBWTtRQUNaLGlCQUFpQjtRQUNqQix5QkFBeUI7TUFDN0I7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsbUJBQW1CLEVBQzdCLFNBQVMsRUFDVCxXQUFXLEVBT2QsRUFBNkI7SUFDMUIsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtNQUNBLE1BQU07TUFDTixXQUFXO0lBQ2Y7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG1CQUFtQixFQUM3QixTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsbUJBQW1CLEVBQzdCLFNBQVMsRUFDVCxJQUFJLEVBQ0osV0FBVyxFQVFkLEVBQTZCO0lBQzFCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7TUFDQSxNQUFNO01BQ04sV0FBVztJQUNmO0VBQ0o7RUFFQTs7OztLQUlDLEdBQ0QsT0FBYyxnQkFBZ0IsRUFDMUIsU0FBUyxFQUNULElBQUksRUFJUCxFQUFtQztJQUNoQyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO1FBQ2IsUUFBUTtNQUNaO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLG1CQUFtQixFQUM3QixTQUFTLEVBQ1QsSUFBSSxFQUlQLEVBQThCO0lBQzNCLE9BQU8sVUFBVSxTQUFTO01BQ3RCLFFBQVE7TUFDUixLQUFLO01BQ0wsTUFBTTtRQUNGLGFBQWE7UUFDYixRQUFRO01BQ1o7SUFDSjtFQUNKO0VBRUE7Ozs7S0FJQyxHQUNELE9BQWMsaUJBQWlCLEVBQzNCLFNBQVMsRUFHWixFQUEwQztJQUN2QyxPQUFPLFVBQVUsU0FBUztNQUN0QixRQUFRO01BQ1IsS0FBSztNQUNMLE1BQU07UUFDRixhQUFhO01BQ2pCO0lBQ0o7RUFDSjtFQUVBOzs7O0tBSUMsR0FDRCxPQUFjLHNCQUFzQixFQUNoQyxTQUFTLEVBR1osRUFBb0M7SUFDakMsT0FBTyxVQUFVLFNBQVM7TUFDdEIsUUFBUTtNQUNSLEtBQUs7TUFDTCxNQUFNO1FBQ0YsYUFBYTtNQUNqQjtJQUNKO0VBQ0o7QUFFSiJ9
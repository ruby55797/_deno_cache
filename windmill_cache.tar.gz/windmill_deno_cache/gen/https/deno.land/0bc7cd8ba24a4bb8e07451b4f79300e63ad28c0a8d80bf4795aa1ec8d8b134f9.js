/* istanbul ignore file */ /* tslint:disable */ /* eslint-disable */ export var Preview;
(function(Preview) {
  let language;
  (function(language) {
    language["PYTHON3"] = "python3";
    language["DENO"] = "deno";
    language["GO"] = "go";
    language["BASH"] = "bash";
  })(language = Preview.language || (Preview.language = {}));
})(Preview || (Preview = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvd2luZG1pbGxAdjEuOTkuMC93aW5kbWlsbC1hcGkvbW9kZWxzL1ByZXZpZXcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyogaXN0YW5idWwgaWdub3JlIGZpbGUgKi9cbi8qIHRzbGludDpkaXNhYmxlICovXG4vKiBlc2xpbnQtZGlzYWJsZSAqL1xuXG5pbXBvcnQgdHlwZSB7IFNjcmlwdEFyZ3MgfSBmcm9tICcuL1NjcmlwdEFyZ3MudHMnO1xuXG5leHBvcnQgdHlwZSBQcmV2aWV3ID0ge1xuICAgIGNvbnRlbnQ6IHN0cmluZztcbiAgICBwYXRoPzogc3RyaW5nO1xuICAgIGFyZ3M6IFNjcmlwdEFyZ3M7XG4gICAgbGFuZ3VhZ2U6IFByZXZpZXcubGFuZ3VhZ2U7XG4gICAgdGFnPzogc3RyaW5nO1xufTtcblxuZXhwb3J0IG5hbWVzcGFjZSBQcmV2aWV3IHtcblxuICAgIGV4cG9ydCBlbnVtIGxhbmd1YWdlIHtcbiAgICAgICAgUFlUSE9OMyA9ICdweXRob24zJyxcbiAgICAgICAgREVOTyA9ICdkZW5vJyxcbiAgICAgICAgR08gPSAnZ28nLFxuICAgICAgICBCQVNIID0gJ2Jhc2gnLFxuICAgIH1cblxuXG59XG5cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3QkFBd0IsR0FDeEIsa0JBQWtCLEdBQ2xCLGtCQUFrQjtVQVlEOztZQUVEOzs7OztLQUFBLG1CQUFBLHFCQUFBO0FBUWhCLEdBVmlCLFlBQUEifQ==